/**
 * Robes 主题 · 评论无感验证 —— 工作量证明 Worker
 *
 * 在主线程之外求解 SHA-256(nonce + counter) 的高位零前缀，
 * 避免占用主线程导致输入卡顿。找到解后把 counter 作为 proof 回传。
 */
(function () {
    'use strict';

    var K = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    ];

    var W = new Uint32Array(64);
    var BUF = new Uint8Array(4096);          
    var VIEW = new DataView(BUF.buffer);

    function rotr(x, n) { return (x >>> n) | (x << (32 - n)); }

    function sha256Words(len) {
        var H0 = 0x6a09e667, H1 = 0xbb67ae85, H2 = 0x3c6ef372, H3 = 0xa54ff53a,
            H4 = 0x510e527f, H5 = 0x9b05688c, H6 = 0x1f83d9ab, H7 = 0x5be0cd19;

        var bitLen = len * 8;
        var padded = ((len + 9 + 63) >> 6) << 6;

        BUF[len] = 0x80;
        for (var z = len + 1; z < padded - 8; z++) BUF[z] = 0;
        VIEW.setUint32(padded - 8, Math.floor(bitLen / 4294967296), false);
        VIEW.setUint32(padded - 4, bitLen >>> 0, false);

        for (var off = 0; off < padded; off += 64) {
            for (var i = 0; i < 16; i++) W[i] = VIEW.getUint32(off + i * 4, false);
            for (i = 16; i < 64; i++) {
                var w15 = W[i - 15], w2 = W[i - 2];
                var s0 = rotr(w15, 7) ^ rotr(w15, 18) ^ (w15 >>> 3);
                var s1 = rotr(w2, 17) ^ rotr(w2, 19) ^ (w2 >>> 10);
                W[i] = (W[i - 16] + s0 + W[i - 7] + s1) | 0;
            }

            var a = H0, b = H1, c = H2, d = H3, e = H4, f = H5, g = H6, h = H7;

            for (i = 0; i < 64; i++) {
                var S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
                var ch = (e & f) ^ (~e & g);
                var t1 = (h + S1 + ch + K[i] + W[i]) | 0;
                var S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
                var maj = (a & b) ^ (a & c) ^ (b & c);
                var t2 = (S0 + maj) | 0;
                h = g; g = f; f = e; e = (d + t1) | 0;
                d = c; c = b; b = a; a = (t1 + t2) | 0;
            }

            H0 = (H0 + a) | 0; H1 = (H1 + b) | 0; H2 = (H2 + c) | 0; H3 = (H3 + d) | 0;
            H4 = (H4 + e) | 0; H5 = (H5 + f) | 0; H6 = (H6 + g) | 0; H7 = (H7 + h) | 0;
        }

        return [H0, H1, H2, H3, H4, H5, H6, H7];
    }

    var HEX = '0123456789abcdef';

    function emit(msg) {
        if (typeof postMessage === 'function') postMessage(msg);
    }

    function wordsToHex(w) {
        var s = '';
        for (var i = 0; i < 8; i++) {
            var v = w[i] >>> 0;
            for (var j = 28; j >= 0; j -= 4) s += HEX.charAt((v >>> j) & 0xf);
        }
        return s;
    }

    function solve(nonce, difficulty) {
        if (nonce.length > 3800) throw new Error('nonce too long');
        var base = [];
        for (var i = 0; i < nonce.length; i++) base.push(nonce.charCodeAt(i) & 0xff);

        var target = '';
        for (i = 0; i < difficulty; i++) target += '0';

        var t0 = Date.now();
        var counter = 0;
        var hashes = 0;
        var lastReport = t0;

        while (true) {
            for (i = 0; i < base.length; i++) BUF[i] = base[i];
            var digits = String(counter);
            var len = base.length;
            for (i = 0; i < digits.length; i++) BUF[len + i] = digits.charCodeAt(i);
            len += digits.length;

            var hex = wordsToHex(sha256Words(len));
            hashes++;

            if (hex.lastIndexOf(target, 0) === 0) {
                return { proof: digits, hash: hex, hashes: hashes, ms: Date.now() - t0 };
            }

            counter++;
            var now = Date.now();
            if (now - lastReport >= 400) {
                lastReport = now;
                emit({ type: 'progress', hashes: hashes, ms: now - t0 });
            }
        }
    }

    if (typeof self !== 'undefined' && typeof self.postMessage === 'function' && typeof importScripts === 'function') {
        self.onmessage = function (e) {
            var d = e.data || {};
            if (d.cmd !== 'solve') return;
            try {
                postMessage({ type: 'solved', nonce: d.nonce, difficulty: d.difficulty, result: solve(String(d.nonce), parseInt(d.difficulty, 10) || 4) });
            } catch (err) {
                postMessage({ type: 'error', message: String(err && err.message ? err.message : err) });
            }
        };
    }

    if (typeof module !== 'undefined' && module.exports) {
        module.exports = { solve: solve };
    }
})();
