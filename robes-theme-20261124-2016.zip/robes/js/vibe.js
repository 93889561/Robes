/* 通知面板「小站」：漂流瓶
   站长心情由服务端直接渲染，这里只负责交互 */
(function () {
    'use strict';

    var vibe = document.getElementById('noticeVibe');
    if (!vibe) return;

    var endpoint = vibe.getAttribute('data-bottle') || '';
    var lastPick = 0;

    function api(action, params, post) {
        var qs = 'action=' + encodeURIComponent(action);
        params = params || {};
        for (var k in params) {
            if (params.hasOwnProperty(k)) qs += '&' + k + '=' + encodeURIComponent(params[k]);
        }
        var opt = { credentials: 'same-origin', cache: 'no-store' };
        var url = endpoint + '?' + qs;
        if (post) {
            opt.method = 'POST';
            opt.headers = { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' };
            opt.body = qs;
            url = endpoint;
        }
        return fetch(url, opt).then(function (r) { return r.json(); });
    }

    function toast(msg, type) {
        if (typeof window.showToast === 'function') window.showToast(msg, type);
    }

    function timeText(ts) {
        var diff = Math.floor(Date.now() / 1000) - (parseInt(ts, 10) || 0);
        if (diff < 60) return '刚刚';
        if (diff < 3600) return Math.floor(diff / 60) + ' 分钟前';
        if (diff < 86400) return Math.floor(diff / 3600) + ' 小时前';
        if (diff < 2592000) return Math.floor(diff / 86400) + ' 天前';
        var d = new Date((parseInt(ts, 10) || 0) * 1000);
        return (d.getMonth() + 1) + '月' + d.getDate() + '日';
    }

    /* ---------- 漂流瓶 ---------- */
    var pickBtn = document.getElementById('vibePickBtn');
    var bottleBody = document.getElementById('vibeBottleBody');

    function renderBottle(bottle) {
        if (!bottleBody) return;
        bottleBody.innerHTML = '';
        if (!bottle) {
            var empty = document.createElement('div');
            empty.className = 'vibe-bottle-empty';
            empty.innerHTML = '<span class="vibe-empty-ico"><i class="ri-mail-line"></i></span>';
            var emptyTitle = document.createElement('strong');
            emptyTitle.textContent = '海面空空的，要不要扔下第一个瓶子？';
            empty.appendChild(emptyTitle);
            var emptyDesc = document.createElement('span');
            emptyDesc.className = 'vibe-empty-desc';
            emptyDesc.textContent = '写下心事，让它漂向远方';
            empty.appendChild(emptyDesc);
            bottleBody.appendChild(empty);
            return;
        }
        var wrap = document.createElement('div');
        wrap.className = 'vibe-bubble';

        var ava = document.createElement('span');
        ava.className = 'vibe-bubble-ava';
        ava.textContent = (bottle.n || '匿').slice(0, 1);

        var note = document.createElement('div');
        note.className = 'vibe-note';

        var text = document.createElement('p');
        text.className = 'vibe-note-text';
        text.textContent = bottle.t || '';
        note.appendChild(text);

        var meta = document.createElement('div');
        meta.className = 'vibe-note-meta';
        meta.innerHTML = '<i class="ri-user-line"></i>';
        var name = document.createElement('span');
        name.textContent = bottle.n || '匿名';
        var dot = document.createElement('span');
        dot.className = 'vibe-meta-dot';
        var time = document.createElement('span');
        time.textContent = timeText(bottle.ts);
        meta.appendChild(name);
        meta.appendChild(dot);
        meta.appendChild(time);
        note.appendChild(meta);

        wrap.appendChild(ava);
        wrap.appendChild(note);
        bottleBody.appendChild(wrap);
    }

    if (pickBtn && bottleBody) {
        pickBtn.addEventListener('click', function () {
            if (pickBtn.disabled) return;
            pickBtn.disabled = true;
            pickBtn.textContent = '打捞中';
            bottleBody.classList.add('is-loading');
            api('pick', lastPick ? { exclude: lastPick } : null).then(function (d) {
                if (!d || !d.ok) throw new Error('bad');
                lastPick = d.bottle ? d.bottle.id : 0;
                renderBottle(d.bottle);
            }).catch(function () {
                toast('海面有点忙，稍后再试', 'error');
            }).then(function () {
                bottleBody.classList.remove('is-loading');
                pickBtn.disabled = false;
                pickBtn.textContent = '再捞一个';
                syncPanel();
            });
        });
    }

    /* ---------- 扔瓶子 ---------- */
    var dropForm = document.getElementById('vibeDropForm');
    var nickInput = document.getElementById('vibeNick');
    var textInput = document.getElementById('vibeText');
    var countEl = document.getElementById('vibeDropCount');
    var sendBtn = document.getElementById('vibeSend');
    var NICK_KEY = 'robes_vibe_nick';

    try {
        var savedNick = localStorage.getItem(NICK_KEY);
        if (savedNick && nickInput && !nickInput.value) nickInput.value = savedNick;
    } catch (e) {}

    if (textInput && countEl) {
        var syncCount = function () {
            countEl.textContent = (textInput.value.length || 0) + '/120';
        };
        /* 输入条随内容长高，最多三行，超过后自己滚动。
           注意：面板初始是隐藏的，此时量 scrollHeight 会是 0，所以只在有内容时改高度。 */
        var autoGrow = function () {
            if (!textInput.value) { textInput.style.height = ''; return; }
            textInput.style.height = 'auto';
            textInput.style.height = Math.min(textInput.scrollHeight, 66) + 'px';
        };
        textInput.addEventListener('input', function () { syncCount(); autoGrow(); });
        textInput.addEventListener('focus', autoGrow);
        syncCount();
    }

    /* 昵称默认匿名，需要时再展开 */
    var nickToggle = document.getElementById('vibeNickToggle');
    var nickRow = document.getElementById('vibeNickRow');
    if (nickToggle && nickRow) {
        nickToggle.addEventListener('click', function () {
            var opening = nickRow.hidden;
            nickRow.hidden = !opening;
            nickToggle.classList.toggle('is-active', opening);
            nickToggle.setAttribute('aria-expanded', opening ? 'true' : 'false');
            if (opening && nickInput) nickInput.focus();
            syncPanel();
        });
    }

    if (dropForm) {
        dropForm.addEventListener('submit', function (e) {
            e.preventDefault();
            if (!textInput || sendBtn.disabled) return;
            var text = textInput.value.trim();
            if (text.length < 2) {
                toast('再多写几个字吧', 'error');
                textInput.focus();
                return;
            }
            var nick = nickInput ? nickInput.value.trim() : '';
            sendBtn.disabled = true;
            sendBtn.innerHTML = '<i class="ri-loader-4-line"></i>';
            api('drop', { text: text, nick: nick }, true).then(function (d) {
                if (!d || !d.ok) {
                    throw new Error((d && d.message) ? d.message : '发送失败');
                }
                try {
                    if (nick) localStorage.setItem(NICK_KEY, nick);
                    else localStorage.removeItem(NICK_KEY);
                } catch (e2) {}
                textInput.value = '';
                if (countEl) countEl.textContent = '0/120';
                toast('瓶子已经漂出去啦');
                if (pickBtn) pickBtn.textContent = '捞一个';
            }).catch(function (err) {
                toast(err && err.message ? err.message : '网络异常，稍后再试', 'error');
            }).then(function () {
                sendBtn.disabled = false;
                sendBtn.innerHTML = '<i class="ri-share-forward-line"></i>';
            });
        });
    }
    /* ---------- 站长状态（仅站长可见） ---------- */
    var moodForm = document.getElementById('vibeMoodForm');
    var moodEdit = document.getElementById('vibeMoodEdit');
    var moodView = document.getElementById('noticeMood');
    var moodCard = moodView ? moodView.querySelector('.mood-card') : null;
    var moodEndpoint = (moodView && moodView.getAttribute('data-mood')) || '';
    var statusChip = document.getElementById('vibeStatusChip');
    var statusEmoji = document.getElementById('vibeStatusEmoji');
    var statusTextEl = document.getElementById('vibeStatusText');
    var heroTextEl = document.getElementById('vibeMoodText');
    var moodUpdatedEl = document.getElementById('vibeMoodUpdated');
    var emojiInput = document.getElementById('vibeMoodEmojiInput');
    var statusInput = document.getElementById('vibeMoodStatusInput');
    var moodTextarea = document.getElementById('vibeMoodTextarea');
    var presetsWrap = document.getElementById('vibeMoodPresets');
    var moodSave = document.getElementById('vibeMoodSave');
    var moodCancel = document.getElementById('vibeMoodCancel');
    var moodChips = presetsWrap ? presetsWrap.querySelectorAll('.vibe-mood-chip') : [];
    var MOOD_ICONS = {};
    try {
        MOOD_ICONS = JSON.parse((moodView && moodView.getAttribute('data-mood-icons')) || '{}') || {};
    } catch (e) {}

    function syncPanel() {
        document.dispatchEvent(new CustomEvent('robes:panel-resize'));
    }

    function syncMoodChips() {
        if (!emojiInput || !statusInput) return;
        var e = emojiInput.value.trim();
        var s = statusInput.value.trim();
        for (var i = 0; i < moodChips.length; i++) {
            var chip = moodChips[i];
            var on = chip.getAttribute('data-emoji') === e && chip.getAttribute('data-status') === s;
            chip.classList.toggle('is-active', on);
        }
    }

    /* ---------- 站长卡片：歌单播放器（最多 5 首，顺序循环） ---------- */
    var songCard = document.getElementById('vibeMoodSongCard');
    var songCover = document.getElementById('vibeSongCover');
    var songNameEl = document.getElementById('vibeSongName');
    var songArtistEl = document.getElementById('vibeSongArtist');
    var songPlayBtn = document.getElementById('vibeMoodPlay');
    var songProgress = document.getElementById('vibeSongProgress');
    var songPrevBtn = document.getElementById('vibeSongPrev');
    var songNextBtn = document.getElementById('vibeSongNext');
    var songNav = document.getElementById('vibeSongNav');
    /* 顶栏胶囊：放歌时切成「正在播放」的实时活动样子 */
    var islandBtn = document.getElementById('noticeBtn');
    var islandSong = document.getElementById('noticeIslandSong');
    var islandVinyl = document.querySelector('.notice-island-vinyl');

    var PLAYLIST_MAX = 5;
    var playlist = [];
    var playIndex = 0;

    function currentSong() {
        if (!playlist.length) return null;
        if (playIndex >= playlist.length) playIndex = playlist.length - 1;
        if (playIndex < 0) playIndex = 0;
        return playlist[playIndex];
    }

    /* 唱片：优先铺当前歌曲封面，没有封面就退回 CSS 纹路 */
    function paintIslandVinyl(cover) {
        if (!islandVinyl) return;
        if (cover) {
            islandVinyl.style.setProperty('--vinyl-cover', 'url("' + cover.replace(/"/g, '%22') + '")');
            islandVinyl.classList.add('has-cover');
        } else {
            islandVinyl.style.removeProperty('--vinyl-cover');
            islandVinyl.classList.remove('has-cover');
        }
    }

    function songTitle() {
        var nm = ((songNameEl && songNameEl.textContent) || '').replace(/\s+/g, ' ').trim();
        return nm || '当前歌曲';
    }

    function setSongPlaying(on) {
        on = !!on;
        if (songPlayBtn) songPlayBtn.classList.toggle('is-playing', on);
        if (!on && songPlayBtn) songPlayBtn.style.setProperty('--p', '0');
        if (islandBtn) islandBtn.classList.toggle('is-playing', on);
        if (islandSong) {
            islandSong.hidden = !on;
            if (on) {
                var nm = ((songNameEl && songNameEl.textContent) || '').replace(/\s+/g, ' ').trim();
                var ar = ((songArtistEl && songArtistEl.textContent) || '').replace(/\s+/g, ' ').trim();
                islandSong.textContent = nm || '正在播放';
                /* 歌名过长时胶囊里会截断，完整信息挂到 title 上 */
                islandSong.title = (nm || '正在播放') + (ar ? ' · ' + ar : '');
            }
        }
        if (on) paintIslandVinyl(currentSong() && currentSong().cover);
        /* PC 底部栏：播放时显示歌词，暂停/停止时恢复版权信息 */
        if (on) {
            loadLyrics(currentSong());
        } else {
            restoreBottomBar();
        }
    }
    var songEndpoint = (moodView && moodView.getAttribute('data-song')) || '';
    var songInput = document.getElementById('vibeSongInput');
    var songResults = document.getElementById('vibeSongResults');
    var songPickedBox = document.getElementById('vibeSongPicked');
    var songHits = [];
    var songSeq = 0;
    var songTimer = null;
    var audioEl = null;
    var audioSrc = '';

    /* ---------- 歌词（PC 底部栏播放时显示） ---------- */
    var lyricLines = [];
    var lyricIdx = -1;
    var lyricEl = null;
    var lyricReqSeq = 0;
    var bottomBar = document.querySelector('.bottom-bar');

    function songIdOf(song) {
        if (!song) return 0;
        var u = (song.link && song.link.indexOf('id=') !== -1) ? song.link : (song.preview || '');
        var m = u.match(/[?&]id=(\d+)/);
        return m ? parseInt(m[1], 10) : 0;
    }

    function parseLrc(lrc) {
        var out = [];
        if (!lrc) return out;
        var lines = String(lrc).split(/\r?\n/);
        var re = /\[(\d{1,2}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g;
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i];
            var times = [];
            var m;
            re.lastIndex = 0;
            while ((m = re.exec(line)) !== null) {
                var mm = parseInt(m[1], 10);
                var ss = parseInt(m[2], 10);
                var ms = m[3] ? parseInt(m[3], 10) : 0;
                if (m[3] && m[3].length === 3) ms = ms / 1000;
                else if (m[3] && m[3].length === 2) ms = ms / 100;
                times.push(mm * 60 + ss + ms);
            }
            var text = line.replace(/\[[^\]]*\]/g, '').trim();
            if (!text) continue;
            for (var t = 0; t < times.length; t++) {
                out.push({ time: times[t], text: text });
            }
        }
        out.sort(function (a, b) { return a.time - b.time; });
        return out;
    }

    /* 歌词层常驻在底部栏里，用 is-lyric 类做交叉淡入淡出：
       版权信息原样保留，只是淡出，暂停时再淡回来 */
    function ensureLyricEl() {
        if (lyricEl || !bottomBar) return;
        lyricEl = document.createElement('div');
        lyricEl.className = 'bottom-lyric';
        lyricEl.setAttribute('aria-hidden', 'true');
        lyricEl.innerHTML = '<i class="ri-music-2-line"></i><span class="bottom-lyric-line"></span>';
        bottomBar.appendChild(lyricEl);
    }

    function showBottomLyric(text) {
        if (!bottomBar) return;
        var first = !lyricEl;
        ensureLyricEl();
        var line = lyricEl.querySelector('.bottom-lyric-line');
        var next = text || '';
        if (line && line.textContent !== next) {
            line.textContent = next;
            /* 重新触发逐行动画 */
            line.classList.remove('is-swap');
            void line.offsetWidth;
            line.classList.add('is-swap');
        }
        if (first) {
            /* 先让歌词层以透明态落一帧，再切类，过渡才会真的生效 */
            void bottomBar.offsetWidth;
            lyricEl.setAttribute('aria-hidden', 'false');
        }
        bottomBar.classList.add('is-lyric');
    }

    function restoreBottomBar() {
        if (!bottomBar) return;
        bottomBar.classList.remove('is-lyric');
        if (lyricEl) lyricEl.setAttribute('aria-hidden', 'true');
        lyricLines = [];
        lyricIdx = -1;
    }

    function loadLyrics(song) {
        lyricReqSeq++;
        var seq = lyricReqSeq;
        lyricLines = [];
        lyricIdx = -1;
        var nm = (song && song.name) || '';
        var ar = (song && song.artist) || '';
        var id = songIdOf(song);
        /* 先把歌名铺上去，等歌词回来再逐行替换 */
        showBottomLyric(nm + (ar ? ' - ' + ar : ''));
        if (!id || !songEndpoint) return;
        fetch(songEndpoint + (songEndpoint.indexOf('?') === -1 ? '?' : '&') + 'action=lyric&id=' + id, {
            credentials: 'same-origin',
            cache: 'no-store'
        }).then(function (r) { return r.json(); }).then(function (d) {
            if (seq !== lyricReqSeq) return;
            if (d && d.ok && d.lrc) lyricLines = parseLrc(d.lrc);
            if (!lyricLines.length) {
                showBottomLyric(nm + (ar ? ' - ' + ar : ''));
            } else {
                syncLyric(audioEl ? audioEl.currentTime : 0);
            }
        }).catch(function () {
            if (seq !== lyricReqSeq) return;
            showBottomLyric(nm + (ar ? ' - ' + ar : ''));
        });
    }

    function syncLyric(currentTime) {
        if (!lyricLines.length) return;
        var idx = -1;
        for (var i = 0; i < lyricLines.length; i++) {
            if (lyricLines[i].time <= currentTime) idx = i;
            else break;
        }
        if (idx !== lyricIdx) {
            lyricIdx = idx;
            if (idx >= 0) showBottomLyric(lyricLines[idx].text);
        }
    }

    function songIcon(cls) {
        return '<i class="' + cls + '"></i>';
    }

    /* 卡片上显示哪一首：只改 DOM，不动音频 */
    function paintTrack() {
        var s = currentSong();
        if (songCard) songCard.hidden = !s;
        if (songNav) {
            songNav.hidden = playlist.length < 2;
            songNav.title = playlist.length > 1 ? (playIndex + 1) + ' / ' + playlist.length : '';
        }
        if (!s) {
            if (songNameEl) songNameEl.textContent = '';
            if (songArtistEl) songArtistEl.textContent = '';
            if (songPlayBtn) {
                songPlayBtn.hidden = true;
                songPlayBtn.setAttribute('data-src', '');
            }
            return;
        }
        if (songCover) {
            songCover.innerHTML = '';
            if (s.cover) {
                var img = document.createElement('img');
                img.src = s.cover;
                img.alt = '';
                img.loading = 'lazy';
                songCover.appendChild(img);
            } else {
                songCover.innerHTML = songIcon('ri-music-2-line');
            }
        }
        if (songNameEl) songNameEl.textContent = s.name;
        if (songArtistEl) songArtistEl.textContent = s.artist || '';
        if (songPlayBtn) {
            songPlayBtn.hidden = !s.preview;
            songPlayBtn.setAttribute('data-src', s.preview || '');
        }
    }

    function resetAudio() {
        if (audioEl) {
            audioEl.pause();
            try { audioEl.currentTime = 0; } catch (e) {}
        }
        if (songProgress) songProgress.style.width = '0%';
        if (songPlayBtn) songPlayBtn.style.setProperty('--p', '0');
        setSongPlaying(false);
    }

    /* 整体替换歌单：服务端渲染的初始数据、保存成功后的回填都走这里。
       如果新的当前曲还是同一首（src 没变），就接着放，不要从头来一遍 */
    function applyPlaylist(list, index) {
        var prevSrc = audioSrc;
        playlist = [];
        if (list && list.length) {
            for (var i = 0; i < list.length && playlist.length < PLAYLIST_MAX; i++) {
                var it = list[i];
                if (!it || !it.name) continue;
                playlist.push({
                    name: it.name,
                    artist: it.artist || '',
                    cover: it.cover || '',
                    preview: it.preview || '',
                    link: it.link || ''
                });
            }
        }
        playIndex = playlist.length ? Math.min(Math.max(index || 0, 0), playlist.length - 1) : 0;
        var s = currentSong();
        if (!(prevSrc && s && s.preview === prevSrc)) {
            audioSrc = '';
            resetAudio();
        }
        paintTrack();
        renderPlaylistEditor();
    }

    /* 编辑表单里的歌单列表：点行切换当前曲，点叉移除 */
    function renderPlaylistEditor() {
        if (!songPickedBox) return;
        songPickedBox.innerHTML = '';
        if (!playlist.length) {
            songPickedBox.hidden = true;
            return;
        }
        var head = document.createElement('div');
        head.className = 'vibe-song-list-head';
        var title = document.createElement('span');
        title.innerHTML = songIcon('ri-music-2-line');
        var cnt = document.createElement('b');
        cnt.textContent = '歌单 ' + playlist.length + '/' + PLAYLIST_MAX;
        title.appendChild(cnt);
        var tip = document.createElement('span');
        tip.className = 'vibe-song-list-tip';
        tip.textContent = '顺序循环';
        head.appendChild(title);
        head.appendChild(tip);
        songPickedBox.appendChild(head);

        playlist.forEach(function (s, idx) {
            var row = document.createElement('div');
            row.className = 'vibe-song-row' + (idx === playIndex ? ' is-current' : '');
            row.title = '设为当前播放';
            if (s.cover) {
                var cover = document.createElement('img');
                cover.className = 'vibe-song-picked-cover';
                cover.src = s.cover;
                cover.alt = '';
                cover.loading = 'lazy';
                row.appendChild(cover);
            } else {
                var ph = document.createElement('span');
                ph.className = 'vibe-song-picked-cover vibe-song-row-ph';
                ph.innerHTML = songIcon('ri-music-2-line');
                row.appendChild(ph);
            }
            var meta = document.createElement('span');
            meta.className = 'vibe-song-picked-meta';
            var name = document.createElement('span');
            name.className = 'vibe-song-picked-name';
            name.textContent = s.name;
            meta.appendChild(name);
            if (s.artist) {
                var artist = document.createElement('span');
                artist.className = 'vibe-song-picked-artist';
                artist.textContent = s.artist;
                meta.appendChild(artist);
            }
            row.appendChild(meta);
            row.addEventListener('click', function () {
                if (playIndex === idx) return;
                playIndex = idx;
                audioSrc = '';
                resetAudio();
                paintTrack();
                renderPlaylistEditor();
            });
            var clear = document.createElement('button');
            clear.type = 'button';
            clear.className = 'vibe-song-clear';
            clear.setAttribute('aria-label', '从歌单移除');
            clear.innerHTML = songIcon('ri-close-line');
            clear.addEventListener('click', function (e) {
                e.stopPropagation();
                removeFromPlaylist(idx);
            });
            row.appendChild(clear);
            songPickedBox.appendChild(row);
        });
        songPickedBox.hidden = false;
    }

    function removeFromPlaylist(idx) {
        if (idx < 0 || idx >= playlist.length) return;
        var wasCurrent = idx === playIndex;
        playlist.splice(idx, 1);
        if (!playlist.length) {
            playIndex = 0;
        } else if (idx < playIndex) {
            playIndex--;
        } else if (playIndex >= playlist.length) {
            playIndex = playlist.length - 1;
        }
        if (wasCurrent) {
            audioSrc = '';
            resetAudio();
        }
        paintTrack();
        renderPlaylistEditor();
        syncPanel();
    }

    function addToPlaylist(hit) {
        if (!hit || !hit.name) return false;
        if (playlist.length >= PLAYLIST_MAX) {
            toast('最多放 ' + PLAYLIST_MAX + ' 首，先移除一首吧');
            return false;
        }
        for (var i = 0; i < playlist.length; i++) {
            if (playlist[i].name === hit.name && (playlist[i].artist || '') === (hit.artist || '')) {
                toast('这首已经在歌单里了');
                return false;
            }
        }
        playlist.push({
            name: hit.name,
            artist: hit.artist || '',
            cover: hit.cover || '',
            preview: hit.preview || '',
            link: hit.link || ''
        });
        paintTrack();
        renderPlaylistEditor();
        syncPanel();
        return true;
    }

    function renderSongHits() {
        if (!songResults) return;
        songResults.innerHTML = '';
        if (!songHits.length) {
            songResults.innerHTML = '<div class="vibe-song-tip">没搜到，换个关键词试试</div>';
            songResults.hidden = false;
            return;
        }
        songHits.forEach(function (hit) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'vibe-song-hit';
            var art = document.createElement('span');
            art.className = 'vibe-song-hit-cover';
            if (hit.cover) {
                var im = document.createElement('img');
                im.src = hit.cover;
                im.alt = '';
                im.loading = 'lazy';
                art.appendChild(im);
            }
            btn.appendChild(art);
            var info = document.createElement('span');
            info.className = 'vibe-song-hit-meta';
            var nm = document.createElement('span');
            nm.className = 'vibe-song-hit-name';
            nm.textContent = hit.name;
            var ar = document.createElement('span');
            ar.className = 'vibe-song-hit-artist';
            ar.textContent = hit.artist;
            info.appendChild(nm);
            info.appendChild(ar);
            btn.appendChild(info);
            btn.addEventListener('click', function () {
                if (btn.classList.contains('is-added')) {
                    toast('这首已经在歌单里了');
                    return;
                }
                if (addToPlaylist(hit)) btn.classList.add('is-added');
            });
            songResults.appendChild(btn);
        });
        songResults.hidden = false;
    }

    function searchSongs(q) {
        var seq = ++songSeq;
        songResults.hidden = false;
        songResults.innerHTML = '<div class="vibe-song-tip">搜索中…</div>';
        var req;
        if (songEndpoint) {
            req = fetch(songEndpoint + (songEndpoint.indexOf('?') === -1 ? '?' : '&') + 'q=' + encodeURIComponent(q), {
                credentials: 'same-origin',
                cache: 'no-store'
            }).then(function (r) { return r.json(); });
        } else {
            req = fetch('https://itunes.apple.com/search?term=' + encodeURIComponent(q) + '&media=music&entity=song&limit=6&country=CN', { cache: 'no-store' })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    var out = [], list = (d && d.results) || [];
                    for (var i = 0; i < list.length; i++) {
                        var it = list[i];
                        out.push({
                            name: it.trackName || '',
                            artist: it.artistName || '',
                            cover: String(it.artworkUrl100 || '').replace('100x100bb', '200x200bb'),
                            preview: it.previewUrl || '',
                            link: it.trackViewUrl || ''
                        });
                    }
                    return { ok: true, results: out };
                });
        }
        req.then(function (d) {
            if (seq !== songSeq) return;
            songHits = [];
            if (d && d.ok === false) {
                songResults.innerHTML = '<div class="vibe-song-tip">' + (d.message || '没搜到，换个关键词试试') + '</div>';
                songResults.hidden = false;
                return;
            }
            var list = (d && d.results) || [];
            for (var i = 0; i < list.length; i++) {
                var it = list[i];
                if (!it.name) continue;
                songHits.push({
                    name: it.name,
                    artist: it.artist || '',
                    cover: it.cover || '',
                    preview: it.preview || '',
                    link: it.link || ''
                });
            }
            renderSongHits();
        }).catch(function () {
            if (seq !== songSeq) return;
            songResults.innerHTML = '<div class="vibe-song-tip">搜索失败，稍后再试</div>';
            songResults.hidden = false;
        });
    }

    /* ---------- 播放器：单例 Audio，切歌只换 src ---------- */
    function ensureAudio() {
        if (audioEl) return audioEl;
        audioEl = new Audio();
        audioEl.preload = 'none';
        audioEl.addEventListener('timeupdate', function () {
            var pct = audioEl.duration ? Math.min(100, (audioEl.currentTime / audioEl.duration) * 100) : 0;
            if (songProgress) songProgress.style.width = pct + '%';
            if (songPlayBtn) songPlayBtn.style.setProperty('--p', pct.toFixed(1));
            syncLyric(audioEl.currentTime);
        });
        /* 放完自动接下一首；只有一首时从头再来 */
        audioEl.addEventListener('ended', function () {
            if (playlist.length < 2) {
                playCurrent(true);
                return;
            }
            stepTrack(1, true);
        });
        /* 某一首失效别把整条歌单卡死：提示后静默跳到下一首 */
        audioEl.addEventListener('error', function () {
            toast('试听加载失败，稍后再试', 'error');
            setSongPlaying(false);
            if (playlist.length > 1) stepTrack(1, false);
        });
        return audioEl;
    }

    function startAudio(src) {
        if (!src) return;
        var a = ensureAudio();
        if (audioSrc !== src) {
            audioSrc = src;
            a.src = src;
            if (songProgress) songProgress.style.width = '0%';
        }
        /* 先立刻给反馈：胶囊 / 播放按钮马上进入播放态并弹提示，不等音频缓冲 */
        setSongPlaying(true);
        toast('正在播放 · ' + songTitle(), 'music');
        var p = a.play();
        if (p && p.catch) {
            p.catch(function () {
                setSongPlaying(false);
                toast('播放失败，请稍后再试', 'error');
            });
        }
    }

    /* 切到当前曲：先停旧的、刷新卡片，需要时再开播 */
    function playCurrent(auto) {
        var s = currentSong();
        var src = s ? (s.preview || '') : '';
        audioSrc = '';
        resetAudio();
        paintTrack();
        if (auto && src) startAudio(src);
    }

    function stepTrack(delta, auto) {
        if (!playlist.length) return;
        if (playlist.length === 1) {
            if (auto) playCurrent(true);
            return;
        }
        playIndex = (playIndex + delta + playlist.length) % playlist.length;
        playCurrent(auto);
    }

    if (songPlayBtn) {
        songPlayBtn.addEventListener('click', function () {
            var s = currentSong();
            var src = s ? (s.preview || '') : '';
            if (!src) return;
            var a = ensureAudio();
            if (a.paused) {
                startAudio(src);
            } else {
                a.pause();
                setSongPlaying(false);
                toast('已暂停 · ' + songTitle(), 'pause');
            }
        });
    }
    if (songPrevBtn) {
        songPrevBtn.addEventListener('click', function () {
            stepTrack(-1, !!(audioEl && !audioEl.paused));
        });
    }
    if (songNextBtn) {
        songNextBtn.addEventListener('click', function () {
            stepTrack(1, !!(audioEl && !audioEl.paused));
        });
    }

    function applyMood(d) {
        var m = (d && d.mood) || {};
        var st = (m.status || '').trim();
        var em = (m.emoji || '').trim();
        var tx = (m.text || '').trim();
        if (statusEmoji) {
            if (MOOD_ICONS[em]) statusEmoji.innerHTML = MOOD_ICONS[em];
            else statusEmoji.textContent = em || '🌿';
        }
        if (statusTextEl) statusTextEl.textContent = st;
        if (statusChip) statusChip.hidden = !st;
        if (heroTextEl) {
            heroTextEl.textContent = tx || (d && d.fallback) || '今天也在认真生活，慢慢来，别着急。';
        }
        if (moodUpdatedEl) {
            moodUpdatedEl.textContent = (d && d.timeText) ? '更新于 ' + d.timeText : '';
        }
        if (moodCard) {
            moodCard.classList.toggle('has-status', !!st);
        }
        if (emojiInput) emojiInput.value = em;
        if (statusInput) statusInput.value = st;
        if (moodTextarea) moodTextarea.value = tx;
        var songList = [];
        if (m.songs && m.songs.length) songList = m.songs;
        else if (m.song && m.song.name) songList = [m.song];
        /* 保存后尽量停在刚才那一首上，别把正在听的歌打断 */
        var keepIdx = 0;
        var nowSong = currentSong();
        if (nowSong) {
            for (var si = 0; si < songList.length; si++) {
                if (songList[si].name === nowSong.name && (songList[si].artist || '') === (nowSong.artist || '')) {
                    keepIdx = si;
                    break;
                }
            }
        }
        applyPlaylist(songList, keepIdx);
        syncMoodChips();
    }

    if (moodForm && moodEdit && moodEndpoint) {
        var moodFormTimer = 0;
        /* 展开 / 收起编辑表单：表单高度与面板高度用同一节奏一起变，
           不会出现「整块内容先冒出来、再被面板慢慢推开」的顿感 */
        function setMoodForm(open) {
            if (open === !moodForm.hidden) return;
            clearTimeout(moodFormTimer);
            var h;
            if (open) {
                moodForm.hidden = false;
                h = moodForm.offsetHeight;
                /* 先让面板按「完全展开」的高度定目标，再让表单从 0 长上来 */
                moodForm.style.height = h + 'px';
                moodForm.style.opacity = '1';
                syncPanel();
                moodForm.style.overflow = 'hidden';
                moodForm.style.transition = 'none';
                moodForm.style.height = '0px';
                moodForm.style.opacity = '0';
                void moodForm.offsetWidth;
                moodForm.style.transition = 'height .34s cubic-bezier(.16,1,.3,1), opacity .24s ease';
                moodForm.style.height = h + 'px';
                moodForm.style.opacity = '1';
                moodFormTimer = setTimeout(function () {
                    moodForm.style.cssText = '';
                    syncPanel();
                }, 360);
                if (statusInput) {
                    setTimeout(function () {
                        try { statusInput.focus({ preventScroll: true }); } catch (e) { statusInput.focus(); }
                    }, 130);
                }
            } else {
                h = moodForm.offsetHeight;
                /* 先量「收起后」的面板高度，面板收缩和表单收起同时开始 */
                moodForm.hidden = true;
                syncPanel();
                moodForm.hidden = false;
                moodForm.style.overflow = 'hidden';
                moodForm.style.height = h + 'px';
                moodForm.style.opacity = '1';
                void moodForm.offsetWidth;
                moodForm.style.transition = 'height .3s cubic-bezier(.4,0,.2,1), opacity .2s ease';
                moodForm.style.height = '0px';
                moodForm.style.opacity = '0';
                moodFormTimer = setTimeout(function () {
                    moodForm.hidden = true;
                    moodForm.style.cssText = '';
                }, 320);
            }
            moodEdit.classList.toggle('is-active', open);
        }

        moodEdit.addEventListener('click', function () {
            setMoodForm(moodForm.hidden);
        });

        if (moodCancel) {
            moodCancel.addEventListener('click', function () {
                setMoodForm(false);
            });
        }

        if (presetsWrap) {
            presetsWrap.addEventListener('click', function (e) {
                var chip = e.target.closest('.vibe-mood-chip');
                if (!chip) return;
                if (emojiInput) emojiInput.value = chip.getAttribute('data-emoji') || '';
                if (statusInput) statusInput.value = chip.getAttribute('data-status') || '';
                syncMoodChips();
            });
        }
        if (emojiInput) emojiInput.addEventListener('input', syncMoodChips);
        if (statusInput) statusInput.addEventListener('input', syncMoodChips);
        syncMoodChips();
        renderPlaylistEditor();

        if (songInput) {
            songInput.addEventListener('input', function () {
                var q = songInput.value.trim();
                clearTimeout(songTimer);
                if (q.length < 2) {
                    songSeq++;
                    songResults.hidden = true;
                    songResults.innerHTML = '';
                    return;
                }
                songTimer = setTimeout(function () { searchSongs(q); }, 420);
            });
            /* 回车不要提交表单，交给搜索结果去选 */
            songInput.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') e.preventDefault();
            });
        }

        moodForm.addEventListener('submit', function (e) {
            e.preventDefault();
            if (moodSave.disabled) return;
            var body = 'action=save'
                + '&token=' + encodeURIComponent(moodForm.getAttribute('data-token') || '')
                + '&emoji=' + encodeURIComponent(emojiInput ? emojiInput.value.trim() : '')
                + '&status=' + encodeURIComponent(statusInput ? statusInput.value.trim() : '')
                + '&text=' + encodeURIComponent(moodTextarea ? moodTextarea.value.trim() : '')
                + '&songs=' + encodeURIComponent(JSON.stringify(playlist));
            moodSave.disabled = true;
            moodSave.innerHTML = '<i class="ri-loader-4-line"></i>保存中';
            fetch(moodEndpoint, {
                method: 'POST',
                credentials: 'same-origin',
                cache: 'no-store',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: body
            }).then(function (r) {
                return r.json();
            }).then(function (d) {
                if (!d || !d.ok) {
                    throw new Error((d && d.message) ? d.message : '保存失败');
                }
                applyMood(d);
                setMoodForm(false);
                toast('状态已更新，其他访客最多 5 分钟后看到');
            }).catch(function (err) {
                toast(err && err.message ? err.message : '网络异常，稍后再试', 'error');
            }).then(function () {
                moodSave.disabled = false;
                moodSave.innerHTML = '<i class="ri-check-line"></i>保存';
            });
        });
    }

    /* 访客首屏：歌单由服务端塞进 data-playlist，
       打开页面随机抽一首作为「当前曲」，但不自动出声，等访客自己点播放 */
    function initPlaylistFromDom() {
        if (playlist.length) return;
        var raw = songCard ? (songCard.getAttribute('data-playlist') || '') : '';
        var list = [];
        if (raw) {
            try { list = JSON.parse(raw) || []; } catch (e) { list = []; }
        }
        if (!list.length) {
            /* 老数据兜底：直接读卡片里的那一首 */
            var name = songNameEl ? songNameEl.textContent.trim() : '';
            if (name) {
                var img = songCover ? songCover.querySelector('img') : null;
                list = [{
                    name: name,
                    artist: songArtistEl ? songArtistEl.textContent.trim() : '',
                    preview: songPlayBtn ? (songPlayBtn.getAttribute('data-src') || '') : '',
                    cover: img ? (img.getAttribute('src') || '') : ''
                }];
            }
        }
        if (!list.length) {
            renderPlaylistEditor();
            return;
        }
        var idx = Math.floor(Math.random() * Math.min(list.length, PLAYLIST_MAX));
        applyPlaylist(list, idx);
    }

    if (songCard) initPlaylistFromDom();
})();

