/* Robes 首页模块：首屏轮播 / 一言天气 / 排序切换 / 首页点赞 */
// ==================== 首页首屏轮播交互（原 index.php 内联脚本） ====================
                (function () {
                    function initHeroStage() {
                        var hero = document.getElementById('hero');
                        var feature = document.getElementById('heroFeature');
                        if (!hero || !feature || feature.dataset.ready === '1') return;

                        var slides = Array.prototype.slice.call(feature.querySelectorAll('.hero-feat'));
                        if (!slides.length) return;
                        feature.dataset.ready = '1';

                        var layers = Array.prototype.slice.call(hero.querySelectorAll('.hero-bg-layer'));
                        var dotsBox = document.getElementById('heroDots');
                        var prev = document.getElementById('heroPrev');
                        var next = document.getElementById('heroNext');
                        var total = slides.length;
                        var fallback = feature.getAttribute('data-fallback') || '';
                        var idx = parseInt(feature.dataset.start, 10);
                        if (isNaN(idx) || idx < 0 || idx >= total) idx = 0;
                        var layerIdx = 0;
                        var firstShown = false;
                        var cache = {};
                        var timer = null;

                        var dots = [];
                        if (dotsBox) {
                            slides.forEach(function (_, i) {
                                var b = document.createElement('button');
                                b.type = 'button';
                                b.className = 'hero-dot' + (i === idx ? ' is-active' : '');
                                b.setAttribute('aria-label', '切换到第 ' + (i + 1) + ' 篇');
                                b.addEventListener('click', function () { goTo(i); restart(); });
                                dotsBox.appendChild(b);
                                dots.push(b);
                            });
                        }

                        function pad2(n) { return (n < 10 ? '0' : '') + n; }
                        /* 序号始终从当前 DOM 读取，避免闭包持有旧节点导致不同步 */
                        function paintCount() {
                            var box = document.getElementById('heroDots');
                            var el = document.getElementById('heroCount');
                            if (!box || !el) return;
                            var all = box.querySelectorAll('.hero-dot');
                            var active = 0;
                            for (var i = 0; i < all.length; i++) {
                                if (all[i].classList.contains('is-active')) { active = i; break; }
                            }
                            el.innerHTML = '<b>' + pad2(active + 1) + '</b><i>/</i>' + pad2(all.length || total);
                        }
                        var dotsLive = document.getElementById('heroDots');
                        if (dotsLive && window.MutationObserver) {
                            new MutationObserver(paintCount).observe(dotsLive, {
                                subtree: true, attributes: true, attributeFilter: ['class']
                            });
                        }
                        paintCount();

                        function coverOf(i) {
                            return slides[i].getAttribute('data-bg') || '';
                        }

                        function setBg(i) {
                            var url = coverOf(i);
                            if (!url || layers.length < 2) return;
                            var target = layers[1 - layerIdx];
                            /* 首次显示直接呈现；之后切片的淡入保留 */
                            var activate = function (u) {
                                var instant = !firstShown;
                                target.style.backgroundImage = 'url("' + u.replace(/"/g, '\\"') + '")';
                                if (instant) {
                                    firstShown = true;
                                    target.style.transition = 'none';
                                }
                                target.classList.add('is-active');
                                layers[layerIdx].classList.remove('is-active');
                                layerIdx = 1 - layerIdx;
                                if (instant) requestAnimationFrame(function () { target.style.transition = ''; });
                            };
                            var swap = function () { activate(url); };
                            var img = cache[url];
                            if (img && img.complete && img.naturalWidth) { swap(); return; }
                            img = new Image();
                            cache[url] = img;
                            img.onload = swap;
                            img.onerror = function () {
                                /* 外链封面失效时回退到站点横幅图，避免停在上一张 */
                                if (!fallback || fallback === url) return;
                                activate(fallback);
                            };
                            img.src = url;
                        }

                        function preload(i) {
                            var url = coverOf(i);
                            if (!url || cache[url]) return;
                            cache[url] = new Image();
                            cache[url].src = url;
                        }

                        function goTo(n) {
                            if (total < 2) return;
                            var target = ((n % total) + total) % total;
                            if (target === idx) return;
                            slides[idx].classList.remove('is-active');
                            slides[target].classList.add('is-active');
                            if (dots[idx]) dots[idx].classList.remove('is-active');
                            if (dots[target]) dots[target].classList.add('is-active');
                            if (typeof refreshSlideGroups === 'function') refreshSlideGroups(true);
                            idx = target;
                            paintCount();
                            setBg(idx);
                            preload((idx + 1) % total);
                            resetRing();
                        }

                        /* 右箭头按钮的进度环：换片后从头再走一遍 5 秒 */
                        function resetRing() {
                            if (!next) return;
                            next.classList.remove('is-running');
                            void next.offsetWidth;
                            next.classList.add('is-running');
                        }

                        function stop() {
                            if (timer) { clearInterval(timer); timer = null; }
                            hero.classList.add('is-paused');
                        }
                        function play() {
                            stop();
                            hero.classList.remove('is-paused');
                            resetRing();
                            if (total < 2) return;
                            timer = setInterval(function () {
                                if (document.hidden) return;
                                if (!document.body.contains(feature)) { stop(); return; }
                                goTo(idx + 1);
                            }, 5000);
                        }
                        function restart() { play(); }

                        if (prev) prev.addEventListener('click', function () { goTo(idx - 1); restart(); });
                        if (next) next.addEventListener('click', function () { goTo(idx + 1); restart(); });
                        hero.addEventListener('mouseenter', stop);
                        hero.addEventListener('mouseleave', play);
                        hero.addEventListener('focusin', stop);

                        var tx = 0, ty = 0;
                        hero.addEventListener('touchstart', function (e) {
                            tx = e.touches[0].clientX; ty = e.touches[0].clientY;
                        }, { passive: true });
                        hero.addEventListener('touchend', function (e) {
                            var t = e.changedTouches[0];
                            var dx = t.clientX - tx, dy = t.clientY - ty;
                            if (Math.abs(dx) > 46 && Math.abs(dx) > Math.abs(dy) * 1.4) {
                                goTo(idx + (dx < 0 ? 1 : -1));
                                restart();
                            }
                        }, { passive: true });

                        preload((idx + 1) % total);
                        play();
                    }

                    initHeroStage();
                    document.addEventListener('DOMContentLoaded', initHeroStage);
                    if (document.body) {
                        new MutationObserver(initHeroStage).observe(document.body, { childList: true, subtree: true });
                    }
                })();
                

var _heroWeatherCache = null;

var weatherCodeMap = {
    113: ['ri-sun-line', '晴'], 116: ['ri-sun-cloudy-line', '多云'], 119: ['ri-cloudy-line', '阴'], 122: ['ri-cloudy-line', '阴天'],
    143: ['ri-foggy-line', '薄雾'], 149: ['ri-foggy-line', '烟霾'], 176: ['ri-drizzle-line', '零星小雨'], 179: ['ri-snowy-line', '零星阵雪'],
    182: ['ri-rainy-line', '雨夹雪'], 185: ['ri-rainy-line', '冻毛毛雨'], 200: ['ri-thunderstorms-line', '雷阵雨'],
    227: ['ri-snowy-line', '风吹雪'], 230: ['ri-snowy-line', '暴风雪'], 248: ['ri-foggy-line', '雾'], 260: ['ri-foggy-line', '冻雾'],
    263: ['ri-drizzle-line', '零星毛毛雨'], 266: ['ri-rainy-line', '毛毛雨'], 281: ['ri-rainy-line', '冻毛毛雨'],
    284: ['ri-rainy-line', '强冻毛毛雨'], 293: ['ri-rainy-line', '零星小雨'], 296: ['ri-rainy-line', '小雨'],
    299: ['ri-showers-line', '间歇中雨'], 302: ['ri-rainy-line', '中雨'], 305: ['ri-showers-line', '间歇大雨'],
    308: ['ri-showers-line', '大雨'], 311: ['ri-rainy-line', '小雨转冻雨'], 314: ['ri-rainy-line', '中雨转冻雨'],
    317: ['ri-rainy-line', '小雨夹雪'], 320: ['ri-rainy-line', '中雨夹雪'], 323: ['ri-snowy-line', '零星小雪'],
    326: ['ri-snowy-line', '小雪'], 329: ['ri-snowy-line', '零星中雪'], 332: ['ri-snowy-line', '中雪'],
    335: ['ri-snowy-line', '零星大雪'], 338: ['ri-snowy-line', '大雪'], 350: ['ri-rainy-line', '冰粒'],
    353: ['ri-drizzle-line', '零星小阵雨'], 356: ['ri-showers-line', '中阵雨'],
    359: ['ri-showers-line', '大阵雨'], 362: ['ri-rainy-line', '小雨夹雪阵'], 365: ['ri-rainy-line', '中雨夹雪阵'],
    368: ['ri-snowy-line', '零星小雪阵'], 371: ['ri-snowy-line', '小阵雪'], 374: ['ri-snowy-line', '零星中雪阵'],
    377: ['ri-snowy-line', '中阵雪'], 386: ['ri-thunderstorms-line', '零星雷阵雨'], 389: ['ri-thunderstorms-line', '强雷阵雨'],
    392: ['ri-thunderstorms-line', '零星雷雪'], 395: ['ri-snowy-line', '中雷雪']
};

var weatherDescMap = {
    'Sunny': '晴', 'Clear': '晴', 'Partly cloudy': '多云', 'Cloudy': '阴', 'Overcast': '阴天',
    'Mist': '薄雾', 'Fog': '雾', 'Haze': '霾', 'Smoke': '烟霾', 'Freezing fog': '冻雾',
    'Patchy rain possible': '零星小雨', 'Light drizzle': '毛毛雨', 'Light rain': '小雨',
    'Moderate rain': '中雨', 'Heavy rain': '大雨', 'Patchy light rain': '零星小雨',
    'Thundery outbreaks possible': '雷阵雨', 'Light rain shower': '小阵雨',
    'Moderate or heavy rain shower': '中到大阵雨', 'Patchy light rain with thunder': '零星雷阵雨',
    'Patchy snow possible': '零星小雪', 'Light snow': '小雪', 'Moderate snow': '中雪',
    'Heavy snow': '大雪', 'Blizzard': '暴风雪'
};

function weatherInfo(code, fallbackDesc) {
    var hit = weatherCodeMap[parseInt(code, 10)];
    if (hit) return { icon: hit[0], text: hit[1] };
    var desc = String(fallbackDesc || '').trim();
    return { icon: 'ri-cloudy-line', text: weatherDescMap[desc] || desc || '—' };
}

function renderHeroWeather(box, data) {
    if (!box) return;
    box.classList.remove('is-loading', 'is-error');
    var info = weatherInfo(data.code, data.desc);
    var icon = box.querySelector('.hw-icon');
    var city = box.querySelector('.hw-city');
    var temp = box.querySelector('.hw-temp');
    var desc = box.querySelector('.hw-desc');
    var meta = box.querySelector('.hw-meta');
    if (icon) icon.className = info.icon + ' hw-icon';
    if (city) city.textContent = data.city || '';
    if (temp) temp.textContent = data.temp + '°';
    if (desc) desc.textContent = info.text;

    if (meta) {
        var parts = [];
        if (data.feels) parts.push('体感 ' + data.feels + '°');
        if (data.humidity) parts.push('湿度 ' + data.humidity + '%');
        if (data.wind) parts.push(data.wind);
        meta.textContent = parts.join(' · ');
    }
}
function initHero() {
    var hero = document.getElementById('hero');
    if (!hero) return;

    initHeroBg();

    bindHeroRec();

    var wbox = document.getElementById('heroWeather');
    if (!wbox || hero.dataset.weather !== '1') return;

    if (_heroWeatherCache) {
        renderHeroWeather(wbox, _heroWeatherCache);
        return;
    }

    wbox.classList.add('is-loading');
    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = setTimeout(function() { if (ctrl) ctrl.abort(); }, 10000);

    fetch((typeof ROBES !== 'undefined' && ROBES.themeUrl ? ROBES.themeUrl.replace(/\/+$/, '') : '') + '/extras/weather.php', ctrl ? { signal: ctrl.signal } : {})
        .then(function(r) { if (!r.ok) throw new Error('status ' + r.status); return r.json(); })
        .then(function(json) {
            clearTimeout(timer);
            if (!json || !json.ok || !json.temp) throw new Error('empty');
            var data = {
                temp: json.temp, code: json.code, desc: json.desc,
                city: json.city, feels: json.feels, humidity: json.humidity, wind: json.wind
            };
            _heroWeatherCache = data;
            renderHeroWeather(wbox, data);
        })
        .catch(function() {
            clearTimeout(timer);
            wbox.classList.remove('is-loading');
            wbox.classList.add('is-error');
            var temp = wbox.querySelector('.hw-temp');
            var desc = wbox.querySelector('.hw-desc');
            if (temp) temp.textContent = '';
            if (desc) desc.textContent = '天气获取失败';
        });
}

function initHeroBg() {
    var bg = document.querySelector('.hero-bg');
    if (!bg) return;
    var ready = function() { bg.classList.add('active'); };
    if (bg.complete && bg.naturalWidth > 0) ready();
    else {
        bg.addEventListener('load', ready);
        bg.addEventListener('error', function() { bg.style.display = 'none'; });
    }
}

var _heroRecTimer = null;

function stopHeroRecAuto() {
    if (_heroRecTimer) { clearInterval(_heroRecTimer); _heroRecTimer = null; }
}

function bindHeroRec() {
    var rec = document.getElementById('heroRec');
    if (rec && rec.dataset.recBound === '1') return;  
    stopHeroRecAuto();                                 
    if (!rec) return;
    rec.dataset.recBound = '1';

    var track = document.getElementById('heroRecTrack');
    if (!track) return;
    var slides = Array.prototype.slice.call(track.children);
    var total = slides.length;
    if (!total) return;

    var idx = parseInt(rec.dataset.start, 10);
    if (isNaN(idx) || idx < 0 || idx >= total) idx = 0;

    var prev = document.getElementById('heroRecPrev');
    var next = document.getElementById('heroRecNext');
    var wrap = rec.closest ? rec.closest('.hero-rec-wrap') : null;

    var syncNav = function() {
        var off = total < 2;
        if (prev) prev.disabled = off;
        if (next) next.disabled = off;
    };

    var syncProg = function() {
        if (!next) return;
        next.classList.remove('is-running');
        if (total < 2) return;
        void next.offsetWidth;         
        next.classList.add('is-running');
    };

    var setPaused = function(v) {
        if (wrap) wrap.classList.toggle('paused', !!v);
    };

    var show = function(n, dir) {
        if (n === idx || n < 0 || n >= total) return;
        var from = slides[idx], to = slides[n];

        to.style.transition = 'none';
        to.classList.remove('exit-up', 'exit-down');
        to.style.transform = 'translateY(' + (dir > 0 ? 100 : -100) + '%) scale(.96)';
        void to.offsetWidth; 
        to.style.transition = '';
        to.style.transform = '';

        to.classList.add('active');
        from.classList.remove('active');
        from.classList.add(dir > 0 ? 'exit-up' : 'exit-down');

        idx = n;
        syncNav();
        syncProg();
    };

    var go = function(step) {
        if (total < 2) return;
        var n = (idx + step + total) % total;  
        show(n, step);
    };

    var startAuto = function() {
        stopHeroRecAuto();
        if (total < 2) return;
        _heroRecTimer = setInterval(function() { if (document.hidden) return; go(1); }, 5000);
    };
    var restartAuto = function() { setPaused(false); startAuto(); };

    if (prev) prev.addEventListener('click', function() { go(-1); restartAuto(); });
    if (next) next.addEventListener('click', function() { go(1); restartAuto(); });
    syncNav();
    syncProg();
    startAuto();
    rec.addEventListener('mouseenter', function() { stopHeroRecAuto(); setPaused(true); });
    rec.addEventListener('mouseleave', restartAuto);
    var sx = null, sy = null;
    rec.addEventListener('touchstart', function(e) {
        if (e.touches.length !== 1) { sx = null; return; }
        sx = e.touches[0].clientX;
        sy = e.touches[0].clientY;
    }, { passive: true });
    rec.addEventListener('touchend', function(e) {
        if (sx === null) return;
        var t = e.changedTouches[0];
        var dx = t.clientX - sx, dy = t.clientY - sy;
        sx = null;
        if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy) * 1.5) go(dx < 0 ? 1 : -1);
    }, { passive: true });
}
function bindIndexLike() {
    document.querySelectorAll('.like-action:not([data-bound])').forEach(function(btn) {
        btn.dataset.bound = '1';
        btn.addEventListener('click', function() {
            var cid = btn.dataset.cid;
            if (!cid) return;
            var countEl = btn.querySelector('span');
            var iconEl = btn.querySelector('i');
            var isLiked = btn.classList.contains('liked');
            var action = isLiked ? 'undo' : 'do';
            btn.style.pointerEvents = 'none';
            fetch(location.href, {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body: 'likeup=' + cid + '&action=' + action
            })
            .then(function(r) { return r.text(); })
            .then(function(text) {
                var likes;
                try { likes = JSON.parse(text).likes; } catch(e) { likes = parseInt(text); }
                if (countEl) countEl.textContent = likes;
                if (action === 'do') {
                    btn.classList.add('liked');
                    if (iconEl) iconEl.className = 'ri-thumb-up-fill';
                    showToast('\u70b9\u8d5e\u6210\u529f', 'success');
                } else {
                    btn.classList.remove('liked');
                    if (iconEl) iconEl.className = 'ri-thumb-up-line';
                    showToast('\u5df2\u53d6\u6d88\u70b9\u8d5e', 'success');
                }
            })
            .catch(function() { showToast('\u70b9\u8d5e\u5931\u8d25', 'error'); })
            .finally(function() { btn.style.pointerEvents = ''; });
        });
    });
}
