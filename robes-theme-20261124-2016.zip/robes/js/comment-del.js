(function () {
  'use strict';

  function toast(msg, type) {
    if (typeof window.showToast === 'function') {
      window.showToast(msg, type || 'success');
    } else {
      window.alert(msg);
    }
  }

  function init() {
    var lists = [].slice.call(document.querySelectorAll('.cmt-list[data-del]'));
    if (!lists.length) return;

    var endpoint = lists[0].getAttribute('data-del');

    /* 置顶评论在分页列表中会重复出现，这里移除主列表中的副本（PJAX 后需要重新执行） */
    var mainList = document.querySelector('.cmt-list[data-pin]');
    if (mainList) {
      mainList.getAttribute('data-pin').split(',').forEach(function (coid) {
        if (!coid) return;
        var li = mainList.querySelector('li#li-comment-' + coid);
        if (li) li.remove();
      });
    }

    var buttons = [].slice.call(document.querySelectorAll('.cmt-del-btn:not([data-del-bound])'));
    var pinButtons = [].slice.call(document.querySelectorAll('.cmt-pin-btn:not([data-del-bound])'));
    if (!buttons.length && !pinButtons.length) return;

    buttons.forEach(function (b) { b.dataset.delBound = '1'; });
    pinButtons.forEach(function (b) { b.dataset.delBound = '1'; });

    var coids = buttons.map(function (b) {
      return b.getAttribute('data-coid');
    }).join(',');

    var who = new URLSearchParams();
    who.set('action', 'whoami');
    who.set('coids', coids);

    fetch(endpoint, { method: 'POST', body: who, credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (!data || !data.ok) {
          buttons.forEach(function (b) { delete b.dataset.delBound; });
          pinButtons.forEach(function (b) { delete b.dataset.delBound; });
          return;
        }
        var map = {};
        (data.items || []).forEach(function (item) {
          map[String(item.coid)] = item;
        });
        buttons.forEach(function (btn) {
          var item = map[btn.getAttribute('data-coid')];
          if (!item || !item.deletable) return;
          btn.setAttribute('data-token', data.token);
          btn.setAttribute('data-children', String(item.children || 0));
          btn.hidden = false;
        });
        if (data.admin) {
          pinButtons.forEach(function (btn) {
            btn.setAttribute('data-token', data.token);
            btn.hidden = false;
          });
        }
      })
      .catch(function () {
        buttons.forEach(function (b) { delete b.dataset.delBound; });
        pinButtons.forEach(function (b) { delete b.dataset.delBound; });
      });
  }

  /* 置顶/取消置顶后原地刷新评论区，避免整页刷新与滚动位置丢失 */
  function softRefreshComments(coid) {
    var feed = document.getElementById('feed');
    var oldLi = document.getElementById('li-comment-' + coid);
    var anchorTop = (feed && oldLi)
      ? oldLi.getBoundingClientRect().top - feed.getBoundingClientRect().top
      : null;
    var base = location.href.split('#')[0];
    var url = base + (base.indexOf('?') === -1 ? '?' : '&') + '_cmt=' + Date.now();

    fetch(url, { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) {
        if (!r.ok) throw new Error('http ' + r.status);
        return r.text();
      })
      .then(function (html) {
        var doc = new DOMParser().parseFromString(html, 'text/html');
        var fresh = doc.querySelector('.cmt-section');
        var old = document.querySelector('.cmt-section');
        if (!fresh || !old) throw new Error('no comment section');
        old.parentNode.replaceChild(document.importNode(fresh, true), old);

        if (typeof bindCommentForm === 'function') bindCommentForm();
        if (typeof bindCommentExtras === 'function') bindCommentExtras();

        var newLi = document.getElementById('li-comment-' + coid);
        if (feed && newLi && anchorTop !== null) {
          var newTop = newLi.getBoundingClientRect().top - feed.getBoundingClientRect().top;
          feed.scrollTop += newTop - anchorTop;
        }
      })
      .catch(function () {
        window.setTimeout(function () { location.reload(); }, 200);
      });
  }

  window.robesInitCommentDel = init;

  if (!document.documentElement.dataset.cmtDelBound) {
    document.documentElement.dataset.cmtDelBound = '1';

    document.addEventListener('click', function (ev) {
      var target = ev.target;

      var pinBtn = target && target.closest ? target.closest('.cmt-pin-btn') : null;
      if (pinBtn) {
        if (pinBtn.hidden) {
          toast('置顶按钮尚未就绪：请确认已登录管理员账号后刷新页面', 'error');
          return;
        }
        if (pinBtn.disabled) return;
        ev.preventDefault();
        ev.stopPropagation();

        var pinned = pinBtn.getAttribute('data-pinned') === '1';
        var action = pinned ? 'unpin' : 'pin';
        pinBtn.disabled = true;

        var endpoint = pinBtn.closest('.cmt-list') ? pinBtn.closest('.cmt-list').getAttribute('data-del') : '';
        if (!endpoint) {
          pinBtn.disabled = false;
          return;
        }

        var pinPayload = new URLSearchParams();
        pinPayload.set('action', action);
        pinPayload.set('coid', pinBtn.getAttribute('data-coid'));
        pinPayload.set('token', pinBtn.getAttribute('data-token') || '');

        fetch(endpoint, { method: 'POST', body: pinPayload, credentials: 'same-origin', cache: 'no-store' })
          .then(function (r) { return r.json(); })
          .then(function (res) {
            if (!res || !res.ok) {
              pinBtn.disabled = false;
              toast((res && res.message) || '操作失败，请稍后再试', 'error');
              return;
            }
            toast(res.pinned ? '已置顶该评论' : '已取消置顶', 'success');
            if (typeof clearPageCache === 'function') clearPageCache(location.href);
            softRefreshComments(pinBtn.getAttribute('data-coid'));
          })
          .catch(function () {
            pinBtn.disabled = false;
            toast('网络异常，请稍后再试', 'error');
          });
        return;
      }

      var btn = target && target.closest ? target.closest('.cmt-del-btn') : null;
      if (!btn) return;
      if (btn.hidden) {
        window.alert('删除按钮尚未就绪：请确认已登录，并刷新页面重试');
        return;
      }
      if (btn.disabled) return;
      ev.preventDefault();
      ev.stopPropagation();

      var endpoint2 = btn.closest('.cmt-list') ? btn.closest('.cmt-list').getAttribute('data-del') : '';
      if (!endpoint2) return;

      var children = parseInt(btn.getAttribute('data-children') || '0', 10);
      var msg = children > 0
        ? '该评论有 ' + children + ' 条回复，删除后将一并移除，确认删除？'
        : '确认删除这条评论？';
      if (!window.confirm(msg)) return;

      btn.disabled = true;

      var payload = new URLSearchParams();
      payload.set('action', 'delete');
      payload.set('coid', btn.getAttribute('data-coid'));
      payload.set('token', btn.getAttribute('data-token') || '');

      fetch(endpoint2, { method: 'POST', body: payload, credentials: 'same-origin', cache: 'no-store' })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (!res || !res.ok) {
            btn.disabled = false;
            window.alert((res && res.message) || '删除失败，请稍后再试');
            return;
          }

          var li = btn.closest('li.cmt-item');
          var removed = li ? li.querySelectorAll('li.cmt-item').length + 1 : 1;

          if (li) {
            li.style.transition = 'opacity .22s ease';
            li.style.opacity = '0';
            window.setTimeout(function () {
              if (!li.parentNode) return;
              var ol = li.parentNode;
              ol.removeChild(li);
              if (ol.classList.contains('cmt-pinned-list') && !ol.querySelector('li.cmt-item')) {
                var box = document.getElementById('cmt-pinned');
                if (box) box.style.display = 'none';
              }
            }, 220);
          }

          var title = document.querySelector('.cmt-title');
          if (title) {
            title.innerHTML = title.innerHTML.replace(/(\d+)(\s*条评论)/, function (all, n, tail) {
              var left = parseInt(n, 10) - removed;
              return left > 0 ? left + tail : '暂无评论';
            });
          }
        })
        .catch(function () {
          btn.disabled = false;
          window.alert('网络异常，请稍后再试');
        });
    });
  }

  init();
})();
