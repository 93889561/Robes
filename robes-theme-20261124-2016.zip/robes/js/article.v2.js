/* Robes 文章模块：灯箱 / 评论 / 目录 / 代码工具 / 音乐卡片 */
function _lbEls() {
    return {
        box: document.getElementById('lightbox'),
        stage: document.getElementById('lightboxStage'),
        img: document.getElementById('lightboxImg'),
        preview: document.getElementById('lightboxPreview'),
        cap: document.getElementById('lightboxCaption'),
        ctr: document.getElementById('lightboxCounter'),
        thumbs: document.getElementById('lightboxThumbs'),
        prev: document.getElementById('lightboxPrev'),
        next: document.getElementById('lightboxNext'),
        dl: document.getElementById('lightboxDownload')
    };
}

function _lbItem(im) {
    return {
        src: im.getAttribute('data-original') || im.currentSrc || im.getAttribute('src') || im.src,
        thumb: im.getAttribute('data-thumb') || '',
        caption: (im.getAttribute('alt') || '').trim()
    };
}

function _lbCollect(cell) {
    var imgs, grid = cell.closest ? cell.closest('.photo-grid') : null;
    if (grid) {
        imgs = Array.prototype.slice.call(grid.querySelectorAll('.photo-item img, .photo-single img'));
    } else if (cell.tagName === 'IMG' && cell.closest('.article-content')) {
        imgs = Array.prototype.slice.call(document.querySelectorAll('.article-content img')).filter(function(i) {
            return !i.closest('.photo-item, .photo-single, .photo-grid');
        });
    } else {
        var only = cell.tagName === 'IMG' ? cell : (cell.querySelector('img') || cell);
        imgs = [only];
    }
    var start = 0;
    if (cell.tagName === 'IMG') start = imgs.indexOf(cell);
    else { var inner = cell.querySelector('img'); start = inner ? imgs.indexOf(inner) : 0; }
    return { items: imgs.map(_lbItem), start: Math.max(0, start) };
}

function _lbApply() {
    var el = _lbEls();
    if (!el.img) return;
    el.img.style.transform = 'translate3d(' + LB.tx + 'px,' + LB.ty + 'px,0) rotate(' + LB.rot + 'deg) scale(' + LB.scale + ')';
    if (el.box) el.box.classList.toggle('zoomed', LB.scale > 1.01);
    var zv = document.getElementById('lightboxZoomVal');
    if (zv) zv.textContent = Math.round(LB.scale * 100) + '%';
    var rb = document.getElementById('lightboxRotate');
    if (rb) rb.classList.toggle('is-active', (LB.rot % 360) !== 0);
}

function _lbClamp() {
    var el = _lbEls();
    if (!el.img) return;
    if (LB.scale <= 1.001) { LB.scale = 1; LB.tx = 0; LB.ty = 0; return; }
    var r = el.img.getBoundingClientRect();
    var maxX = Math.max(0, (r.width - window.innerWidth) / 2 + 60);
    var maxY = Math.max(0, (r.height - window.innerHeight) / 2 + 60);
    LB.tx = Math.max(-maxX, Math.min(maxX, LB.tx));
    LB.ty = Math.max(-maxY, Math.min(maxY, LB.ty));
}

function _lbZoomAt(newScale, cx, cy) {
    var el = _lbEls();
    if (!el.img) return;
    newScale = Math.max(1, Math.min(6, newScale));
    if (Math.abs(newScale - LB.scale) < 0.001) return;
    /* 旋转状态下指针缩放同样成立：transform 链是 translate→rotate→scale，
       缩放以指针为锚点时旋转项会被约掉，所以不用退化成"绕中心缩放" */
    if (typeof cx !== 'number') {
        LB.scale = newScale;
        if (LB.scale <= 1.001) { LB.scale = 1; LB.tx = 0; LB.ty = 0; }
        _lbClamp(); _lbApply(); return;
    }
    var r = el.img.getBoundingClientRect();
    var c0x = (r.left + r.width / 2) - LB.tx;
    var c0y = (r.top + r.height / 2) - LB.ty;
    var ratio = newScale / LB.scale;
    LB.tx = (cx - c0x) - ratio * ((cx - c0x) - LB.tx);
    LB.ty = (cy - c0y) - ratio * ((cy - c0y) - LB.ty);
    LB.scale = newScale;
    if (LB.scale <= 1.001) { LB.scale = 1; LB.tx = 0; LB.ty = 0; }
    _lbClamp(); _lbApply();
}

function _lbRotate() {
    LB.rot = (LB.rot + 90) % 360;
    LB.scale = 1; LB.tx = 0; LB.ty = 0;
    _lbApply();
}

function _lbBuildThumbs() {
    var el = _lbEls();
    if (!el.thumbs) return;
    if (LB.items.length < 2) { el.thumbs.innerHTML = ''; return; }
    el.thumbs.innerHTML = '';
    LB.items.forEach(function(it, i) {
        var b = document.createElement('div');
        b.className = 'lightbox-thumb' + (i === LB.idx ? ' active' : '');
        var t = document.createElement('img');
        t.src = it.thumb || it.src; t.alt = ''; t.loading = 'lazy';
        b.appendChild(t);
        b.addEventListener('click', function(e) {
            e.stopPropagation();
            var dir = i > LB.idx ? 1 : (i < LB.idx ? -1 : 0);
            LB.idx = i; _lbRender(dir);
        });
        el.thumbs.appendChild(b);
    });
    var act = el.thumbs.querySelector('.lightbox-thumb.active');
    if (act && act.scrollIntoView) act.scrollIntoView({ block: 'nearest', inline: 'center' });
}

function _lbPrefetch() {
    if (LB.items.length < 2) return;
    LB._prefetch = LB._prefetch || [];
    [1, -1].forEach(function(d) {
        var n = LB.items[(LB.idx + d + LB.items.length) % LB.items.length];
        if (n && n.src) {
            var im = new Image();
            im.src = n.src;
            LB._prefetch.push(im);            // 保留引用，避免被垃圾回收导致不预载
            if (LB._prefetch.length > 8) LB._prefetch.shift();
        }
    });
}

function _lbSlide(dir) {
    var el = _lbEls();
    if (!el.img || !dir) return;
    var cls = dir > 0 ? 'lb-slide-right' : 'lb-slide-left';
    el.img.classList.remove('lb-slide-right', 'lb-slide-left');
    void el.img.offsetWidth;   
    el.img.classList.add(cls);
}

function _lbShowItem(img, item, token, dir, cached) {
    var done = false;
    var started = Date.now();

    function apply() {
        if (token !== LB.token) return;
        var el = _lbEls();
        if (el.box) el.box.classList.remove('no-anim', 'is-error');
        void img.offsetWidth;
        img.classList.remove('lb-loading');
        if (el.preview) el.preview.classList.remove('is-on');
        if (el.box) el.box.classList.remove('is-loading');
        /* 打开灯箱的首张图做一次渐入放大 */
        if (LB._openPending) {
            LB._openPending = false;
            img.classList.remove('lb-open-in');
            void img.offsetWidth;
            img.classList.add('lb-open-in');
        }
        _lbSlide(dir);
        _lbPrefetch();
    }

    /* 加载失败：不要停在一片空白，给提示和重试入口 */
    function fail() {
        if (token !== LB.token) return;
        var el = _lbEls();
        if (el.box) {
            el.box.classList.remove('is-loading');
            el.box.classList.add('is-error');
        }
        img.classList.remove('lb-loading');
        if (el.preview) el.preview.classList.remove('is-on');
    }

    /* 已在缓存里：直接显示，不出现加载动画 */
    if (cached) { apply(); return; }

    function finish() {
        if (done) return;
        done = true;
        img.removeEventListener('load', finish);
        img.removeEventListener('error', finish);
        if (token !== LB.token) return;
        if (!img.naturalWidth) { fail(); return; }
        var elapsed = Date.now() - started;
        /* 缓存命中（瞬间完成）直接显示；真正联网加载时才让动画至少停留 220ms */
        if (elapsed < 60) { apply(); return; }
        setTimeout(apply, Math.max(0, 220 - elapsed));
    }
    img.addEventListener('load', finish);
    img.addEventListener('error', finish);
    /* complete 为真但没有宽高 = 这张图已经失败过（缓存的错误结果） */
    if (img.complete) finish();
}

function _lbRender(dir) {
    var el = _lbEls();
    if (!el.box || !el.img) return;
    var item = LB.items[LB.idx];
    if (!item) return;

    LB.scale = 1; LB.tx = 0; LB.ty = 0; LB.rot = 0;
    el.box.classList.add('no-anim');
    _lbApply();

    var token = (LB.token = LB.token + 1);
    var cached = false;

    el.box.classList.remove('is-loading', 'is-error');
    el.img.classList.remove('lb-loading');
    el.img.setAttribute('alt', item.caption || '');
    el.img.src = item.src;
    cached = el.img.complete && el.img.naturalWidth > 0;

    if (!cached) {
        el.box.classList.add('is-loading');
        el.img.classList.add('lb-loading');
    }

    /* 原图未到之前，先铺一层模糊小图 */
    if (el.preview) {
        if (cached) {
            el.preview.classList.remove('is-on');
        } else {
            el.preview.src = item.thumb || item.src;
            el.preview.classList.add('is-on');
        }
    }

    _lbShowItem(el.img, item, token, dir, cached);

    if (el.cap) el.cap.textContent = item.caption || '';
    var multi = LB.items.length > 1;
    if (el.ctr) el.ctr.textContent = multi ? (LB.idx + 1) + ' / ' + LB.items.length : '';
    if (el.prev) el.prev.style.display = multi ? 'flex' : 'none';
    if (el.next) el.next.style.display = multi ? 'flex' : 'none';
    if (el.dl) el.dl.href = item.src;
    _lbBuildThumbs();
}

function _lbOpen(items, start) {
    var el = _lbEls();
    if (!el.box || !items || !items.length) return;
    LB.items = items;
    LB.idx = Math.max(0, Math.min(items.length - 1, start || 0));
    LB.active = true;
    LB._openPending = true;
    el.box.classList.add('active');
    el.box.setAttribute('aria-hidden', 'false');
    document.body.classList.add('lb-open');
    _lbRender();
}

function _lbClose() {
    var el = _lbEls();
    if (!el.box) return;
    LB.active = false;
    LB.token = LB.token + 1;   
    el.box.classList.remove('active', 'zoomed', 'dragging', 'pinching', 'is-loading', 'is-error');
    el.box.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('lb-open');
    if (el.img) { el.img.style.transform = ''; el.img.classList.remove('lb-loading'); el.img.removeAttribute('src'); }
    if (el.preview) { el.preview.classList.remove('is-on'); el.preview.removeAttribute('src'); }
    LB.scale = 1; LB.tx = 0; LB.ty = 0; LB.rot = 0;
    LB.items = []; LB.idx = 0;
}

function _lbGo(step) {
    if (LB.items.length < 2) return;
    LB.idx = (LB.idx + step + LB.items.length) % LB.items.length;
    _lbRender(step);
}

function _lbFileName(url) {
    try {
        var u = new URL(url, location.href);
        var name = decodeURIComponent(u.pathname.split('/').pop() || '');
        if (!name || name.indexOf('.') === -1) name = 'image-' + Date.now() + '.jpg';
        return name;
    } catch (_e) { return 'image-' + Date.now() + '.jpg'; }
}

function _lbDownload() {
    var item = LB.items[LB.idx];
    if (!item) return;
    var name = _lbFileName(item.src);
    var save = function(url, revoke) {
        var a = document.createElement('a');
        a.href = url; a.download = name;
        document.body.appendChild(a); a.click(); a.remove();
        if (revoke) setTimeout(function() { URL.revokeObjectURL(url); }, 5000);
        showToast('图片已开始下载', 'success');
    };
    if (typeof fetch === 'function') {
        fetch(item.src, { mode: 'cors' })
            .then(function(r) { if (!r.ok) throw 0; return r.blob(); })
            .then(function(b) { save(URL.createObjectURL(b), true); })
            .catch(function() {
                window.open(item.src, '_blank', 'noopener');
                showToast('已在新窗口打开原图', 'success');
            });
    } else {
        window.open(item.src, '_blank', 'noopener');
    }
}

function _lbDist(t) {
    var dx = t[0].clientX - t[1].clientX, dy = t[0].clientY - t[1].clientY;
    return Math.sqrt(dx * dx + dy * dy);
}
function _lbMid(t) {
    return { x: (t[0].clientX + t[1].clientX) / 2, y: (t[0].clientY + t[1].clientY) / 2 };
}

function _lbBindGlobal() {
    if (LB.globalBound) return;
    var el = _lbEls();
    if (!el.box || !el.stage || !el.img) return;
    LB.globalBound = true;

    document.addEventListener('keydown', function(e) {
        if (!LB.active) return;
        var k = e.key;
        if (k === 'Escape') { e.preventDefault(); _lbClose(); }
        else if (k === 'ArrowLeft') { e.preventDefault(); _lbGo(-1); }
        else if (k === 'ArrowRight') { e.preventDefault(); _lbGo(1); }
        else if (k === '+' || k === '=') { e.preventDefault(); _lbZoomAt(LB.scale * 1.3); }
        else if (k === '-' || k === '_') { e.preventDefault(); _lbZoomAt(LB.scale / 1.3); }
        else if (k === '0') { e.preventDefault(); LB.scale = 1; LB.tx = 0; LB.ty = 0; LB.rot = 0; _lbApply(); }
        else if (k === 'r' || k === 'R') { e.preventDefault(); _lbRotate(); }
        else if (k === 'd' || k === 'D') { e.preventDefault(); _lbDownload(); }
    });

    document.addEventListener('wheel', function(e) {
        if (!LB.active) return;
        if (!el.stage.contains(e.target)) return;
        e.preventDefault();
        _lbZoomAt(LB.scale * (e.deltaY < 0 ? 1.18 : 1 / 1.18), e.clientX, e.clientY);
    }, { passive: false });

    el.box.addEventListener('click', function(e) {
        if (e.target === el.box || e.target === el.stage) _lbClose();
    });

    el.img.addEventListener('dblclick', function(e) {
        e.preventDefault();
        if (LB.scale > 1.01) { LB.scale = 1; LB.tx = 0; LB.ty = 0; _lbApply(); }
        else _lbZoomAt(2.5, e.clientX, e.clientY);
    });

    el.img.addEventListener('mousedown', function(e) {
        if (LB.scale <= 1) return;
        e.preventDefault();
        LB.drag = { x: e.clientX, y: e.clientY, tx: LB.tx, ty: LB.ty };
        el.box.classList.add('dragging');
    });
    document.addEventListener('mousemove', function(e) {
        if (!LB.drag) return;
        LB.tx = LB.drag.tx + (e.clientX - LB.drag.x);
        LB.ty = LB.drag.ty + (e.clientY - LB.drag.y);
        _lbClamp(); _lbApply();
    });
    document.addEventListener('mouseup', function() {
        if (!LB.drag) return;
        LB.drag = null;
        el.box.classList.remove('dragging');
    });

    el.stage.addEventListener('touchstart', function(e) {
        if (e.touches.length === 2) {
            LB.pinch = { d: _lbDist(e.touches), s: LB.scale };
            LB.swipe = null;
            el.box.classList.add('pinching');
        } else if (e.touches.length === 1) {
            var t = e.touches[0];
            LB.swipe = { x: t.clientX, y: t.clientY, tx: LB.tx, ty: LB.ty, moved: false };
        }
    }, { passive: true });

    el.stage.addEventListener('touchmove', function(e) {
        if (e.touches.length === 2 && LB.pinch) {
            e.preventDefault();
            var mid = _lbMid(e.touches);
            _lbZoomAt(LB.pinch.s * (_lbDist(e.touches) / LB.pinch.d), mid.x, mid.y);
        } else if (e.touches.length === 1 && LB.swipe) {
            var t = e.touches[0];
            var dx = t.clientX - LB.swipe.x, dy = t.clientY - LB.swipe.y;
            if (Math.abs(dx) > 6 || Math.abs(dy) > 6) LB.swipe.moved = true;
            if (LB.scale > 1) {
                e.preventDefault();
                LB.tx = LB.swipe.tx + dx;
                LB.ty = LB.swipe.ty + dy;
                _lbClamp(); _lbApply();
            } else if (LB.swipe.moved) {
                /* 未放大时也跟手：图片贴着手指走，松手再决定切换还是回弹 */
                e.preventDefault();
                el.box.classList.add('dragging');
                LB.tx = dx;
                LB.ty = dy * 0.22;
                _lbApply();
            }
        }
    }, { passive: false });

    el.stage.addEventListener('touchend', function(e) {
        if (LB.pinch && e.touches.length < 2) {
            LB.pinch = null;
            el.box.classList.remove('pinching');
            if (LB.scale <= 1.01) { LB.scale = 1; LB.tx = 0; LB.ty = 0; _lbApply(); }
        }
        if (LB.swipe && e.touches.length === 0) {
            var s = LB.swipe;
            LB.swipe = null;
            el.box.classList.remove('dragging');
            if (LB.scale <= 1 && s.moved && e.changedTouches[0]) {
                var dx = e.changedTouches[0].clientX - s.x;
                var dy = e.changedTouches[0].clientY - s.y;
                if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.5) {
                    /* 切换：先无过渡归位，交给切换动画 */
                    el.box.classList.add('no-anim');
                    LB.tx = 0; LB.ty = 0;
                    _lbApply();
                    _lbGo(dx < 0 ? 1 : -1);
                } else {
                    /* 没到阈值：带过渡弹回原位 */
                    LB.tx = 0; LB.ty = 0;
                    _lbApply();
                }
            } else if (LB.tx || LB.ty) {
                /* 没到阈值：带过渡弹回原位 */
                LB.tx = 0; LB.ty = 0;
                _lbApply();
            }
        }
    }, { passive: true });
}

function _lbBindControls() {
    var on = function(id, fn) {
        var el = document.getElementById(id);
        if (el) el.onclick = function(e) { e.preventDefault(); e.stopPropagation(); fn(); };
    };
    var lbImg = _lbEls().img;
    if (lbImg) lbImg.addEventListener('animationend', function() {
        lbImg.classList.remove('lb-slide-right', 'lb-slide-left', 'lb-open-in');
    });
    on('lightboxRetry', function() {
        var el2 = _lbEls();
        if (!el2.img) return;
        el2.box.classList.remove('is-error');
        /* 先摘掉 src 再设回来，强制重新请求（不让缓存里的失败结果挡住重试） */
        el2.img.removeAttribute('src');
        void el2.img.offsetWidth;
        _lbRender(0);
    });
    on('lightboxZoomIn', function() { _lbZoomAt(LB.scale * 1.3); });
    on('lightboxZoomOut', function() { _lbZoomAt(LB.scale / 1.3); });
    on('lightboxReset', function() { LB.scale = 1; LB.tx = 0; LB.ty = 0; LB.rot = 0; _lbApply(); });
    on('lightboxRotate', _lbRotate);
    on('lightboxClose', _lbClose);
    on('lightboxDownload', _lbDownload);
    on('lightboxPrev', function() { _lbGo(-1); });
    on('lightboxNext', function() { _lbGo(1); });
}

function bindLightbox() {
    if (typeof ROBES === 'undefined' || !ROBES.enableLightbox) return;
    if (!document.getElementById('lightbox')) return;
    _lbBindGlobal();
    _lbBindControls();

    var isIndex = document.body.dataset.page === 'index';
    if (!isIndex) {
        document.querySelectorAll('.img-cell:not([data-lb]), .photo-item:not([data-lb]), .photo-single:not([data-lb])').forEach(function(cell) {
            cell.dataset.lb = '1';
            cell.addEventListener('click', function() {
                var g = _lbCollect(cell);
                _lbOpen(g.items, g.start);
            });
        });
    }
    document.querySelectorAll('.article-content img:not([data-lb])').forEach(function(img) {
        if (img.closest('.photo-item, .photo-single, .photo-grid')) return;
        if (img.closest('.post-music, .post-ref')) return;
        img.dataset.lb = '1';
        img.style.cursor = 'pointer';
        img.addEventListener('click', function() {
            var g = _lbCollect(img);
            _lbOpen(g.items, g.start);
        });
    });
}
// ── 评论无感验证（PoW + 行为信号 + 蜜罐） ──
var VF = (function() {
    var MIN_WAIT = 1200;     
    var SOLVE_TIMEOUT = 30000;
    var s = {
        token: '', nonce: '', difficulty: 4, proof: '',
        ready: false, bot: false, startedAt: 0, beh: 0, pending: null
    };
    var sigBound = false;

    function base() {
        return (window.ROBES && ROBES.themeUrl) ? ROBES.themeUrl.replace(/\/+$/, '') : '';
    }

    function pill(text, state) {
        var el = document.getElementById('vf-pill');
        if (!el) return;
        var t = el.querySelector('.vf-text');
        if (t) t.textContent = text;
        el.setAttribute('data-state', state || 'idle');
    }

    function needed(form) {
        return !!(form && form.querySelector && form.querySelector('input[name="vf_token"]'));
    }

    function bindSignals() {
        if (sigBound) return;
        sigBound = true;
        var bump = function() { if (s.beh < 9999) s.beh++; };
        ['mousemove', 'mousedown', 'pointermove', 'keydown', 'touchstart', 'scroll'].forEach(function(ev) {
            document.addEventListener(ev, bump, { passive: true, capture: true });
        });
        try { if (navigator.webdriver === true) s.bot = true; } catch (e) {}
    }

    function solveInWorker(nonce, difficulty) {
        return new Promise(function(resolve, reject) {
            var w;
            try { w = new Worker(base() + '/js/pow-worker.js'); }
            catch (e) { reject(e); return; }
            var done = false;
            var timer = setTimeout(function() {
                if (done) return;
                done = true;
                try { w.terminate(); } catch (e) {}
                reject(new Error('timeout'));
            }, SOLVE_TIMEOUT);
            w.onmessage = function(ev) {
                var d = ev.data || {};
                if (d.type === 'progress') { pill('正在验证…', 'solving'); return; }
                if (done) return;
                if (d.type === 'solved') {
                    done = true; clearTimeout(timer);
                    try { w.terminate(); } catch (e) {}
                    resolve(d.result && d.result.proof);
                } else if (d.type === 'error') {
                    done = true; clearTimeout(timer);
                    try { w.terminate(); } catch (e) {}
                    reject(new Error(d.message || 'worker'));
                }
            };
            w.onerror = function() {
                if (done) return;
                done = true; clearTimeout(timer);
                try { w.terminate(); } catch (e) {}
                reject(new Error('worker'));
            };
            w.postMessage({ cmd: 'solve', nonce: nonce, difficulty: difficulty });
        });
    }

    /** Worker 不可用时的降级：用 WebCrypto 分批计算，避免阻塞主线程 */
    function solveInMain(nonce, difficulty) {
        return new Promise(function(resolve, reject) {
            if (!window.crypto || !crypto.subtle || !window.TextEncoder) { reject(new Error('no crypto')); return; }
            var prefix = '';
            for (var i = 0; i < Math.max(1, difficulty); i++) prefix += '0';
            var enc = new TextEncoder();
            var t0 = Date.now();
            var counter = 0;
            var BATCH = 64;
            function loop() {
                var n = 0;
                function one() {
                    var p = String(counter++);
                    crypto.subtle.digest('SHA-256', enc.encode(nonce + p)).then(function(buf) {
                        var arr = new Uint8Array(buf), hex = '';
                        for (var i = 0; i < arr.length; i++) hex += (arr[i] < 16 ? '0' : '') + arr[i].toString(16);
                        if (hex.indexOf(prefix) === 0) { resolve(p); return; }
                        if (++n >= BATCH) {
                            if (Date.now() - t0 > SOLVE_TIMEOUT) { reject(new Error('timeout')); return; }
                            pill('正在验证…', 'solving');
                            setTimeout(loop, 0);
                        } else { one(); }
                    }, reject);
                }
                one();
            }
            loop();
        });
    }

    function solve(nonce, difficulty) {
        if (typeof Worker === 'undefined') return solveInMain(nonce, difficulty);
        return solveInWorker(nonce, difficulty).catch(function() { return solveInMain(nonce, difficulty); });
    }

    function ensure() {
        if (s.ready && s.proof) return Promise.resolve();
        if (s.pending) return s.pending;
        if (s.bot) { pill('环境异常', 'fail'); return Promise.reject(new Error('bot')); }

        pill('正在验证…', 'solving');
        s.startedAt = Date.now();

        s.pending = fetch(base() + '/verify/verify.php?action=challenge', { credentials: 'same-origin', cache: 'no-store' })
            .then(function(r) { return r.json(); })
            .then(function(d) {
                if (!d || !d.ok || !d.token) throw new Error('challenge');
                s.token = d.token;
                s.nonce = d.nonce;
                s.difficulty = d.difficulty || 4;
                return solve(s.nonce, s.difficulty);
            })
            .then(function(proof) {
                if (!proof) throw new Error('proof');
                var wait = MIN_WAIT - (Date.now() - s.startedAt);
                return new Promise(function(res) { setTimeout(res, wait > 0 ? wait : 0); }).then(function() { return proof; });
            })
            .then(function(proof) {
                s.proof = proof;
                s.ready = true;
                pill('已就绪', 'ok');
            })
            .catch(function(err) {
                s.pending = null;
                pill('验证失败', 'fail');
                throw err;
            });
        return s.pending;
    }

    function attach(form) {
        if (!needed(form)) return;
        if (form.dataset.vfBound) return;
        form.dataset.vfBound = '1';
        bindSignals();
        s.token = ''; s.nonce = ''; s.proof = ''; s.ready = false; s.pending = null; s.startedAt = 0;
        ensure().catch(function() {});
    }

    function fill(form) {
        if (!needed(form)) return;
        var set = function(name, val) {
            var el = form.querySelector('input[name="' + name + '"]');
            if (el) el.value = val == null ? '' : String(val);
        };
        set('vf_token', s.token);
        set('vf_proof', s.proof);
        set('vf_elapsed', s.startedAt ? Date.now() - s.startedAt : 0);
        set('vf_beh', s.beh);
    }

    function invalidate(form) {
        if (!needed(form)) return;
        s.token = ''; s.proof = ''; s.ready = false; s.pending = null; s.startedAt = 0;
        pill('正在验证…', 'solving');
        ensure().catch(function() {});
    }

    return {
        needed: needed,
        attach: attach,
        prepare: ensure,
        fill: fill,
        invalidate: invalidate,
        isReady: function() { return s.ready && !!s.proof; }
    };
})();

var _commentSubmitting = false;

document.addEventListener('submit', function(e) {
    var form = e.target;
    if (!form || form.id !== 'comment-form') return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    doCommentSubmit(form);
}, true);

/* Ctrl / Cmd + Enter 提交，与表单上的快捷键提示保持一致 */
document.addEventListener('keydown', function(e) {
    if (e.key !== 'Enter' || !(e.ctrlKey || e.metaKey)) return;
    var form = e.target && e.target.form;
    if (!form || form.id !== 'comment-form') return;
    e.preventDefault();
    if (typeof form.requestSubmit === 'function') form.requestSubmit();
    else doCommentSubmit(form);
});

/**
 * 友链申请提交：走主题独立接口 links-apply.php，返回 JSON，不写评论
 */
function robesApplySubmit(form) {
    var btn = form.querySelector('#comment-submit');
    var orig = btn ? btn.innerHTML : '';
    _commentSubmitting = true;
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="ri-loader-4-line"></i> 提交中…'; }

    fetch(form.getAttribute('action'), {
        method: 'POST',
        body: new FormData(form),
        credentials: 'same-origin',
        cache: 'no-store',
        headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
    }).then(function(r) {
        return r.json();
    }).then(function(res) {
        if (!res || !res.ok) {
            showToast((res && res.message) || '提交失败，请稍后重试', 'error');
            return;
        }
        var done = document.getElementById('applyDone');
        form.reset();
        form.hidden = true;
        if (done) done.hidden = false;
        showToast(res.message || '提交成功', 'success');
    }).catch(function() {
        showToast('网络错误，请稍后重试', 'error');
    }).finally(function() {
        if (btn) { btn.disabled = false; btn.innerHTML = orig; }
        _commentSubmitting = false;
    });
}

/**
 * Typecho 评论提交流程（全面排查版）
 *
 * Typecho comment action 行为：
 *   成功 → 302 重定向到文章页
 *   失败 → 200 返回带错误信息的 HTML 页面
 *
 * 关键判断逻辑：
 *   1. response.url ≠ action → 浏览器跟了重定向 → Typecho 走了 302 → 评论成功
 *   2. response.url = action → Typecho 没有重定向 → 需要检查是否有错误
 *   3. 如果没有检测到任何错误信息但 Typecho 也没重定向 → 可能是评论被过滤/静默拒绝
 */
function doCommentSubmit(form) {
    if (_commentSubmitting) return;

    if (form.getAttribute('data-apply-mode') === '1') {
        robesApplySubmit(form);
        return;
    }

    var ta = form.querySelector('textarea[name="text"]');
    var text = ta ? ta.value.trim() : '';
    if (!text) { showToast('请输入评论内容', 'error'); if (ta) ta.focus(); return; }

    /* 网址（个人主页）服务端为必填项，提前拦截，避免用户只看到 HTTP 500 */
    var urlInput = form.querySelector('input[name="url"]');
    if (urlInput && !urlInput.value.trim()) {
        showToast('请填写网址（个人主页），该字段为必填项', 'error');
        urlInput.focus();
        return;
    }

    if (VF.needed(form) && !VF.isReady()) {
        var vbtn = form.querySelector('#comment-submit');
        var vorig = vbtn ? vbtn.innerHTML : '';
        if (vbtn) { vbtn.innerHTML = '<i class="ri-shield-check-line"></i> 验证中…'; vbtn.disabled = true; }
        VF.prepare(form).then(function() {
            if (vbtn) { vbtn.innerHTML = vorig; vbtn.disabled = false; }
            doCommentSubmit(form);
        }, function() {
            if (vbtn) { vbtn.innerHTML = vorig; vbtn.disabled = false; }
            showToast('人机验证未通过，请刷新页面后重试', 'error');
        });
        return;
    }

    _commentSubmitting = true;
    var savedText = text;
    var btn = form.querySelector('#comment-submit');
    var orig = btn ? btn.innerHTML : '';
    if (btn) { btn.style.minWidth = btn.offsetWidth + 'px'; btn.innerHTML = '<i class="ri-loader-4-line ri-spin"></i> 提交中…'; btn.disabled = true; }

    if (VF.needed(form)) VF.fill(form);

    var fd = new FormData(form);
    var action = form.getAttribute('action');
    if (!action || action === '#') action = location.href;

    fetch(action, { method: 'POST', body: fd, credentials: 'same-origin' })
    .then(function(response) {

        if (!response.ok) {
            return response.text().then(function(html) {
                var ct0 = (response.headers && response.headers.get) ? response.headers.get('content-type') || '' : '';
                var msg = '';
                if (ct0.indexOf('json') !== -1) {
                    try {
                        var jd = JSON.parse(html);
                        msg = jd.message || jd.error || jd.msg || '';
                    } catch (_je) {}
                }
                showToast(msg || _extractErrMsg(html) || '提交失败，请检查昵称、邮箱、网址是否都已填写', 'error');
                if (ta) ta.value = savedText;
                VF.invalidate(form);
            });
        }

        var ct = (response.headers && response.headers.get) ? response.headers.get('content-type') || '' : '';
        if (ct.indexOf('json') !== -1) {
            return response.json().then(function(data) {
                var errMsg = data.message || data.error || data.msg || data.reason || '';
                if (!errMsg && (data.success === false || (data.code && data.code !== 0))) errMsg = '评论提交失败';
                if (errMsg) {
                    showToast(errMsg, 'error');
                    if (ta) ta.value = savedText;
                    VF.invalidate(form);
                } else {
                    _commentSuccess(ta, '', form);
                }
            });
        }

        return response.text().then(function(html) {
            var redirected = false;
            try {
                var respUrl = response.url || '';
                var actPath = _normalizeUrl(action);
                var respPath = _normalizeUrl(respUrl);
                redirected = respPath && actPath && respPath !== actPath;
            } catch(_e) {}

            if (redirected) {
                _commentSuccess(ta, response.url || '', form);
                return;
            }

            var isActionFallback = (action === location.href || action === location.pathname);
            var errMsg = _extractErrMsg(html);

            if (errMsg) {
                showToast(errMsg, 'error');
                if (ta) ta.value = savedText;
                VF.invalidate(form);
            } else if (isActionFallback) {
                /* action 是文章页 URL（fallback），无法通过 URL 判断，
                   但没检测到错误 → 大概率成功（Typecho 可能用了 meta refresh 等非标准重定向） */
                _commentSuccess(ta, '', form);
            } else if (form && form.getAttribute('data-apply-mode') === '1') {
                _commentSuccess(ta, '', form);
            } else {
                showToast('评论已提交，若未显示请刷新页面', 'success');
                if (ta) ta.value = '';
                setTimeout(function() {
                    if (typeof clearPageCache === 'function') clearPageCache(location.href);
                    location.reload();
                }, 2200);
            }
        });
    })
    .catch(function() {
        showToast('网络错误，请重试', 'error');
        if (ta) ta.value = savedText;
    })
    .finally(function() {
        if (btn) { btn.innerHTML = orig; btn.disabled = false; btn.style.minWidth = ''; }
        _commentSubmitting = false;
    });
}

function _commentSuccess(ta, targetUrl, form) {
    /* 以「提交的表单」判断是否为友链申请，避免 pjax 遗留的申请弹窗把普通评论/回复误判成申请 */
    var isApply = !!(form && form.getAttribute('data-apply-mode') === '1');
    if (isApply) {
        showToast('友链申请已提交，审核通过后将展示在友链列表~', 'success');
        if (ta) ta.value = '';
        if (typeof window.closeApplyModal === 'function') window.closeApplyModal();
        return;
    }
    showToast('评论已提交，感谢您的留言！', 'success');
    if (ta) ta.value = '';
    /* 自己的评论已经落库：让铃铛丢掉旧缓存，并立刻认领游客身份 */
    if (typeof window.noticeAfterComment === 'function') window.noticeAfterComment();
    var go = '';
    try {
        if (targetUrl && targetUrl.indexOf(location.origin) === 0) go = targetUrl;
    } catch (_e) {}
    setTimeout(function() {
        if (typeof clearPageCache === 'function') clearPageCache();
        cmtRefreshAfterSubmit(go || location.href);
    }, 600);
}

/**
 * 提交成功后原地刷新评论区，避免整页跳回顶部
 * 若重定向地址带 #comment-xxx，会切换到对应评论页并定位到新评论
 */
function cmtRefreshAfterSubmit(targetUrl) {
    var target = '', base = '', hash = '';
    try {
        target = (targetUrl || location.href);
        var u = new URL(target, location.href);
        base = u.href.split('#')[0];
        hash = u.hash || '';
    } catch (_e) {
        base = (location.href || '').split('#')[0];
    }

    function load(url) {
        var reqUrl = url + (url.indexOf('?') === -1 ? '?' : '&') + '_cmt=' + Date.now();
        return fetch(reqUrl, { credentials: 'same-origin', cache: 'no-store' }).then(function(r) {
            if (!r.ok) throw new Error('http ' + r.status);
            return r.text();
        }).then(function(html) {
            return new DOMParser().parseFromString(html, 'text/html');
        });
    }

    function apply(doc, url) {
        var fresh = doc.querySelector('.cmt-section');
        var old = document.querySelector('.cmt-section');
        if (!fresh || !old) throw new Error('no comment section');
        old.parentNode.replaceChild(document.importNode(fresh, true), old);

        var hit = hash ? doc.querySelector(hash) : null;
        try { history.replaceState(null, '', hit ? (url + hash) : url); } catch (_e) {}

        bindCommentForm();
        bindCommentExtras();

        /* 没有可定位的评论锚点时，定位到最新的那条评论，最差也停在评论区 */
        if (!hit) {
            requestAnimationFrame(function() {
                var feed = document.getElementById('feed');
                if (!feed) return;
                var latest = null, maxCoid = -1;
                Array.prototype.forEach.call(document.querySelectorAll('.cmt-item[data-coid]'), function(li) {
                    var c = parseInt(li.getAttribute('data-coid'), 10) || 0;
                    if (c > maxCoid) { maxCoid = c; latest = li; }
                });
                var cs = latest || document.getElementById('comments');
                if (!cs) return;
                var top = feed.scrollTop + cs.getBoundingClientRect().top - feed.getBoundingClientRect().top - 16;
                smoothScrollTo(feed, Math.max(0, top), 360);
            });
        }
    }

    load(base)
        .then(function(doc) {
            if (!hash || doc.querySelector(hash)) return apply(doc, base);

            /* 新评论可能在最后一页，取分页中最大页码再试一次 */
            var maxPage = 0, pageUrl = '';
            Array.prototype.forEach.call(doc.querySelectorAll('.page-navigator a[href*="comment-page-"]'), function(a) {
                var m = (a.getAttribute('href') || '').match(/comment-page-(\d+)/);
                if (m && +m[1] > maxPage) { maxPage = +m[1]; pageUrl = a.href; }
            });
            if (!pageUrl) return apply(doc, base);
            var url = pageUrl.split('#')[0];
            return load(url).then(function(doc2) { apply(doc2, url); });
        })
        .catch(function() {
            /* 兜底：刷新后尽量停在评论区 */
            try { sessionStorage.setItem('robes_cmt_anchor', '1'); } catch (_e) {}
            location.href = base || location.href;
        });
}

/* 兜底整页刷新后，恢复滚动到评论区 */
function cmtRestoreAnchor() {
    var flag = '';
    try { flag = sessionStorage.getItem('robes_cmt_anchor') || ''; } catch (_e) {}
    if (!flag) return;
    try { sessionStorage.removeItem('robes_cmt_anchor'); } catch (_e) {}
    requestAnimationFrame(function() {
        var feed = document.getElementById('feed');
        var cs = document.getElementById('comments');
        if (!feed || !cs) return;
        var top = feed.scrollTop + cs.getBoundingClientRect().top - feed.getBoundingClientRect().top - 16;
        smoothScrollTo(feed, Math.max(0, top), 320);
    });
}

function hoistApplyModal() {
    var m = document.getElementById('cmt-apply-modal');
    if (m && m.parentNode !== document.body) document.body.appendChild(m);
}

(function() {
    hoistApplyModal();
    function openApplyModal() {
        var m = document.getElementById('cmt-apply-modal');
        if (!m) return;
        m.classList.remove('closing');
        m.classList.add('active');
        m.setAttribute('aria-hidden', 'false');
        document.body.classList.add('cmt-modal-open');
        var f = m.querySelector('form.apply-form');
        var done = m.querySelector('#applyDone');
        if (f) f.hidden = false;
        if (done) done.hidden = true;
        var first = m.querySelector('form.apply-form [name="name"]') || m.querySelector('input, textarea');
        if (first) setTimeout(function() { try { first.focus(); } catch(_e) {} }, 120);
    }
    function closeApplyModal() {
        var m = document.getElementById('cmt-apply-modal');
        if (!m || !m.classList.contains('active')) return;
        m.classList.add('closing');
        setTimeout(function() {
            m.classList.remove('active', 'closing');
            m.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('cmt-modal-open');
        }, 190);
    }
    window.openApplyModal = openApplyModal;
    window.closeApplyModal = closeApplyModal;

    document.addEventListener('click', function(e) {
        if (e.target.closest && e.target.closest('[data-cmt-apply-open]')) {
            e.preventDefault();
            openApplyModal();
            return;
        }
        if (e.target.closest && e.target.closest('[data-cmt-apply-close]')) {
            e.preventDefault();
            closeApplyModal();
        }
    });

    document.addEventListener('keydown', function(e) {
        if (e.key !== 'Escape') return;
        var m = document.getElementById('cmt-apply-modal');
        if (m && m.classList.contains('active')) closeApplyModal();
    });
})();

function _normalizeUrl(url) {
    try {
        var u = new URL(url, location.origin);
        return u.pathname.replace(/\/+$/, '') || '/';
    } catch(_e) {
        return url.split('?')[0].split('#')[0].replace(/\/+$/, '') || '/';
    }
}

/**
 * 从 HTML 中提取错误信息（只在 Typecho 消息区域查找，
 * 避免正文内容中的"垃圾""禁止"等词导致误判）
 */
function _extractErrMsg(html) {
    try {
        var doc = new DOMParser().parseFromString(html, 'text/html');

        var msgEl = doc.querySelector('.typecho-message span')
            || doc.querySelector('.typecho-message')
            || doc.querySelector('.message')
            || doc.querySelector('[class*="error"]')
            || doc.querySelector('.typecho-notice')
            || doc.querySelector('.notice')
            || doc.querySelector('body > .container')
            || doc.querySelector('[role="alert"]');

        if (msgEl) {
            var msgText = msgEl.textContent.trim();
            if (msgText && msgText.length <= 120) {
                var lower = msgText.toLowerCase();
                var errKw = ['失败','错误','error','禁止','spam','垃圾','已发表过','过快',
                             'flood','重复','不能为空','评论已关闭','不允许','denied','blocked',
                             'invalid','missing','required','too many','limit','必须','请填写',
                             '不合法','已被注册','频繁','格式错误','未登录','不存在'];
                for (var i = 0; i < errKw.length; i++) {
                    if (lower.indexOf(errKw[i]) !== -1) return msgText;
                }
            }
        }

        /* Typecho 的 500 错误页固定为 <body><div class="container">真实原因</div>，
           这里不再做关键词白名单，直接取容器文本，避免把真实原因吞掉 */
        var cEl = doc.querySelector('body > div.container');
        if (cEl) {
            var cText = cEl.textContent.trim();
            if (cText && cText.length <= 200) return cText;
        }

        var titleEl = doc.querySelector('title');
        if (titleEl) {
            var t = titleEl.textContent.toLowerCase();
            if (t.indexOf('error') !== -1 || t.indexOf('错误') !== -1) return '评论提交失败，请重试';
        }
    } catch(_e) {}
    return '';
}
function bindCommentValidity() {
    document.querySelectorAll('#comment-form input[name="url"], #comment-form textarea[name="text"]').forEach(function(el) {
        if (el.dataset.vmsgBound) return;
        el.dataset.vmsgBound = '1';
        var msg = el.name === 'url' ? '请填写网址（个人主页）' : '请输入评论内容';
        var sync = function() { el.setCustomValidity(el.value.trim() ? '' : msg); };
        el.addEventListener('input', sync);
        el.addEventListener('change', sync);
        sync();
    });
}

function bindCommentForm() {
    var replyBar = document.getElementById('cmt-reply-bar');
    var replyInfo = document.getElementById('cmt-reply-info');
    var cancelBtn = document.getElementById('cmt-cancel-btn');
    var parentInput = document.getElementById('comment-parent');
    var commentForm = document.getElementById('comment-form');

    bindCommentValidity();

    if (cancelBtn) {
        cancelBtn.onclick = function() {
            if (parentInput) parentInput.value = '';
            if (replyBar) {
                var rbh = replyBar.getBoundingClientRect().height;
                var rbo = parseFloat(getComputedStyle(replyBar).opacity) || 0;
                var rbm = getComputedStyle(replyBar).marginBottom;
                replyBar.classList.remove('show');
                rcSlide(replyBar, false, { from: rbh, fromOpacity: rbo, fromMargin: rbm });
            }
            var ta = commentForm ? commentForm.querySelector('textarea') : null;
            if (ta) {
                if (ta.dataset.mentionPrefill && ta.value === ta.dataset.mentionPrefill) ta.value = '';
                delete ta.dataset.mentionPrefill;
                ta.placeholder = '说点什么吧…';
            }
        };
    }

    var emojiBtn = document.getElementById('cmt-emoji-btn');
    var emojiPanel = document.getElementById('cmt-emoji-panel');
    var EMOJI_GROUPS = [
        { name: '常用', list: '😀 😂 🤣 😊 😍 🥰 😘 😎 🤔 😅 😭 😤 👍 👏 🙏 ❤️ 🔥 🎉 💯 ✅ ⭐ 😆 😉 🙄 😴 🤗 🥳 😇 😋 😜 🤝 💪 ✨ 🥺 😅' },
        { name: '表情', list: '😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 😉 😊 😇 🥰 😍 🤩 😘 😗 😚 😙 😋 😛 😜 🤪 😝 🤗 🤭 🤫 🤔 🤐 🤨 😐 😑 😶 😏 😒 🙄 😬 😮 😯 😲 😴 😌 😔 🤤 😪 😵 🤯' },
        { name: '手势', list: '👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐️ 🖖 👋 🤝 🙏 💪 🦾 👏 🙌 👐 🤲 👊 ✊ 🤛 🤜' },
        { name: '爱心', list: '❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ♥️ 💌' },
        { name: '动物', list: '🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦄 🐝 🐛 🦋 🐌 🐞 🐢 🐍 🐬 🐳 🐟 🐠 🦈 🐊 🐅 🐆 🦓 🦍' },
        { name: '美食', list: '🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥒 🌽 🥕 🥔 🍞 🥐 🧀 🥚 🍳 🥞 🥓 🍔 🍟 🍕 🌭 🥪 🌮 🍜 🍝 🍣 🍱 🍰' },
        { name: '活动', list: '⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 🏸 🥅 🏒 🥊 🥋 ⛳ 🎿 🏂 🏋️ 🤸 🎯 🎮 🕹️ 🎲 🎰 🎳 🎭 🎨 🎬 🎤 🎧 🎼 🎹 🥁 🎷 🎺 🎸 🎻 🏆 🥇 🥈 🥉' },
        { name: '自然', list: '🌞 🌝 🌚 🌙 ⭐ 🌟 ✨ ⚡ 🔥 💥 ❄️ ⛄ 🌊 💧 🌈 ☀️ ⛅ ☁️ 🌤️ 🌧️ ⛈️ 🌨️ 🌪️ 🌫️ 🌸 🌺 🌻 🌹 🌷 🍀' },
        { name: '符号', list: '❤️ 💯 ✅ ❌ ⭕ ❗ ❓ ⚠️ ♻️ ✨ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 💠 🔔 🎵 🎶 ➕ ➖ ➗ ✖️ ✔️ ☑️ 🔘 ™️' }
    ];

    function insertEmoji(ch) {
        if (!commentForm || !ch) return;
        var ta = commentForm.querySelector('textarea');
        if (!ta) return;
        var s = ta.selectionStart, e = ta.selectionEnd;
        ta.value = ta.value.substring(0, s) + ch + ta.value.substring(e);
        ta.selectionStart = ta.selectionEnd = s + ch.length;
        ta.focus();
    }

    if (emojiPanel && !emojiPanel.dataset.built) {
        var tabsHtml = '', catsHtml = '';
        EMOJI_GROUPS.forEach(function(g, i) {
            tabsHtml += '<button type="button" class="cmt-emoji-tab' + (i === 0 ? ' active' : '') +
                '" data-idx="' + i + '">' + g.name + '</button>';
            catsHtml += '<div class="cmt-emoji-cat" data-idx="' + i + '"' + (i === 0 ? '' : ' hidden') + '>' +
                g.list.split(' ').map(function(em) {
                    return '<span class="cmt-emoji-item">' + em + '</span>';
                }).join('') + '</div>';
        });
        emojiPanel.innerHTML = '<div class="cmt-emoji-tabs">' + tabsHtml + '</div>' +
            '<div class="cmt-emoji-grid">' + catsHtml + '</div>';

        emojiPanel.addEventListener('click', function(ev) {
            var tab = ev.target.closest('.cmt-emoji-tab');
            if (tab) {
                var idx = tab.getAttribute('data-idx');
                emojiPanel.querySelectorAll('.cmt-emoji-tab').forEach(function(b) {
                    b.classList.toggle('active', b === tab);
                });
                emojiPanel.querySelectorAll('.cmt-emoji-cat').forEach(function(c) {
                    c.hidden = c.getAttribute('data-idx') !== idx;
                });
                var grid = emojiPanel.querySelector('.cmt-emoji-grid');
                if (grid) grid.scrollTop = 0;
                return;
            }
            var item = ev.target.closest('.cmt-emoji-item');
            if (item) {
                insertEmoji(item.textContent);
                closeEmojiPanel();
            }
        });
        emojiPanel.dataset.built = '1';
    }

    if (emojiBtn) {
        emojiBtn.onclick = function(e) {
            e.stopPropagation();
            if (!emojiPanel) return;
            if (emojiPanelIsOpen()) closeEmojiPanel();
            else openEmojiPanel();
        };
    }

    VF.attach(commentForm);
}

document.addEventListener('click', function(e) {
    var btn = e.target.closest('.cmt-reply-btn');
    if (!btn) return;
    e.preventDefault();
    var cid = btn.getAttribute('data-cid');
    var coid = btn.getAttribute('data-coid');
    var parentInput = document.getElementById('comment-parent');
    var replyBar = document.getElementById('cmt-reply-bar');
    var replyInfo = document.getElementById('cmt-reply-info');
    var commentForm = document.getElementById('comment-form');
    if (parentInput) parentInput.value = coid;
    var card = document.getElementById(cid);
    var nameEl = card ? card.querySelector('.cmt-name') : null;
    var name = nameEl ? nameEl.textContent.trim() : '';
    if (replyInfo) replyInfo.innerHTML = '回复 <strong>' + name + '</strong>';
    if (replyBar) {
        var rbo2 = parseFloat(getComputedStyle(replyBar).opacity) || 0;
        var rbm2 = getComputedStyle(replyBar).marginBottom;
        replyBar.classList.add('show');
        rcSlide(replyBar, true, { from: 0, fromOpacity: rbo2, fromMargin: rbm2 });
    }
    var ta = commentForm ? commentForm.querySelector('textarea') : null;
    if (ta) {
        /* @ 提及：回复时自动带上被回复者昵称 */
        var at = name ? '@' + name + ' ' : '';
        if (at) {
            if (!ta.value.trim() || (ta.dataset.mentionPrefill && ta.value === ta.dataset.mentionPrefill)) {
                ta.value = at;
                ta.dataset.mentionPrefill = at;
            } else if (ta.value.indexOf('@' + name) === -1) {
                ta.value = ta.value.replace(/\s*$/, '') + (/\s$/.test(ta.value) ? '' : ' ') + at;
            }
        }
        ta.focus();
        ta.placeholder = '回复 ' + name + '…';
        try { ta.selectionStart = ta.selectionEnd = ta.value.length; } catch (_e) {}
    }
    if (commentForm) commentForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
});

/* 表情面板：展开/收起动画 + 上下翻转定位 */
var _emojiCloseTimer = null;
function _emojiPanelEl() { return document.getElementById('cmt-emoji-panel'); }
function emojiPanelIsOpen() {
    var p = _emojiPanelEl();
    return !!(p && p.style.display !== 'none');
}
function placeEmojiPanel() {
    var panel = _emojiPanelEl();
    if (!panel) return;
    panel.classList.remove('cmt-emoji-panel--down');
    var tb = document.querySelector('.topbar');
    var limit = tb ? tb.getBoundingClientRect().bottom + 8 : 96;
    if (panel.getBoundingClientRect().top < limit) {
        panel.classList.add('cmt-emoji-panel--down');
    }
}
function openEmojiPanel() {
    var panel = _emojiPanelEl();
    if (!panel) return;
    clearTimeout(_emojiCloseTimer);
    panel.classList.remove('cmt-emoji-panel--out', 'cmt-emoji-panel--in');
    panel.style.display = 'block';
    var grid = panel.querySelector('.cmt-emoji-grid');
    if (grid) grid.scrollTop = 0;
    placeEmojiPanel();
    /* 强制回流，确保动画每次都从头播放 */
    void panel.offsetWidth;
    panel.classList.add('cmt-emoji-panel--in');
}
function closeEmojiPanel() {
    var panel = _emojiPanelEl();
    if (!panel || panel.style.display === 'none') return;
    if (panel.classList.contains('cmt-emoji-panel--out')) return;
    clearTimeout(_emojiCloseTimer);
    panel.classList.remove('cmt-emoji-panel--in');
    panel.classList.add('cmt-emoji-panel--out');
    _emojiCloseTimer = setTimeout(function() {
        panel.style.display = 'none';
        panel.classList.remove('cmt-emoji-panel--out');
    }, 160);
}
function bindLike() {
    var btn = document.getElementById('likeBtn');
    if (!btn || btn.dataset.bound) return;
    btn.dataset.bound = '1';
    if (btn.dataset.liked === '1') btn.classList.add('liked');
    btn.addEventListener('click', function() {
        var cid = btn.dataset.cid;
        var isLiked = btn.classList.contains('liked');
        var action = isLiked ? 'undo' : 'do';
        btn.style.pointerEvents = 'none';
        fetch(location.href, {
            method: 'POST',
            headers: {'Content-Type':'application/x-www-form-urlencoded'},
            body: 'likeup=' + cid + '&action=' + action
        })
        .then(function(r) { return r.text(); })
        .then(function(text) {
            var likes;
            try { likes = JSON.parse(text).likes; } catch(e) { likes = parseInt(text); }
            var countEl = btn.querySelector('.like-count');
            if (countEl) countEl.textContent = likes;
            if (action === 'do') {
                btn.classList.add('liked');
                btn.querySelector('i').className = 'ri-heart-fill';
                btn.querySelector('.like-text').textContent = '\u5df2\u559c\u6b22';
                btn.classList.add('animating');
                var fh = document.createElement('i');
                fh.className = 'ri-heart-fill like-float-heart';
                btn.appendChild(fh);
                setTimeout(function() { btn.classList.remove('animating'); fh.remove(); }, 800);
                showToast('\u70b9\u8d5e\u6210\u529f \u2764\ufe0f', 'success');
            } else {
                btn.classList.remove('liked');
                btn.querySelector('i').className = 'ri-heart-line';
                btn.querySelector('.like-text').textContent = '\u559c\u6b22\u8fd9\u7bc7\u6587\u7ae0';
                showToast('\u5df2\u53d6\u6d88\u70b9\u8d5e', 'success');
            }
        })
        .catch(function() { showToast('\u70b9\u8d5e\u5931\u8d25', 'error'); })
        .finally(function() { btn.style.pointerEvents = ''; });
    });
}
function initTOC() {
  var content = document.querySelector('.article-content');
  var tocWrap = document.getElementById('articleTOC');
  var inlineBtn = document.getElementById('tocInlineBtn');
  if (!content || !tocWrap) return;
  var headings = content.querySelectorAll('h2, h3');
  if (headings.length < 2) { if (inlineBtn) inlineBtn.style.display = 'none'; return; }
  if (inlineBtn) inlineBtn.style.display = '';

  var list = document.createElement('div');
  list.className = 'toc-list';
  headings.forEach(function(h, i) {
    if (!h.id) h.id = 'toc-' + i;
    var item = document.createElement('a');
    item.className = 'toc-item toc-' + h.tagName.toLowerCase();
    item.href = '#' + h.id;
    item.textContent = h.textContent;
    item.addEventListener('click', function(e) {
      e.preventDefault();
      var feedEl = document.getElementById('feed');
      if (feedEl) {
        var target = feedEl.scrollTop + h.getBoundingClientRect().top - feedEl.getBoundingClientRect().top - 24;
        smoothScrollTo(feedEl, Math.max(0, target), 400);
      } else {
        h.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
    list.appendChild(item);
  });
  tocWrap.appendChild(list);

  if (inlineBtn) {
    inlineBtn.addEventListener('click', function() {
      var isOpen = !tocWrap.classList.contains('open');
      var fromH = tocWrap.getBoundingClientRect().height;
      var fromOp = parseFloat(getComputedStyle(tocWrap).opacity) || 0;
      tocWrap.classList.toggle('open', isOpen);
      inlineBtn.classList.toggle('active', isOpen);
      inlineBtn.title = isOpen ? '收起目录' : '展开目录';
      rcSlide(tocWrap, isOpen, { from: fromH, fromOpacity: fromOp });
    });
  }

  var feed = document.getElementById('feed');
  if (!feed) return;
  var items = list.querySelectorAll('.toc-item');
  var ticking = false;
  feed.addEventListener('scroll', function() {
    if (ticking || feed.__animating) return;
    ticking = true;
    requestAnimationFrame(function() {
      var current = '';
      headings.forEach(function(h) {
        var rect = h.getBoundingClientRect();
        if (rect.top <= 120) current = h.id;
      });
      items.forEach(function(item) {
        item.classList.toggle('active', item.getAttribute('href') === '#' + current);
      });
      ticking = false;
    });
  });
}
function cmtGetCookie(name) {
    try {
        var m = document.cookie.match(new RegExp('(?:^|; )' + name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '=([^;]*)'));
        return m ? decodeURIComponent(m[1]) : '';
    } catch (_e) { return ''; }
}

function cmtCopyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text);
    }
    return new Promise(function(resolve, reject) {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); resolve(); } catch (e) { reject(e); }
        document.body.removeChild(ta);
    });
}

function cmtHighlightMentions(root) {
    var skip = /^(A|CODE|PRE|SCRIPT|STYLE|TEXTAREA)$/;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode: function(node) {
            var p = node.parentNode;
            if (!p || skip.test(p.nodeName)) return NodeFilter.FILTER_REJECT;
            if (node.nodeValue.indexOf('@') === -1) return NodeFilter.FILTER_REJECT;
            return NodeFilter.FILTER_ACCEPT;
        }
    });
    var nodes = [], n;
    while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach(function(node) {
        var text = node.nodeValue;
        var re = /@([\u4e00-\u9fa5A-Za-z0-9_.\-]{1,20})/g;
        var frag = document.createDocumentFragment();
        var last = 0, m, hit = false;
        while ((m = re.exec(text))) {
            hit = true;
            if (m.index > last) frag.appendChild(document.createTextNode(text.slice(last, m.index)));
            var span = document.createElement('span');
            span.className = 'cmt-mention';
            span.setAttribute('data-name', m[1]);
            span.textContent = m[0];
            frag.appendChild(span);
            last = m.index + m[0].length;
        }
        if (!hit) return;
        if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
        node.parentNode.replaceChild(frag, node);
    });
}

function cmtFlashHash() {
    var hash = location.hash;
    if (!/^#comment-\d+$/.test(hash)) return;
    var card = document.getElementById(hash.slice(1));
    if (!card) return;
    var li = card.closest('li.cmt-item') || card;
    li.classList.add('cmt-flash');
    try { card.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (_e) {}
    setTimeout(function() { li.classList.remove('cmt-flash'); }, 2600);
}

function cmtInitCollapse() {
    var LIMIT = 280;
    document.querySelectorAll('.cmt-text:not([data-collapse])').forEach(function(el) {
        el.dataset.collapse = '1';
        var build = function() {
            if (el.dataset.collapseReady || el.classList.contains('cmt-collapsed')) return;
            if (el.scrollHeight <= LIMIT + 24) return;
            el.dataset.collapseReady = '1';
            el.classList.add('cmt-collapsed');
            el.dataset.foldH = Math.round(el.getBoundingClientRect().height) || LIMIT;
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'cmt-expand-btn';
            btn.innerHTML = '<span>展开全文</span><i class="ri-arrow-down-line"></i>';
            btn.addEventListener('click', function() {
                var collapsed = el.classList.contains('cmt-collapsed');
                var fromH = el.getBoundingClientRect().height;
                if (collapsed) {
                    el.classList.remove('cmt-collapsed');
                    rcSlide(el, true, { from: fromH, open: 380 });
                } else {
                    rcSlide(el, false, {
                        from: fromH,
                        to: parseFloat(el.dataset.foldH) || LIMIT,
                        close: 300,
                        done: function() { el.classList.add('cmt-collapsed'); }
                    });
                }
                btn.querySelector('span').textContent = collapsed ? '收起' : '展开全文';
                btn.querySelector('i').className = collapsed ? 'ri-arrow-up-line' : 'ri-arrow-down-line';
            });
            el.parentNode.insertBefore(btn, el.nextSibling);
        };
        requestAnimationFrame(build);
        el.querySelectorAll('img').forEach(function(img) {
            if (!img.complete) img.addEventListener('load', build, { once: true });
        });
    });
}

function bindCommentExtras() {
    document.querySelectorAll('.cmt-like-btn:not([data-bound])').forEach(function(btn) {
        btn.dataset.bound = '1';
        var coid = btn.getAttribute('data-coid');
        var countEl = btn.querySelector('.cmt-like-count');
        if (cmtGetCookie('cmt_like_' + coid)) btn.classList.add('liked');
        btn.addEventListener('click', function() {
            var liked = btn.classList.contains('liked');
            var action = liked ? 'undo' : 'do';
            btn.style.pointerEvents = 'none';
            fetch(location.href, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'cmtup=' + encodeURIComponent(coid) + '&action=' + action
            })
            .then(function(r) { return r.json(); })
            .then(function(res) {
                if (!res || !res.ok) {
                    showToast((res && res.message) || '操作失败，请稍后再试', 'error');
                    return;
                }
                if (countEl) countEl.textContent = res.likes > 0 ? res.likes : '';
                btn.classList.toggle('liked', !!res.liked);
                showToast(res.liked ? '点赞成功 ❤️' : '已取消点赞', 'success');
            })
            .catch(function() { showToast('点赞失败，请稍后再试', 'error'); })
            .finally(function() { btn.style.pointerEvents = ''; });
        });
    });

    document.querySelectorAll('.cmt-floor:not([data-bound])').forEach(function(btn) {
        btn.dataset.bound = '1';
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            var cid = btn.getAttribute('data-cid');
            if (!cid) return;
            var url = location.origin + location.pathname + location.search + '#' + cid;
            cmtCopyText(url).then(function() {
                showToast('评论链接已复制', 'success');
            }, function() {
                showToast('复制失败，请手动复制地址栏链接', 'error');
            });
        });
    });

    document.querySelectorAll('.cmt-text:not([data-mention-bound])').forEach(function(el) {
        el.dataset.mentionBound = '1';
        cmtHighlightMentions(el);
    });

    cmtInitCollapse();
    cmtFlashHash();
    if (typeof initWaterfall === 'function') initWaterfall();
    if (typeof window.robesInitCommentDel === 'function') window.robesInitCommentDel();
}
document.addEventListener('click', function(e) {
    var m = e.target.closest ? e.target.closest('.cmt-mention') : null;
    if (!m) return;
    var form = document.getElementById('comment-form');
    var ta = form ? form.querySelector('textarea') : null;
    if (!ta) return;
    e.preventDefault();
    var name = m.getAttribute('data-name') || '';
    if (!name) return;
    var at = '@' + name + ' ';
    if (ta.value.indexOf('@' + name) === -1) {
        var s = ta.selectionStart, en = ta.selectionEnd;
        ta.value = ta.value.substring(0, s) + at + ta.value.substring(en);
        ta.selectionStart = ta.selectionEnd = s + at.length;
    }
    ta.focus();
});
