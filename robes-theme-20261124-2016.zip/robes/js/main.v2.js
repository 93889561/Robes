/* 页面切入后台时给 html 挂 doc-hidden，base.css 据此暂停所有动画，
   避免后台标签页持续占用 CPU/GPU */
(function () {
    var root = document.documentElement;
    function syncDocHidden() { root.classList.toggle('doc-hidden', document.hidden); }
    document.addEventListener('visibilitychange', syncDocHidden);
    syncDocHidden();
})();

function showToast(msg, type) {
    var el = document.querySelector('.toast-notification');
    if (el) el.remove();
    var t = document.createElement('div');
    var icon = 'ri-checkbox-circle-line';
    if (type === 'error') icon = 'ri-error-warning-line';
    else if (type === 'music' || type === 'pause') icon = 'ri-music-2-line';
    t.className = 'toast-notification toast-' + (type || 'success');
    t.innerHTML = '<i class="' + icon + '"></i><span></span>';
    t.querySelector('span').textContent = msg;
    document.body.appendChild(t);
    requestAnimationFrame(function() { t.classList.add('toast-show'); });
    setTimeout(function() { t.classList.remove('toast-show'); setTimeout(function() { t.remove(); }, 400); }, 2000);
}

/* ============ 统一的展开 / 收起 ============ */
function rcReduceMotion() {
    return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
}
/* 按真实高度做过渡（而不是 max-height 猜值），结束后把高度交还给样式表。
   opts: from(起始高度) / to(收起目标) / open|close(毫秒) / done(回调)
         fromOpacity / fromMargin（class 已切换，需要由调用方传入切换前的值，
         否则 transition:none 会让这些属性直接跳变） */
function rcSlide(el, open, opts) {
    if (!el) return;
    opts = opts || {};
    if (el._rcTimer) { clearTimeout(el._rcTimer); el._rcTimer = null; }
    var dur = open ? (opts.open || 340) : (opts.close || 260);
    var ease = open ? 'cubic-bezier(.22,1,.36,1)' : 'cubic-bezier(.4,0,.2,1)';
    var finish = opts.done || function () {};
    var from = opts.from != null ? opts.from : el.getBoundingClientRect().height;
    var fade = opts.fromOpacity != null;
    var grow = opts.fromMargin != null;
    var fadeDur = Math.min(dur, 260);

    function reset() {
        el.style.height = '';
        el.style.maxHeight = '';
        el.style.overflow = '';
        el.style.transition = '';
        if (fade) el.style.opacity = '';
        if (grow) el.style.marginBottom = '';
    }

    if (rcReduceMotion()) {
        reset();
        finish(open);
        return;
    }
    /* 样式表里可能有 max-height:0 的收起态，动画期间先解除，否则高度被夹住 */
    el.style.maxHeight = 'none';

    var to;
    if (open) {
        el.style.transition = 'none';
        el.style.overflow = 'hidden';
        el.style.height = 'auto';
        to = el.getBoundingClientRect().height;
        if (Math.abs(to - from) < 1) { reset(); finish(true); return; }
    } else {
        to = opts.to != null ? opts.to : 0;
        if (from <= to + 1) { reset(); finish(false); return; }
    }

    el.style.transition = 'none';
    el.style.overflow = 'hidden';
    el.style.height = from + 'px';
    /* class 已经切换过，这里把过渡属性先拉回起点，避免 transition:none 造成瞬变 */
    if (fade) el.style.opacity = opts.fromOpacity;
    if (grow) el.style.marginBottom = opts.fromMargin;
    void el.offsetHeight;

    var tr = 'height ' + dur + 'ms ' + ease;
    if (fade) tr += ', opacity ' + fadeDur + 'ms ' + ease;
    if (grow) tr += ', margin-bottom ' + dur + 'ms ' + ease;
    el.style.transition = tr;
    el.style.height = to + 'px';
    if (fade) el.style.opacity = open ? 1 : 0;
    if (grow) el.style.marginBottom = open ? opts.marginTo || '8px' : '0px';

    el._rcTimer = setTimeout(function () {
        el._rcTimer = null;
        reset();
        finish(open);
    }, dur + 20);
}



function initTheme() {
    var btn = document.getElementById('themeToggle');
    if (!btn) return;
    var darkMode = (typeof ROBES !== 'undefined' && ROBES.darkMode) ? ROBES.darkMode : 'auto';

    if (darkMode === 'light' || darkMode === 'dark') {
        btn.style.display = 'none';
        document.documentElement.classList.toggle('dark', darkMode === 'dark');
        localStorage.setItem('theme', darkMode);
        return;
    }

    btn.style.display = '';

    if (darkMode === 'switch') {
        document.documentElement.classList.toggle('dark', localStorage.getItem('theme') === 'dark');
    } else if (!localStorage.getItem('theme')) {
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            document.documentElement.classList.add('dark');
        }
    } else if (localStorage.getItem('theme') === 'dark') {
        document.documentElement.classList.add('dark');
    }

    if (!btn.dataset.bound) {
        btn.dataset.bound = '1';
        btn.addEventListener('click', function() {
            var root = document.documentElement;
            root.classList.add('theme-switching');
            root.classList.toggle('dark');
            var d = root.classList.contains('dark');
            localStorage.setItem('theme', d ? 'dark' : 'light');

            var fade = document.createElement('div');
            fade.className = 'theme-fade';
            document.body.appendChild(fade);
            setTimeout(function() { root.classList.remove('theme-switching'); }, 80);
            setTimeout(function() { fade.remove(); }, 400);

            setTimeout(function() {
                showToast(d ? '已切换到深色模式' : '已切换到浅色模式');
            }, 120);
        });
    }
}


function initSectionToggle() {
    var btns = document.querySelectorAll('.section-toggle-btn');
    if (!btns.length) return;
    btns.forEach(function(btn) {
        var targetId = btn.getAttribute('data-target');
        var list = document.getElementById(targetId);
        if (!list) return;

        var collapsed = localStorage.getItem('section_' + targetId) === '1';
        if (collapsed) {
            list.classList.add('collapsed');
            btn.classList.add('collapsed');
        }

        if (!btn.dataset.bound) {
            btn.dataset.bound = '1';
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var isCollapsed = !list.classList.contains('collapsed');
                var fromH = list.getBoundingClientRect().height;
                var fromOp = parseFloat(getComputedStyle(list).opacity) || 0;
                list.classList.toggle('collapsed', isCollapsed);
                btn.classList.toggle('collapsed', isCollapsed);
                localStorage.setItem('section_' + targetId, isCollapsed ? '1' : '0');
                rcSlide(list, !isCollapsed, { from: fromH, fromOpacity: fromOp });
            });
        }
    });
}

function smoothScrollTo(el, target, duration) {
    duration = duration || 500;
    var start = el.scrollTop, change = target - start;
    if (!change) return;
    var token = (el.__scrollAnim = (el.__scrollAnim || 0) + 1);
    el.__animating = true;
    var startTime = null;
    function easeInOut(t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }
    function step(ts) {
        if (el.__scrollAnim !== token) return;
        if (!startTime) startTime = ts;
        var p = Math.min((ts - startTime) / duration, 1);
        el.scrollTop = start + change * easeInOut(p);
        if (p < 1) requestAnimationFrame(step);
        else el.__animating = false;
    }
    requestAnimationFrame(step);
}

function updateScrollUI() {
    var el = document.getElementById('feed');
    var btn = document.getElementById('scrollTopBtn');
    if (!el) return;
    var st = el.scrollTop, max = el.scrollHeight - el.clientHeight;
    el.classList.toggle('fade-top-on', st > 8);
    el.classList.toggle('fade-bottom-on', st + el.clientHeight < el.scrollHeight - 8);
    if (btn) {
        var canScroll = max > 8;
        var atTop = st < 50;
        btn.classList.toggle('to-bottom', canScroll && atTop);
        btn.classList.toggle('is-at-bottom', canScroll && st >= max - 8);
        btn.title = canScroll && atTop ? '滚到底部' : '回到顶部';
        btn.setAttribute('aria-label', btn.title);
    }
}

var sidebarOverlay = document.getElementById('sidebarOverlay');
function openSidebar() {
    var sb = document.querySelector('.sidebar');
    if (sb) sb.classList.add('open');
    if (sidebarOverlay) sidebarOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
    refreshSlideGroups();
    setTimeout(refreshSlideGroups, 380);
}
function closeSidebar() {
    var sb = document.querySelector('.sidebar');
    if (sb) sb.classList.remove('open');
    if (sidebarOverlay) sidebarOverlay.classList.remove('active');
    document.body.style.overflow = '';
}
function syncNavActive() {
    var path = location.pathname.replace(/\/+$/, '') || '/';
    var home = path === '/' || /^\/page\/\d+/.test(path);
    document.querySelectorAll('.sidebar .nav-item').forEach(function(a) {
        var href = a.getAttribute('href');
        if (!href) return;
        var p;
        try { p = new URL(href, location.origin).pathname.replace(/\/+$/, '') || '/'; } catch (e) { return; }
        var on;
        if (p === '/') on = home;
        else on = (p === path) || (path.indexOf(p + '/') === 0);
        a.classList.toggle('active', on);
    });
    refreshSlideGroups();
}
function bindSidebarAutoClose() {
    document.querySelectorAll('.sidebar .nav-item').forEach(function(item) {
        if (item.dataset.sbBound) return;
        item.dataset.sbBound = '1';
        item.addEventListener('click', function() { if (window.innerWidth <= 768) closeSidebar(); });
    });
}
function bindMobileMenuBtn() {
    var btn = document.getElementById('mobileMenuBtn');
    if (!btn || btn.dataset.bound) return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', function() { openSidebar(); });
}
function syncMobileTabbar() {
    var bar = document.querySelector('.mobile-tabbar');
    if (!bar) return;
    var path = location.pathname.replace(/\/+$/, '') || '/';
    bar.querySelectorAll('a.mtab').forEach(function(a) {
        var p;
        try { p = (new URL(a.href, location.href)).pathname.replace(/\/+$/, '') || '/'; }
        catch (e) { return; }
        a.classList.toggle('active', p === path);
    });
}
function bindMobileTabbarMore() {
    var btn = document.getElementById('mtabMoreBtn');
    var panel = document.getElementById('mtabMorePanel');
    if (!btn || !panel || btn.dataset.bound) return;
    btn.dataset.bound = '1';
    function setOpen(open) {
        panel.classList.toggle('open', open);
        btn.classList.toggle('active', open);
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
    btn.addEventListener('click', function(e) {
        e.stopPropagation();
        setOpen(!panel.classList.contains('open'));
    });
    panel.addEventListener('click', function(e) {
        if (e.target.closest('a')) setOpen(false);
    });
    document.addEventListener('click', function(e) {
        if (!panel.classList.contains('open')) return;
        if (panel.contains(e.target) || btn.contains(e.target)) return;
        setOpen(false);
    });
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') setOpen(false);
    });
}
function bindSiteInfo() {
    var btn = document.getElementById('siteInfoBtn');
    var pop = document.getElementById('siteInfoPop');
    if (!btn || !pop || btn.dataset.bound) return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', function(e) {
        e.stopPropagation();
        pop.classList.toggle('active');
    });
    document.addEventListener('click', function(e) {
        if (!pop.contains(e.target)) pop.classList.remove('active');
    });
}

/* 评论通知：铃铛 + 下拉面板（游客可看公开的最新评论与公告，登录后才有未读与我的评论） */
function bindNotice() {
    var btn = document.getElementById('noticeBtn');
    var pop = document.getElementById('noticePop');
    if (!btn || !pop || btn.dataset.bound === '1') return;
    btn.dataset.bound = '1';

    var badge = document.getElementById('noticeBadge');
    var islandCount = document.getElementById('noticeIslandCount');
    var list = document.getElementById('noticeList');
    var boardView = document.getElementById('noticeBoardView');
    var vibeView = document.getElementById('noticeVibe');
    var moodView = document.getElementById('noticeMood');
    var boardDot = document.getElementById('noticeBoardDot');
    var foot = document.getElementById('noticeFoot');
    var moreBtn = document.getElementById('noticeMore');
    var markAllBtn = document.getElementById('noticeMarkAll');
    var refreshBtn = document.getElementById('noticeRefresh');
    var closeBtn = document.getElementById('noticeClose');
    var headCount = document.getElementById('noticeHeadCount');
    var tabCount = document.getElementById('noticeTabCount');
    var tabs = Array.prototype.slice.call(pop.querySelectorAll('.notice-tab'));
    var tabsWrap = pop.querySelector('.notice-tabs');
    var tabThumb = pop.querySelector('.notice-tab-thumb');
    /* 分段控件的白色滑块：宽度贴合当前 Tab，位置随 Tab 平滑过渡 */
    function moveTabThumb() {
        if (!tabThumb || !tabsWrap) return;
        var active = tabsWrap.querySelector('.notice-tab.is-active');
        if (!active) return;
        tabThumb.style.width = active.offsetWidth + 'px';
        tabThumb.style.transform = 'translateX(' + (active.offsetLeft - 3) + 'px)';
        tabThumb.classList.add('is-ready');
    }
    /* 鼠标掠过 Tab 时滑块先跟过去，移出后回到当前 Tab */
    if (tabThumb && tabsWrap) {
        tabs.forEach(function (t) {
            t.addEventListener('pointerenter', function (e) {
                if (e.pointerType === 'touch') return;
                tabThumb.classList.add('is-ready');
                tabThumb.style.width = t.offsetWidth + 'px';
                tabThumb.style.transform = 'translateX(' + (t.offsetLeft - 3) + 'px)';
            });
        });
        tabsWrap.addEventListener('pointerleave', function () { moveTabThumb(); });
    }

    var endpoint = pop.getAttribute('data-endpoint') || '';
    var canTrack = pop.getAttribute('data-identity') === '1';
    if (!endpoint) return;

    /* 挂到 body 下：.shell 自带 backdrop-filter，形成 backdrop root，
       面板留在里面时自己的模糊采样不到页面内容（和移动端悬浮栏的观感不一致） */
    if (pop.parentNode !== document.body) document.body.appendChild(pop);

    /* 桌面端按铃铛按钮的位置定位；移动端交给 CSS 的贴顶抽屉 */
    var mobileMq = window.matchMedia('(max-width: 640px)');
    function placePanel() {
        if (mobileMq.matches) {
            pop.style.top = '';
            pop.style.right = '';
            return;
        }
        var r = btn.getBoundingClientRect();
        pop.style.top = Math.round(r.bottom + 10) + 'px';
        pop.style.right = Math.round(Math.max(10, window.innerWidth - r.right)) + 'px';
    }
    placePanel();
    window.addEventListener('resize', placePanel);
    window.addEventListener('resize', moveTabThumb);

    var tab = 'board';
    var page = 1;
    var loading = false;
    var hasMore = false;
    var unread = 0;
    var loadedAt = 0;
    var countSeq = 0;
    var boardUnread = 0;
    var BOARD_READ_KEY = 'robes_notice_board_read';
    var boardItems = boardView
        ? Array.prototype.slice.call(boardView.querySelectorAll('.notice-board-item'))
        : [];
    /* 没有登录、也没留过评论的访客没有服务端身份，用本地「上次看到的最新评论时间」
       判断有没有新评论，同样给铃铛挂提醒 */
    var guestNew = false;
    var latestTs = 0;
    var GUEST_SEEN_KEY = 'robes_notice_comment_seen';

    function guestSeenTs() {
        try { return parseInt(localStorage.getItem(GUEST_SEEN_KEY), 10) || 0; } catch (e) { return 0; }
    }

    function popBadge() {
        if (!badge) return;
        badge.classList.remove('is-pop');
        void badge.offsetWidth;
        badge.classList.add('is-pop');
        setTimeout(function() { badge.classList.remove('is-pop'); }, 360);
    }

    /* 公告是服务端直接渲染的，每条公告用 data-key 记已读，存在 localStorage 里 */
    function boardReadKeys() {
        try {
            var arr = JSON.parse(localStorage.getItem(BOARD_READ_KEY) || '[]');
            return Array.isArray(arr) ? arr : [];
        } catch (e) { return []; }
    }

    function boardItemKey(el) {
        return el.getAttribute('data-key')
            || (el.getAttribute('data-date') || '') + ':' + (el.textContent || '').replace(/\s+/g, '').slice(0, 60);
    }

    function syncBoardUnread() {
        if (boardDot) boardDot.hidden = boardUnread === 0;
    }

    if (boardItems.length) {
        var boardRead = boardReadKeys();
        boardItems.forEach(function(el) {
            var key = boardItemKey(el);
            el.setAttribute('data-key', key);
            if (boardRead.indexOf(key) !== -1) return;
            boardUnread++;
            el.classList.add('is-unread');
            var textEl = el.querySelector('.notice-board-text');
            if (textEl && !textEl.querySelector('.notice-board-new')) {
                var tag = document.createElement('span');
                tag.className = 'notice-board-new';
                tag.textContent = '新';
                textEl.appendChild(tag);
            }
        });
    }
    syncBoardUnread();
    moveTabThumb();
    if (document.fonts && document.fonts.ready) {
        document.fonts.ready.then(moveTabThumb);
    }

    function api(action, params, post) {
        var qs = 'action=' + encodeURIComponent(action);
        for (var k in params) {
            if (params.hasOwnProperty(k)) qs += '&' + k + '=' + encodeURIComponent(params[k]);
        }
        var opt = { credentials: 'same-origin', cache: 'no-store' };
        var url = endpoint + '?' + qs;
        if (post) {
            opt.method = 'POST';
            opt.headers = { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' };
            opt.body = qs;
            url = endpoint;
        }
        return fetch(url, opt).then(function(r) { return r.json(); });
    }

    function renderBadge() {
        var total = unread + boardUnread + (guestNew ? 1 : 0);
        if (badge) {
            badge.hidden = total === 0;
            badge.textContent = total === 0 ? '' : (total > 99 ? '99+' : String(total));
        }
        /* 头部计数胶囊：一眼知道还剩多少没读 */
        if (headCount) {
            headCount.hidden = total === 0;
            headCount.textContent = total > 0 ? (total > 99 ? '99+' : String(total)) + ' 条未读' : '';
        }
        /* 灵动岛展开后显示的文字：有未读就报数字，没有就只留「通知中心」 */
        if (islandCount) {
            islandCount.hidden = total === 0;
            islandCount.textContent = total > 0 ? (total > 99 ? '99+' : String(total)) + ' 条通知未读' : '';
        }
        if (tabCount) {
            tabCount.hidden = (unread + (guestNew ? 1 : 0)) === 0;
            tabCount.textContent = (unread + (guestNew ? 1 : 0)) > 99 ? '99+' : String(unread + (guestNew ? 1 : 0));
        }
        if (markAllBtn) markAllBtn.hidden = unread === 0 || tab !== 'latest';
        /* 只要还有没读的提醒，胶囊就保持展开；全部读完才收回 */
        if (btn) {
            btn.classList.toggle('is-peek', total > 0);
            btn.setAttribute('aria-label', total > 0 ? '通知与公告，' + total + ' 条未读' : '通知与公告');
        }
    }

    /* 服务端返回的最新评论时间：比本地记录新就点亮铃铛 */
    function applyLatest(ts) {
        latestTs = Math.max(0, parseInt(ts, 10) || 0);
        if (canTrack || !latestTs) return;
        /* 面板正停在「最新评论」时，刚拿到的时间戳直接算看过，
           否则接口晚于打开面板返回，会在眼前又亮一次未读 */
        var fresh = latestTs > guestSeenTs();
        if (fresh && pop.classList.contains('active') && tab === 'latest') {
            try { localStorage.setItem(GUEST_SEEN_KEY, String(latestTs)); } catch (e) {}
            fresh = false;
        }
        if (fresh === guestNew) return;
        guestNew = fresh;
        renderBadge();
        if (fresh) popBadge();
    }

    /* 打开铃铛 / 切到「最新评论」即视为看过，清掉访客态的提醒 */
    function markGuestSeen() {
        if (canTrack || !latestTs) return;
        if (latestTs > guestSeenTs()) {
            try { localStorage.setItem(GUEST_SEEN_KEY, String(latestTs)); } catch (e) {}
        }
        if (!guestNew) return;
        guestNew = false;
        renderBadge();
    }

    function setUnread(n) {
        var prev = unread;
        unread = Math.max(0, parseInt(n, 10) || 0);
        /* 同步各 Tab 的缓存快照：否则「全部已读」后切走再切回，
           会用缓存里的旧未读数把红点又点亮 */
        if (tabCache) {
            for (var k in tabCache) {
                if (tabCache.hasOwnProperty(k) && tabCache[k] && typeof tabCache[k].unread === 'number') {
                    tabCache[k].unread = unread;
                }
            }
        }
        renderBadge();
        if (unread > prev && unread > 0) popBadge();
    }

    function markBoardSeen() {
        if (!boardItems.length || boardUnread === 0) return;
        var keys = boardReadKeys();
        boardItems.forEach(function(el) {
            if (!el.classList.contains('is-unread')) return;
            var key = el.getAttribute('data-key');
            if (key && keys.indexOf(key) === -1) keys.push(key);
            /* 先把高亮淡出去，让用户看到哪几条是新的 */
            el.classList.remove('is-unread');
            var tag = el.querySelector('.notice-board-new');
            if (tag) tag.classList.add('is-fading');
        });
        try { localStorage.setItem(BOARD_READ_KEY, JSON.stringify(keys.slice(-400))); } catch (e) {}
        boardUnread = 0;
        syncBoardUnread();
        renderBadge();
        setTimeout(function() {
            boardItems.forEach(function(el) {
                var tag = el.querySelector('.notice-board-new.is-fading');
                if (tag && tag.parentNode) tag.parentNode.removeChild(tag);
            });
        }, 700);
    }

    /* 访客没有服务端未读数时，靠公告 / 最新评论的本地已读状态点亮胶囊 */
    function refreshCount() {
        var seq = ++countSeq;
        api('count').then(function(d) {
            if (seq !== countSeq || !d || !d.ok) return;
            if (canTrack) setUnread(d.unread);
            applyLatest(d.latest);
            renderBadge();
        }).catch(function() {});
    }

    function clearNewMarks() {
        Array.prototype.forEach.call(list.querySelectorAll('.notice-item.is-new'), function(el) {
            el.classList.remove('is-new');
        });
        Array.prototype.forEach.call(list.querySelectorAll('.notice-dot'), function(el) {
            if (el.parentNode) el.parentNode.removeChild(el);
        });
    }

    function markAllRead() {
        if (!canTrack) return;
        countSeq++;
        api('seen', null, true).then(function(d) {
            if (d && d.ok) {
                setUnread(0);
                clearNewMarks();
            }
        }).catch(function() {});
    }

    function setOpen(open) {
        pop.classList.toggle('active', open);
        btn.classList.toggle('is-active', open);
        /* 面板打开时胶囊保持展开，和下方面板连成一块 */
        btn.classList.toggle('is-open', open);
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        pop.setAttribute('aria-hidden', open ? 'false' : 'true');
        /* 收起时把高度还给内容，下次展开重新按内容量一次 */
        if (!open) {
            pop.style.height = '';
            if (list) list.style.minHeight = '';
            clearTimeout(resizeTimer);
            pop.classList.remove('is-resizing');
        } else {
            /* 面板从隐藏到可见后量一次，滑块宽度才对得上 */
            requestAnimationFrame(moveTabThumb);
        }
    }

    /* 内容高度变化时平滑过渡。
       关键：展开期间高度始终保留为具体 px，这样换 Tab / 骨架 → 内容时
       才能量到「旧高度」，否则高度已是 auto，会直接跳变。 */
    var resizeTimer = 0;
    function syncHeight() {
        if (!pop.classList.contains('active')) return;
        /* 高度过渡期间先关掉内部滚动：新内容比当前高度高时，
           中间帧会闪出一条滚动条再消失，看起来像画面跳了一下 */
        pop.classList.add('is-resizing');
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function() {
            pop.classList.remove('is-resizing');
        }, 460);
        var from = parseFloat(pop.style.height);
        /* 用 offsetHeight 而不是 getBoundingClientRect：
           面板刚展开时还在 scale(.94) 的过渡里，rect 会被缩掉 6%，
           量出来的高度偏小，内容就会在里面滚一条 */
        if (!from) from = pop.offsetHeight;
        pop.style.height = 'auto';
        var to = pop.offsetHeight;
        if (Math.abs(to - from) < 1) {
            pop.style.height = to + 'px';
            return;
        }
        pop.style.height = from + 'px';
        void pop.offsetWidth;
        pop.style.height = to + 'px';
    }

    /* 心情表单展开 / 漂流瓶换一条时，内容高度会变，通知面板重新量一次 */
    document.addEventListener('robes:panel-resize', function () { syncHeight(); });

    /* 每个 Tab 记住上一次的结果，来回切换就不用再等接口；
       3 分钟内直接用缓存，重新打开面板时会静默刷新一次保持新鲜 */
    var tabCache = {};
    var CACHE_TTL = 180000;

    function render(d, append) {
        if (append) {
            list.insertAdjacentHTML('beforeend', d.html);
        } else {
            list.innerHTML = d.html;
            list.scrollTop = 0;
        }
        hasMore = !!d.hasMore;
        if (foot) foot.hidden = !hasMore || tab === 'board' || (tab === 'vibe' || tab === 'mood');
        if (canTrack && typeof d.unread === 'number') setUnread(d.unread);
        if (append && tabCache[tab]) {
            tabCache[tab].html += d.html;
            tabCache[tab].hasMore = hasMore;
            tabCache[tab].page = page;
            tabCache[tab].at = Date.now();
        } else if (!append) {
            tabCache[tab] = {
                html: d.html,
                hasMore: hasMore,
                page: 1,
                unread: typeof d.unread === 'number' ? d.unread : unread,
                at: Date.now()
            };
        }
        syncHeight();
    }

    var SKELETON = '<div class="notice-skeleton"><span></span><span></span><span></span></div>';
    /* 「我的评论」通常条数少，只给一行骨架，避免空占三行高度 */
    var SKELETON_ONE = '<div class="notice-skeleton"><span></span></div>';
    function skeletonFor(t) { return t === 'mine' ? SKELETON_ONE : SKELETON; }

    /* 切 Tab 时先用骨架顶上，但把列表区锁到切换前的高度，
       这样只会「一次」从旧高度过渡到新内容高度，不会先塌到骨架高度再弹回来 */
    var pendingLockH = -1;
    function lockListHeight() {
        if (!list) return;
        var h = pendingLockH >= 0 ? pendingLockH : list.offsetHeight;
        pendingLockH = -1;
        list.style.minHeight = Math.max(h, 0) + 'px';
    }

    function unlockListHeight() {
        if (list) list.style.minHeight = '';
    }

    var reqSeq = 0;

    function load(append, silent) {
        /* 切换 Tab 时允许新的请求顶掉旧请求；追加加载则避免重复触发 */
        if (append && (loading || !hasMore)) return Promise.resolve(false);
        var seq = ++reqSeq;
        loading = true;
        var reqPage = append ? page + 1 : 1;
        if (!append && !silent) {
            lockListHeight();
            list.innerHTML = skeletonFor(tab);
            if (foot) foot.hidden = true;
            syncHeight();
        } else if (append && moreBtn) {
            moreBtn.disabled = true;
            moreBtn.textContent = '加载中…';
        }
        return api('list', { tab: tab, page: reqPage }).then(function(d) {
            if (seq !== reqSeq) return false;
            if (d && d.ok) {
                unlockListHeight();
                render(d, append);
                page = reqPage;
                loadedAt = Date.now();
                return true;
            } else if (!append && !silent) {
                unlockListHeight();
                list.innerHTML = '<div class="notice-empty">加载失败，请稍后重试</div>';
                syncHeight();
            } else if (append && typeof showToast === 'function') {
                showToast('加载更多失败，请稍后重试', 'error');
            }
            return false;
        }).catch(function() {
            if (seq !== reqSeq) return false;
            if (!append && !silent) {
                unlockListHeight();
                list.innerHTML = '<div class="notice-empty">网络异常，请稍后重试</div>';
                syncHeight();
            }
            return false;
        }).finally(function() {
            if (seq !== reqSeq) return;
            loading = false;
            if (moreBtn) {
                moreBtn.disabled = false;
                moreBtn.textContent = '加载更多';
            }
        });
    }

    var TAB_ORDER = ['board', 'mood', 'vibe', 'mine', 'latest'];
    var viewDir = 1;
    /* 切换方向决定内容从哪边推进来：往右切从右边进，往左切从左边进 */
    function animateView(next) {
        var el = next === 'board' ? boardView
            : (next === 'vibe' ? vibeView : (next === 'mood' ? moodView : list));
        if (!el) return;
        el.style.setProperty('--tab-dx', (viewDir < 0 ? -10 : 10) + 'px');
        el.classList.remove('notice-view-in');
        void el.offsetWidth;
        el.classList.add('notice-view-in');
    }

    function showTab(next) {
        var prevTab = tab;
        viewDir = TAB_ORDER.indexOf(next) - TAB_ORDER.indexOf(prevTab);
        tab = next;
        /* 让还在路上的旧请求失效，避免它把上一个 Tab 的内容画到当前 Tab */
        reqSeq++;
        loading = false;
        /* 切走之前先记下当前可见区域的高度，给骨架占位用 */
        var visible = (boardView && !boardView.hidden) ? boardView
            : (vibeView && !vibeView.hidden ? vibeView
            : (moodView && !moodView.hidden ? moodView
            : (list && !list.hidden ? list : null)));
        /* 「我的评论」通常很短，不沿用上一个 Tab 的高度，直接收紧 */
        pendingLockH = (visible && next !== 'mine') ? visible.offsetHeight : -1;
        tabs.forEach(function(t) {
            t.classList.toggle('is-active', t.getAttribute('data-tab') === next);
        });
        moveTabThumb();
        var isBoard = next === 'board';
        var isVibe = next === 'vibe';
        var isMood = next === 'mood';
        /* 这两个视图没有固定高度，允许面板整体长高 */
        pop.classList.toggle('is-tall', isVibe || isMood);
        if (boardView) boardView.hidden = !isBoard;
        if (list) list.hidden = isBoard || isVibe || isMood;
        if (vibeView) vibeView.hidden = !isVibe;
        if (moodView) moodView.hidden = !isMood;
        animateView(next);
        if (isBoard) {
            if (foot) foot.hidden = true;
            if (markAllBtn) markAllBtn.hidden = true;
            pendingLockH = -1;
            markBoardSeen();
            syncHeight();
            return;
        }
        if (isVibe || isMood) {
            if (foot) foot.hidden = true;
            if (markAllBtn) markAllBtn.hidden = true;
            pendingLockH = -1;
            syncHeight();
            return;
        }
        if (next === 'latest') markGuestSeen();
        if (markAllBtn) markAllBtn.hidden = unread === 0 || tab !== 'latest';

        /* 「我的评论」每次点开都重新取：刚发完评论、切回浏览器都可能变，
           3 分钟缓存只会让人以为自己的评论丢了 */
        var cached = next === 'mine' ? null : tabCache[next];
        if (cached && Date.now() - cached.at < CACHE_TTL) {
            pendingLockH = -1;
            page = cached.page || 1;
            hasMore = !!cached.hasMore;
            loadedAt = cached.at;
            unlockListHeight();
            list.innerHTML = cached.html;
            list.scrollTop = 0;
            if (foot) foot.hidden = !hasMore;
            if (canTrack && typeof cached.unread === 'number') setUnread(cached.unread);
            if (unread === 0) clearNewMarks();
            syncHeight();
            return;
        }
        page = 1;
        hasMore = false;
        loadedAt = 0;
        load(false);
    }

    /* 点击立即展开（骨架占位），数据回来后再填充，不再等接口 */
    function togglePanel() {
        if (pop.classList.contains('active')) {
            setOpen(false);
            return;
        }
        pop.classList.toggle('is-tall', tab === 'vibe' || tab === 'mood');
        placePanel();
        setOpen(true);
        if (tab === 'board') {
            markBoardSeen();
            return;
        }
        if ((tab === 'vibe' || tab === 'mood')) return;
        markGuestSeen();
        if (!list.querySelector('.notice-item') && !list.querySelector('.notice-skeleton')) {
            /* 预取还没回来时先铺骨架，避免出现空白面板 */
            if (loading) list.innerHTML = skeletonFor(tab);
            else load(false);
        } else if (loadedAt && Date.now() - loadedAt > 45000) {
            load(false, true);
        }
    }

    /* 鼠标移入/聚焦时先偷偷取一页，点开基本就是现成的 */
    var prefetched = false;
    function prefetch() {
        if (prefetched || tab === 'board' || (tab === 'vibe' || tab === 'mood') || loading) return;
        if (list.querySelector('.notice-item')) return;
        prefetched = true;
        load(false, true);
    }
    btn.addEventListener('mouseenter', prefetch);
    btn.addEventListener('focus', prefetch);

    btn.addEventListener('click', function(e) {
        e.stopPropagation();
        var playing = btn.classList.contains('is-playing');
        var willOpen = !pop.classList.contains('active');
        togglePanel();
        /* 正在放歌时点胶囊，直接落到「心情」，省得再找那张歌卡 */
        if (playing && willOpen) showTab('mood');
    });

    if (moreBtn) {
        moreBtn.addEventListener('click', function() { load(true); });
    }

    if (markAllBtn) {
        markAllBtn.addEventListener('click', markAllRead);
    }

    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            refreshBtn.classList.remove('is-spinning');
            void refreshBtn.offsetWidth;
            refreshBtn.classList.add('is-spinning');
            setTimeout(function() { refreshBtn.classList.remove('is-spinning'); }, 650);
            if (tab !== 'board' && (tab !== 'vibe' && tab !== 'mood')) {
                load(false, true);
            }
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            setOpen(false);
        });
    }

    /* 键盘左右方向键切 Tab，Tab 本身可聚焦后即可用 */
    if (tabsWrap) {
        tabsWrap.addEventListener('keydown', function(e) {
            if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
            var idx = tabs.indexOf(document.activeElement);
            if (idx === -1) return;
            e.preventDefault();
            var nextIdx = (idx + (e.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
            tabs[nextIdx].focus();
            var k = tabs[nextIdx].getAttribute('data-tab');
            if (k && k !== tab) showTab(k);
        });
    }

    /* 点击单条：只把这一条标为已读，不等同于「全部已读」 */
    list.addEventListener('click', function(e) {
        var item = e.target.closest ? e.target.closest('.notice-item') : null;
        if (!item || !canTrack || tab !== 'latest' || !item.classList.contains('is-new')) return;
        var coid = parseInt(item.getAttribute('data-coid'), 10);
        if (!coid) return;
        if (navigator.sendBeacon) {
            var fd = new FormData();
            fd.append('action', 'read');
            fd.append('coid', String(coid));
            navigator.sendBeacon(endpoint, fd);
        } else {
            api('read', { coid: coid }, true).catch(function() {});
        }
        item.classList.remove('is-new');
        var dot = item.querySelector('.notice-dot');
        if (dot && dot.parentNode) dot.parentNode.removeChild(dot);
        setUnread(unread - 1);
    });

    /* 列表滚到底自动续载，按钮保留兜底 */
    list.addEventListener('scroll', function() {
        if (tab === 'board' || !hasMore || loading) return;
        if (list.scrollTop + list.clientHeight >= list.scrollHeight - 48) load(true);
    }, { passive: true });

    /* 铃铛红点最多 1 分钟内更新（未登录访客也按本地记录判断新评论） */
    setInterval(function() {
        if (document.hidden) return;
        refreshCount();
    }, 60000);
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden) refreshCount();
    });
    refreshCount();

    /* 页面滚动时收起下拉面板（面板内部滚动不会触发） */
    var scroller = document.querySelector('.content-scroll');
    if (scroller) {
        scroller.addEventListener('scroll', function() {
            if (pop.classList.contains('active')) setOpen(false);
        }, { passive: true });
    }

    tabs.forEach(function(el) {
        el.addEventListener('click', function() {
            var next = el.getAttribute('data-tab');
            if (!next || next === tab) return;
            showTab(next);
        });
    });

    document.addEventListener('click', function(e) {
        if (!pop.classList.contains('active')) return;
        /* 点击面板内元素后会重渲染（比如选中一首歌会把结果列表换掉），
           此时 e.target 已经脱离文档，contains 会误判成「点在外面」。
           composedPath 是派发时算好的，能正确包含面板本身。 */
        var path = e.composedPath ? e.composedPath() : [];
        if (pop.contains(e.target) || btn.contains(e.target) ||
            path.indexOf(pop) !== -1 || path.indexOf(btn) !== -1) return;
        setOpen(false);
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && pop.classList.contains('active')) setOpen(false);
    });

    window.noticeRefresh = refreshCount;
    window.noticeClose = function() {
        if (pop.classList.contains('active')) setOpen(false);
    };

    /* 评论提交成功后调用：丢掉旧列表缓存，并把游客身份点亮，
       这样不用刷新页面也能立刻在「我的评论」里看到自己刚发的评论 */
    window.noticeAfterComment = function() {
        tabCache = {};
        loadedAt = 0;
        if (!canTrack) {
            canTrack = true;
            pop.setAttribute('data-identity', '1');
            pop.setAttribute('data-mine', '1');
            tabs.forEach(function(t) {
                var k = t.getAttribute('data-tab');
                if (k === 'mine' || k === 'board') t.hidden = false;
            });
        }
        /* 面板正开着就直接换一份新列表，否则下次点开也会因 loadedAt 归零重新取 */
        if (pop.classList.contains('active') && tab !== 'board') load(false, true);
        refreshCount();
    };

    /* 首屏空闲时就把「最新评论」取回来，第一次点开铃铛也是现成的 */
    if (window.requestIdleCallback) {
        requestIdleCallback(prefetch, { timeout: 3000 });
    } else {
        setTimeout(prefetch, 2000);
    }
}

function sharePost(url, title) {
    if (navigator.share) navigator.share({ title: title, url: url });
    else if (navigator.clipboard) {
        navigator.clipboard.writeText(url)
            .then(function() { showToast('链接已复制', 'success'); })
            .catch(function() { showToast('复制失败，请手动复制', 'error'); });
    } else {
        var ta = document.createElement('textarea');
        ta.value = url; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); showToast('链接已复制', 'success'); }
        catch (_e) { showToast('复制失败，请手动复制', 'error'); }
        ta.remove();
    }
}


var LB = {
    items: [], idx: 0,
    scale: 1, tx: 0, ty: 0, rot: 0,
    active: false, globalBound: false,
    drag: null, pinch: null, swipe: null,
    token: 0
};




function bindArchiveTabs() {
    var tabs = document.getElementById('archTabs');
    var list = document.getElementById('archList');
    if (!tabs || !list) return;
    tabs.onclick = function(e) {
        var btn = e.target.closest('.pg-arch-tab');
        if (!btn) return;
        var year = btn.getAttribute('data-year');
        tabs.querySelectorAll('.pg-arch-tab').forEach(function(t) { t.classList.remove('active'); });
        btn.classList.add('active');
        list.querySelectorAll('.pg-arch-panel').forEach(function(p) {
            p.style.display = p.getAttribute('data-year') === year ? '' : 'none';
        });
        var panel = list.querySelector('.pg-arch-panel[data-year="' + year + '"]');
        if (panel) retriggerWaterfall(panel);
    };
}


document.addEventListener('click', function(e) {
    var panel = document.getElementById('cmt-emoji-panel');
    if (panel && panel.style.display !== 'none' && !e.target.closest('.cmt-emoji-panel') && !e.target.closest('.cmt-emoji-btn')) {
        closeEmojiPanel();
    }
});

function initTableWrap() {
    document.querySelectorAll('.article-content table').forEach(function(table) {
        if (table.parentNode.classList.contains('table-wrap')) return;
        var wrap = document.createElement('div');
        wrap.className = 'table-wrap';
        table.parentNode.insertBefore(wrap, table);
        wrap.appendChild(table);
        var updateFade = function() {
            var max = wrap.scrollWidth - wrap.clientWidth;
            wrap.classList.toggle('fade-left', wrap.scrollLeft > 2);
            wrap.classList.toggle('fade-right', wrap.scrollLeft < max - 2);
        };
        updateFade();
        requestAnimationFrame(updateFade);
        wrap.addEventListener('scroll', updateFade, {passive: true});
    });
    if (!window.__tableFadeBound) {
        window.__tableFadeBound = true;
        window.addEventListener('resize', function() {
            document.querySelectorAll('.table-wrap').forEach(function(w) {
                var max = w.scrollWidth - w.clientWidth;
                w.classList.toggle('fade-left', w.scrollLeft > 2);
                w.classList.toggle('fade-right', w.scrollLeft < max - 2);
            });
        });
    }
}

function initSearchHighlight() {
    var params = new URLSearchParams(location.search);
    var keyword = params.get('s');
    if (!keyword || keyword.length < 2) return;
    var content = document.querySelector('.content-scroll');
    if (!content) return;
    var walker = document.createTreeWalker(content, NodeFilter.SHOW_TEXT, null, false);
    var nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    var re = new RegExp('(' + keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi');
    nodes.forEach(function(node) {
        if (!node.nodeValue.trim() || node.parentNode.closest('.search-highlight')) return;
        if (!re.test(node.nodeValue)) return;
        var span = document.createElement('span');
        span.innerHTML = node.nodeValue.replace(re, '<span class="search-highlight">$1</span>');
        node.parentNode.replaceChild(span, node);
    });
}

    /* 代码块增强：语言角标 + 超长代码折叠 */
    var CODE_LANGS = {
        js: 'JavaScript', javascript: 'JavaScript', ts: 'TypeScript', typescript: 'TypeScript',
        php: 'PHP', html: 'HTML', xml: 'XML', css: 'CSS', scss: 'SCSS', less: 'Less',
        json: 'JSON', bash: 'Shell', sh: 'Shell', shell: 'Shell', zsh: 'Shell',
        python: 'Python', py: 'Python', java: 'Java', go: 'Go', golang: 'Go',
        sql: 'SQL', yaml: 'YAML', yml: 'YAML', md: 'Markdown', markdown: 'Markdown',
        c: 'C', cpp: 'C++', csharp: 'C#', cs: 'C#', rust: 'Rust', rs: 'Rust',
        vue: 'Vue', jsx: 'JSX', tsx: 'TSX', nginx: 'Nginx', ini: 'INI', toml: 'TOML',
        dockerfile: 'Dockerfile', diff: 'Diff', http: 'HTTP'
    };
    function codeLangName(pre, code) {
        var cls = (pre.className || '') + ' ' + (code ? code.className || '' : '');
        var m = cls.match(/(?:language|lang)-([a-z0-9+#]+)/i);
        var key = m ? m[1].toLowerCase() : String(pre.getAttribute('data-lang') || '').toLowerCase();
        if (!key || key === 'undefined' || key === 'plaintext') return '';
        return CODE_LANGS[key] || key.toUpperCase();
    }
    function enhanceCodeBlock(pre, code) {
        if (!code) return;
        var name = codeLangName(pre, code);
        if (name && !pre.querySelector('.code-lang')) {
            var tag = document.createElement('span');
            tag.className = 'code-lang';
            tag.textContent = name;
            pre.appendChild(tag);
        }
        if (pre.getAttribute('data-rc-code')) return;
        pre.setAttribute('data-rc-code', '1');
        var MAX = 420;
        if (code.scrollHeight > MAX + 40) {
            pre.classList.add('is-collapsed');
            var ex = document.createElement('button');
            ex.type = 'button';
            ex.className = 'code-expand-btn';
            ex.innerHTML = '<i class="ri-arrow-down-double-line"></i><span>展开全部</span>';
            ex.addEventListener('click', function() {
                var collapsed = pre.classList.toggle('is-collapsed');
                pre.classList.toggle('is-expanded', !collapsed);
                ex.innerHTML = collapsed
                    ? '<i class="ri-arrow-down-double-line"></i><span>展开全部</span>'
                    : '<i class="ri-arrow-up-double-line"></i><span>收起代码</span>';
                if (collapsed) pre.scrollIntoView({ block: 'nearest' });
            });
            pre.appendChild(ex);
        }
    }

function initCodeCopy() {
    document.querySelectorAll('.article-content pre').forEach(function(pre) {
        if (pre.querySelector('.code-copy-btn')) return;
        var btn = document.createElement('button');
        btn.className = 'code-copy-btn';
        btn.innerHTML = '<i class="ri-file-copy-line"></i>';
        btn.title = '复制代码';
        btn.addEventListener('click', function() {
            var code = pre.querySelector('code');
            var text = code ? code.textContent : pre.textContent;
            navigator.clipboard.writeText(text).then(function() {
                btn.innerHTML = '<i class="ri-check-line"></i>';
                btn.classList.add('copied');
                setTimeout(function() {
                    btn.innerHTML = '<i class="ri-file-copy-line"></i>';
                    btn.classList.remove('copied');
                }, 1500);
            }).catch(function() {
                var ta = document.createElement('textarea');
                ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
                document.body.appendChild(ta); ta.select();
                try { document.execCommand('copy');
                    btn.innerHTML = '<i class="ri-check-line"></i>'; btn.classList.add('copied');
                    setTimeout(function() { btn.innerHTML = '<i class="ri-file-copy-line"></i>'; btn.classList.remove('copied'); }, 1500);
                } catch(e) {}
                document.body.removeChild(ta);
            });
        });
        pre.style.position = 'relative';
        pre.appendChild(btn);
        enhanceCodeBlock(pre, pre.querySelector('code'));
    });
}




function initScrollAutoHide() {
  var feed = document.getElementById('feed');
  if (!feed) return;
  var scrollTimer = null;
  feed.addEventListener('scroll', function() {
    feed.classList.add('sb-active');
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(function() {
      feed.classList.remove('sb-active');
    }, 800);
  });
}

var WATERFALL_SELECTORS = [
  '.post-card', '.post-card-simple', '.friend-feed-card',
  '.cmt-item', '.cmt-card', '.photo-item',
  '.link-card', '.album-card', '.pg-arch-row',
  '.abt-head', '.abt-stats', '.abt-sec', '.abt-cta'
].join(',');

function initWaterfall() {
  var cards = document.querySelectorAll(WATERFALL_SELECTORS);
  if (!cards.length) return;
  if (typeof IntersectionObserver !== 'undefined') {
    var observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          var card = entry.target;
          if (!card.classList.contains('card-visible')) {
            var parent = card.parentElement;
            var siblings = parent ? Array.from(parent.querySelectorAll(WATERFALL_SELECTORS + ':not(.card-visible)')) : [card];
            var idx = siblings.indexOf(card);
            card.style.animationDelay = (idx * 0.04) + 's';
            card.classList.add('card-visible');
          }
          observer.unobserve(card);
        }
      });
    }, { threshold: 0.05 });
    cards.forEach(function(card) { observer.observe(card); });
  } else {
    cards.forEach(function(card) { card.classList.add('card-visible'); });
  }
}

function retriggerWaterfall(container) {
  var cards = container.querySelectorAll(WATERFALL_SELECTORS);
  cards.forEach(function(card, i) {
    card.classList.remove('card-visible');
    void card.offsetWidth;
    card.style.animationDelay = (i * 0.04) + 's';
    card.classList.add('card-visible');
  });
}

var _linkCheckCache = {};  
var _linkCheckTTL = 3600000; 
var _linkCheckKey = 'robes_link_check_v2'; 

function _loadLinkCache() {
  try {
    var raw = localStorage.getItem(_linkCheckKey);
    if (raw) {
      var data = JSON.parse(raw);
      var now = Date.now();
      var valid = {};
      for (var url in data) {
        if (data[url] && data[url].ts && (now - data[url].ts) < _linkCheckTTL) {
          valid[url] = data[url];
        }
      }
      _linkCheckCache = valid;
      _saveLinkCache(); 
    }
  } catch(_e) {}
}

function _saveLinkCache() {
  try {
    localStorage.setItem(_linkCheckKey, JSON.stringify(_linkCheckCache));
  } catch(_e) {}
}

_loadLinkCache();

function initLinkCheck() {
  if (typeof ROBES !== 'undefined' && !ROBES.enableLinkCheck) {
    document.querySelectorAll('.link-status').forEach(function(dot) {
      dot.style.display = 'none';
    });
    return;
  }
  var cards = document.querySelectorAll('.link-card[data-url]');
  if (!cards.length) return;

  var pending = [];
  var now = Date.now();

  cards.forEach(function(card) {
    var url = card.getAttribute('data-url');
    var dot = card.querySelector('.link-status');
    if (!url || !dot) return;

    var cached = _linkCheckCache[url];
    if (cached && cached.ts && (now - cached.ts) < _linkCheckTTL) {
      _applyResult(dot, cached.status);
      return;
    }
    if (card.dataset.checking === '1') return;
    card.dataset.checking = '1';
    dot.className = 'link-status checking';
    dot.title = '检测中…';
    dot.textContent = '检测中';
    pending.push({ card: card, url: url, dot: dot });
  });

  if (!pending.length) return;
  _serverCheck(pending);
}

function _applyResult(dot, result) {
  if (result === 'ok') {
    dot.className = 'link-status online';
    dot.title = '正常';
    dot.textContent = '在线';
  } else if (result === 'unknown') {
    dot.className = 'link-status unknown';
    dot.title = '检测超时';
    dot.textContent = '未知';
  } else {
    dot.className = 'link-status offline';
    dot.title = '无法访问';
    dot.textContent = '离线';
  }
}

function _markResult(url, status) {
  _linkCheckCache[url] = { status: status, ts: Date.now() };
  _saveLinkCache();
}

function _serverCheck(pending) {
  var apiUrl = (typeof ROBES !== 'undefined' && ROBES.themeUrl ? ROBES.themeUrl : '/usr/themes/robes/') + 'extras/api-link-check.php';

  for (var i = 0; i < pending.length; i += 8) {
    _serverCheckChunk(pending.slice(i, i + 8), apiUrl);
  }
}

function _serverCheckChunk(pending, apiUrl) {
  var urls = pending.map(function(p) { return p.url; });

  fetch(apiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: urls.map(function(u) { return 'urls[]=' + encodeURIComponent(u); }).join('&')
  })
  .then(function(r) {
    if (!r.ok) throw new Error('http ' + r.status);
    return r.json();
  })
  .then(function(data) {
    pending.forEach(function(p) {
      var r = data[p.url];
      if (!r) { _applyResult(p.dot, 'unknown'); p.card.dataset.checking = '0'; return; }
      var status = r.ok ? 'ok' : 'fail';
      _markResult(p.url, status);
      _applyResult(p.dot, status);
      p.card.dataset.checking = '0';
    });
  })
  .catch(function() {
    pending.forEach(function(p) {
      _applyResult(p.dot, 'unknown');
      p.card.dataset.checking = '0';
    });
  });
}

function initCodeHighlight() {
    var pres = document.querySelectorAll('.article-content pre code:not(.hljs)');
    if (!pres.length) return;
    var run = function(blocks) {
        blocks.forEach(function(block) {
            var pre = block.parentNode;
            if (pre && pre.tagName === 'PRE') enhanceCodeBlock(pre, block);
        });
        if (typeof hljs !== 'undefined') {
            blocks.forEach(function(block) { hljs.highlightElement(block); });
            blocks.forEach(function(block) {
                var pre = block.parentNode;
                if (pre && pre.tagName === 'PRE') enhanceCodeBlock(pre, block);
            });
        }
    };
    if (typeof hljs === 'undefined') {
        var script = document.createElement('script');
        script.src = 'https://cdn.bootcdn.net/ajax/libs/highlight.js/11.9.0/highlight.min.js';
        script.onload = function() { run(pres); };
        document.head.appendChild(script);
    } else {
        run(pres);
    }
}

function initLazyLoad() {
    document.querySelectorAll('.article-content img:not([loading])').forEach(function(img) {
        img.setAttribute('loading', 'lazy');
    });
}

function initImgLoading() {
    var imgs = document.querySelectorAll('.post-cover img, .album-cover img, .friend-feed-avatar img, .link-avatar img, .photo-item img, .article-content img');
    if (!imgs.length) return;
    imgs.forEach(function(img) {
        if (img.getAttribute('data-img-observed')) return;
        img.setAttribute('data-img-observed', '1');
        if (img.complete && img.naturalWidth > 0) {
            img.classList.add('loaded');
            return;
        }
        var wrap = img.closest('.post-cover, .album-cover, .friend-feed-avatar, .link-avatar, .photo-item');
        if (!wrap && img.closest('.article-content') && !img.closest('.post-music, .post-ref')) {
            wrap = document.createElement('span');
            wrap.className = 'img-shimmer-wrap';
            img.parentNode.insertBefore(wrap, img);
            wrap.appendChild(img);
        }
        if (wrap) wrap.classList.add('img-loading');
        img.classList.add('img-fade');
        var reveal = function() {
            img.classList.add('loaded');
            if (wrap) wrap.classList.remove('img-loading');
            img.classList.remove('img-fade');
        };
        img.addEventListener('load', reveal, { once: true });
        img.addEventListener('error', reveal, { once: true });
    });
}

function bindLinksTabs() {
    var tabs = document.querySelectorAll('#linksCategoryTabs .links-cat-tab');
    if (!tabs.length) return;
    var groups = document.querySelectorAll('.links-category-group');
    tabs.forEach(function(tab) {
        if (tab.dataset.bound) return;
        tab.dataset.bound = '1';
        tab.addEventListener('click', function() {
            var cat = this.getAttribute('data-category');
            tabs.forEach(function(t) { t.classList.remove('active'); });
            this.classList.add('active');
            groups.forEach(function(g) {
                g.style.display = (g.getAttribute('data-category') === cat) ? '' : 'none';
            });
            var activeGroup = document.querySelector('.links-category-group[data-category="' + cat + '"]');
            if (activeGroup) retriggerWaterfall(activeGroup);
            initLinkCheck();
        });
    });
}

/* 分段胶囊滑块：归档年份 / 友链分类 / 通知卡片 / 侧栏导航共用 */
var slideGroupRefreshers = [];
function refreshSlideGroups(animate) {
    slideGroupRefreshers.forEach(function(fn) { fn(animate === true); });
}

function bindSlideGroup(wrap, tabSelector) {
    if (!wrap) return;
    var tabs = Array.prototype.slice.call(wrap.querySelectorAll(tabSelector));
    if (!tabs.length) return;
    var thumb = wrap.querySelector('.slide-thumb');
    if (!thumb) {
        thumb = document.createElement('span');
        thumb.className = 'slide-thumb';
        thumb.setAttribute('aria-hidden', 'true');
        wrap.appendChild(thumb);
    }
    var active = wrap.querySelector(tabSelector + '.active')
        || wrap.querySelector(tabSelector + '.is-active')
        || null;

    function moveTo(el, animate) {
        if (!el) {
            /* 立即隐藏，避免切页时旧高亮和新高亮同时亮着闪一下 */
            thumb.style.transition = 'none';
            thumb.style.opacity = '0';
            void thumb.offsetWidth;
            thumb.style.transition = '';
            return;
        }
        /* 从隐藏状态出现时直接落位，不要从分组顶部“长”出来 */
        var wasHidden = thumb.style.opacity === '0' || thumb.offsetWidth === 0;
        if (!animate || wasHidden) thumb.style.transition = 'none';
        thumb.style.opacity = '';
        thumb.style.width = el.offsetWidth + 'px';
        thumb.style.height = el.offsetHeight + 'px';
        thumb.style.transform = 'translate3d(' + el.offsetLeft + 'px,' + el.offsetTop + 'px,0)';
        if (!animate || wasHidden) {
            void thumb.offsetWidth;
            thumb.style.transition = '';
        }
    }

    moveTo(active, false);
    if (wrap.dataset.slideBound === '1') return;
    wrap.dataset.slideBound = '1';

    function resetPreview() {
        wrap.classList.remove('is-previewing');
        moveTo(active, true);
    }

    /* 侧栏「导航」和「分类」两个分组同时只保留一个高亮，避免两块白底叠在一起闪 */
    function hideSiblingThumbs() {
        if (!wrap.classList.contains('nav-group')) return;
        Array.prototype.forEach.call(document.querySelectorAll('.nav-group'), function(g) {
            if (g === wrap) return;
            g.classList.remove('is-previewing');
            var th = g.querySelector('.slide-thumb');
            if (!th) return;
            th.style.transition = 'none';
            th.style.opacity = '0';
            void th.offsetWidth;
            th.style.transition = '';
        });
    }

    slideGroupRefreshers.push(function(animate) {
        var cur = wrap.querySelector(tabSelector + '.active')
            || wrap.querySelector(tabSelector + '.is-active');
        active = cur;
        moveTo(active, animate === true);
    });

    tabs.forEach(function(tab) {
        tab.addEventListener('pointerenter', function(e) {
            if (e.pointerType === 'touch') return;
            wrap.classList.add('is-previewing');
            hideSiblingThumbs();
            moveTo(tab, true);
        });
        tab.addEventListener('click', function() {
            active = tab;
            moveTo(tab, true);
            hideSiblingThumbs();
        });
    });
    wrap.addEventListener('pointerleave', function() {
        resetPreview();
        /* 离开后把另一个分组的当前高亮恢复回来 */
        if (wrap.classList.contains('nav-group')) refreshSlideGroups(true);
    });
    wrap.addEventListener('pointermove', function(e) {
        /* 侧栏导航项之间有 2px 间隙，穿过间隙时不要复位，否则高亮会来回弹 */
        if (wrap.classList.contains('nav-group')) return;
        if (!e.target.closest(tabSelector)) resetPreview();
    });
    window.addEventListener('resize', function() { moveTo(active, false); });
}

function bindArchYearSlider() {
    bindSlideGroup(document.querySelector('.arch-years'), '.links-cat-tab');
    bindSlideGroup(document.querySelector('#linksCategoryTabs:not(.arch-years)'), '.links-cat-tab');
    Array.prototype.forEach.call(document.querySelectorAll('.nav-group'), function(group) {
        bindSlideGroup(group, '.nav-item');
    });
}

function syncEditBtn() {
    var btn = document.getElementById('editPostBtn');
    if (!btn) return;
    var url = document.body.getAttribute('data-edit-url');
    if (url) { btn.href = url; btn.style.display = ''; }
    else { btn.style.display = 'none'; }
}



/* ---------- 交互细节：PJAX 进度条 / 图片渐显 ---------- */
function _pjaxBar(on) {
    var bar = document.querySelector('.pjax-bar');
    if (!bar) {
        bar = document.createElement('div');
        bar.className = 'pjax-bar';
        document.body.appendChild(bar);
    }
    if (on) {
        bar.classList.remove('done');
        bar.classList.add('active');
    } else {
        bar.classList.remove('active');
        bar.classList.add('done');
        setTimeout(function() { bar.classList.remove('done'); }, 260);
    }
}

/* 网易云音乐卡片：点击后才加载播放器，避免每篇文章都预载 iframe */

function bindMobileSearch() {
    var btn = document.getElementById('mSearchBtn');
    var pop = document.getElementById('mSearchPop');
    if (!btn || !pop || pop.dataset.bound === '1') return;
    pop.dataset.bound = '1';

    var closeBtn = document.getElementById('mSearchClose');
    var input = pop.querySelector('input[name="s"]');
    var form = pop.querySelector('form');

    var open = function() {
        pop.classList.add('is-open');
        btn.classList.add('is-active');
        pop.setAttribute('aria-hidden', 'false');
        setTimeout(function() { if (input) { input.focus(); input.select(); } }, 90);
    };
    var close = function() {
        pop.classList.remove('is-open');
        btn.classList.remove('is-active');
        pop.setAttribute('aria-hidden', 'true');
        if (input) input.blur();
    };

    btn.addEventListener('click', function(e) {
        e.stopPropagation();
        if (pop.classList.contains('is-open')) close(); else open();
    });

    if (closeBtn) closeBtn.addEventListener('click', function(e) { e.stopPropagation(); close(); });

    document.addEventListener('click', function(e) {
        if (!pop.classList.contains('is-open')) return;
        if (pop.contains(e.target) || btn.contains(e.target)) return;
        close();
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && pop.classList.contains('is-open')) close();
    });

    if (form) form.addEventListener('submit', function(e) {
        if (!input || !input.value.trim()) { e.preventDefault(); if (input) input.focus(); }
    });
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bindMobileSearch);
else bindMobileSearch();

function rebindAll() {
    initTheme(); initSectionToggle(); bindSidebarAutoClose(); bindArchiveTabs(); initCodeCopy(); initCodeHighlight(); initTableWrap(); initSearchHighlight(); initLinkCheck(); initWaterfall(); initLazyLoad(); initImgLoading(); bindLinksTabs(); bindArchYearSlider(); syncEditBtn(); initScrollAutoHide(); bindSiteInfo(); bindNotice(); bindMobileSearch();
    rcPageInits();
    var tagsEl = document.getElementById('articleTags');
    if (tagsEl && !tagsEl.querySelector('a')) tagsEl.style.display = 'none';
    var se = document.getElementById('feed');
    if (se) {
        if (!se.dataset.scrollBound) { se.dataset.scrollBound = '1'; se.addEventListener('scroll', updateScrollUI, {passive: true}); }
        updateScrollUI();
    }
    var cb = document.getElementById('sidebarCloseBtn');
    if (cb) cb.addEventListener('click', closeSidebar);
    bindMobileMenuBtn();
    bindMobileTabbarMore();
    syncMobileTabbar();
    if (typeof hoistApplyModal === 'function') hoistApplyModal();
}

/* ============ 按页面类型拆分加载的模块 ============ */
var RC_MODS = {
    home: { src: ROBES.themeUrl + '/js/home.v2.js?v=' + (ROBES.assetVer || ''), probe: 'initHero' },
    article: { src: ROBES.themeUrl + '/js/article.v2.js?v=' + (ROBES.assetVer || ''), probe: 'bindCommentForm' }
};
function rcLoadMod(name, cb) {
    var m = RC_MODS[name];
    if (!m) { if (cb) cb(); return; }
    if (typeof window[m.probe] === 'function') { if (cb) cb(); return; }
    if (m.pending) { if (cb) m.pending.push(cb); return; }
    m.pending = cb ? [cb] : [];
    var s = document.createElement('script');
    s.src = m.src;
    s.async = true;
    var done = function () {
        var q = m.pending || [];
        m.pending = null;
        for (var i = 0; i < q.length; i++) q[i]();
    };
    s.onload = done;
    s.onerror = done;
    document.head.appendChild(s);
}
/* PJAX 切换页面后，DOM 需求变了：缺哪个模块就补哪个 */
function rcPageInits() {
    var needHome = !!document.getElementById('hero');
    var needArt = !!(document.getElementById('comment-form') || document.querySelector('.article-content')
        || document.getElementById('tocInlineBtn') || document.querySelector('.link-apply'));
    if (needHome) rcLoadMod('home', function () {
        if (typeof initHero === 'function') initHero();
        if (typeof bindIndexLike === 'function') bindIndexLike();
    });
    if (needArt) rcLoadMod('article', function () {
        if (typeof bindLike === 'function') bindLike();
        if (typeof bindCommentForm === 'function') bindCommentForm();
        if (typeof bindCommentExtras === 'function') bindCommentExtras();
        if (typeof bindLightbox === 'function') bindLightbox();
        if (typeof initTOC === 'function') initTOC();
        if (typeof cmtRestoreAnchor === 'function') cmtRestoreAnchor();
        if (typeof hoistApplyModal === 'function') hoistApplyModal();
    });
    if (!needArt && typeof hoistApplyModal === 'function') hoistApplyModal();
}

(function() {
    var scrollEl = document.getElementById('feed');
    if (scrollEl) {
        if (!scrollEl.dataset.scrollBound) { scrollEl.dataset.scrollBound = '1'; scrollEl.addEventListener('scroll', updateScrollUI, {passive: true}); }
        updateScrollUI();
    }
    var scrollTopBtn = document.getElementById('scrollTopBtn');
    if (scrollTopBtn) scrollTopBtn.addEventListener('click', function() {
        var el = document.getElementById('feed');
        if (!el) return;
        if (el.scrollHeight - el.clientHeight <= 10) return;
        if (el.scrollTop < 50) smoothScrollTo(el, el.scrollHeight);
        else smoothScrollTo(el, 0);
    });
    var hamburgerBtn = document.getElementById('hamburgerBtn');
    if (hamburgerBtn) hamburgerBtn.addEventListener('click', function() { var sb = document.querySelector('.sidebar'); (sb && sb.classList.contains('open')) ? closeSidebar() : openSidebar(); });
    if (sidebarOverlay) sidebarOverlay.addEventListener('click', closeSidebar);
    var sidebarCloseBtn = document.getElementById('sidebarCloseBtn');
    if (sidebarCloseBtn) sidebarCloseBtn.addEventListener('click', closeSidebar);
    bindMobileMenuBtn();
    bindSiteInfo();
    bindNotice();
    bindMobileTabbarMore();

    function rcBoot() {
        /* 首屏也校正一次导航高亮：Typecho 的 is('index') 在归档页同样为真，
           直接打开分类页时首页与分类会同时 active */
        syncNavActive();
        bindSidebarAutoClose(); bindArchiveTabs(); initCodeCopy(); initCodeHighlight(); initTableWrap(); initLinkCheck(); initWaterfall(); bindLinksTabs(); bindArchYearSlider(); syncEditBtn(); initImgLoading(); initScrollAutoHide(); bindMobileSearch();
        initTheme(); initSectionToggle();
        rcPageInits();
        var tagsEl = document.getElementById('articleTags');
        if (tagsEl && !tagsEl.querySelector('a')) tagsEl.style.display = 'none';
    }
    if (document.readyState === 'complete') rcBoot();
    else document.addEventListener('DOMContentLoaded', rcBoot);

    if (!ROBES.enablePJAX) return;
    var container = document.querySelector('.main-body');
    if (!container) return;
    var isPjax = false, cache = {};
    window.clearPageCache = function(url) {
        if (url) { delete cache[url]; }
        else { cache = {}; }
    };

    function isPjaxLink(a) {
        if (!a || !a.href || a.target === '_blank') return false;
        if (a.href.indexOf(location.origin) !== 0) return false;
        if (a.href.indexOf('#') !== -1 && a.pathname === location.pathname) return false;
        if (a.classList.contains('no-pjax')) return false;
        return true;
    }

    /* 首页首屏点进来的文章：把当时显示的那张图带过去，文章头图沿用同一张 */
    function heroCoverUrl(a) {
        var li = a && a.closest ? a.closest('.hero-feat') : null;
        if (!li) return a ? a.href : '';
        var bg = li.getAttribute('data-bg') || '';
        if (!bg) return a.href;
        return a.href + (a.href.indexOf('?') === -1 ? '?' : '&') + 'hero=' + encodeURIComponent(bg);
    }

    loadPage = function(url, push, fetchUrl) {
        var reqUrl = fetchUrl || url;
        if (isPjax) return;
        isPjax = true;
        _pjaxBar(true);
        var loading = document.getElementById('pjaxLoading');
        if (loading) loading.classList.add('active');

        function render(html) {
            var doc = new DOMParser().parseFromString(html, 'text/html');
            var nc = doc.querySelector('.main-body');
            var nt = doc.querySelector('title');
            var nb = doc.querySelector('body');
            var targetArea = container.querySelector('.content-area');
            var nextArea = nc ? nc.querySelector('.content-area') : null;
            if (nextArea && targetArea) {
                /* 清掉上一页被移到 body 的友链申请弹窗，否则会在别的页面残留，
                  导致普通评论/回复被误判为友链申请 */
                var staleModal = document.getElementById('cmt-apply-modal');
                if (staleModal) {
                    staleModal.parentNode.removeChild(staleModal);
                    document.body.classList.remove('cmt-modal-open');
                }
                /* 只替换内容区：侧栏不重建，导航文字不会再跳一下 */
                var doSwap = function() {
                    targetArea.innerHTML = nextArea.innerHTML;
                    if (typeof window.noticeClose === 'function') window.noticeClose();
                    if (typeof window.noticeRefresh === 'function') window.noticeRefresh();
                    if (nt) document.title = nt.textContent;
                    if (nb) {
                        document.body.dataset.page = nb.dataset.page || 'inner';
                        if (nb.dataset.editUrl) document.body.dataset.editUrl = nb.dataset.editUrl;
                        else delete document.body.dataset.editUrl;
                    }
                    if (push) history.pushState(null, '', url);
                    syncNavActive();
                    rebindAll();
                    syncMobileTabbar();
                    if (typeof hoistApplyModal === 'function') hoistApplyModal();
                    var feed = document.getElementById('feed');
                    if (feed) {
                        var hash = '';
                        try { hash = new URL(url, location.href).hash; } catch (_e) { hash = location.hash; }
                        if (hash === '#comments') {
                            /* 评论翻页：停留在评论区，不回到页面顶部 */
                            var cs = document.getElementById('comments');
                            if (cs) {
                                requestAnimationFrame(function() {
                                    feed.scrollTop = feed.scrollTop + cs.getBoundingClientRect().top - feed.getBoundingClientRect().top - 16;
                                });
                            }
                        } else if (!/^#comment-\d+$/.test(hash)) {
                            feed.scrollTop = 0;
                        }
                    }
                };
                doSwap();
            } else {
                window.location.href = url;
            }
            if (loading) loading.classList.remove('active');
            _pjaxBar(false);
            isPjax = false;
        }

        if (cache[reqUrl]) { render(cache[reqUrl]); }
        else {
            fetch(reqUrl).then(function(r) { return r.text(); }).then(function(html) { cache[reqUrl] = html; render(html); })
                .catch(function() {
            isPjax = false;
            if (loading) loading.classList.remove('active');
            _pjaxBar(false);
            window.location.href = url;
        });
        }
    };

    var prefetchTimer;
    document.addEventListener('mouseover', function(e) {
        var a = e.target.closest('a');
        if (!a || !isPjaxLink(a)) return;
        var u = heroCoverUrl(a);
        if (cache[u]) return;
        clearTimeout(prefetchTimer);
        prefetchTimer = setTimeout(function() { if(cache[u])return; fetch(u).then(function(r) { return r.text(); }).then(function(h) { cache[u] = h; }).catch(function(){}); }, 80);
    });

    document.addEventListener('click', function(e) {
        var a = e.target.closest('a');
        if (!a || !isPjaxLink(a)) return;
        e.preventDefault();
        if (a.href === location.href) return;
        loadPage(a.href, true, heroCoverUrl(a));
    });

    var guardUrl = null;
    if (document.body.dataset.page === 'inner') {
        var ref = document.referrer || '';
        if (ref === '' || ref.indexOf(location.origin) !== 0) {
            guardUrl = location.href;
            history.pushState({ robesBackGuard: 1 }, '', location.href);
        }
    }

    window.addEventListener('popstate', function() {
        if (guardUrl && location.href === guardUrl) {
            var home = '/';
            try {
                home = new URL((window.ROBES && ROBES.homeUrl) || '/', location.href).pathname || '/';
            } catch (err) { home = '/'; }
            guardUrl = null;
            history.replaceState(null, '', home);
            loadPage(home, false);
            return;
        }
        loadPage(location.href, false);
    });
})();
