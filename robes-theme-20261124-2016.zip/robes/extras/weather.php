<?php
/**
 * 图片位天气接口（同源代理）
 * 按访客 IP 自动识别城市，返回当地实时天气
 */

define('WX_LAT', '22.9864');
define('WX_LON', '114.7196');
define('WX_LABEL', '惠东县');

define('WX_WEATHER_TTL', 1200);
define('WX_FAIL_TTL', 120);
define('WX_GEO_TTL', 604800);
define('WX_GEO_FAIL_TTL', 3600);
define('WX_UA', 'Mozilla/5.0 (compatible; RobesTheme/1.0)');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');

function wx_out($data)
{
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function wx_http($url, $timeout)
{
    if (!function_exists('curl_init')) return '';
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_TIMEOUT        => $timeout,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_FOLLOWLOCATION => 1,
        CURLOPT_USERAGENT      => WX_UA,
    ));
    $body = curl_exec($ch);
    curl_close($ch);
    return is_string($body) ? $body : '';
}

function wx_cache_dir()
{
    static $dir = null;
    if ($dir !== null) return $dir;

    $cands = array(
        rtrim(sys_get_temp_dir(), '/') . '/robes-wx-cache',
        __DIR__ . '/wx-cache',
    );
    foreach ($cands as $c) {
        if (!is_dir($c) && !@mkdir($c, 0755, true) && !is_dir($c)) continue;
        if (is_writable($c)) { $dir = $c; return $dir; }
    }
    $dir = '';
    return $dir;
}

function wx_cache_read($key)
{
    $dir = wx_cache_dir();
    if ($dir === '') return null;
    $fp = @fopen($dir . '/' . $key . '.json', 'rb');
    if (!$fp) return null;
    $raw = stream_get_contents($fp);
    fclose($fp);
    $row = json_decode($raw, true);
    if (!is_array($row) || !isset($row['t'], $row['ttl'], $row['v'])) return null;
    if (time() - (int) $row['t'] > (int) $row['ttl']) return null;
    return $row['v'];
}

function wx_cache_write($key, $val, $ttl)
{
    $dir = wx_cache_dir();
    if ($dir === '') return;
    @file_put_contents(
        $dir . '/' . $key . '.json',
        json_encode(array('t' => time(), 'ttl' => $ttl, 'v' => $val), JSON_UNESCAPED_UNICODE),
        LOCK_EX
    );
}

function wx_wind($cur)
{
    $dirs = array('北', '东北', '东', '东南', '南', '西南', '西', '西北');
    $dir = '';
    if (isset($cur['winddirDegree']) && $cur['winddirDegree'] !== '') {
        $dir = $dirs[(int) round(((float) $cur['winddirDegree'] % 360) / 45) % 8];
    }

    $level = '';
    if (isset($cur['windspeedKmph']) && $cur['windspeedKmph'] !== '') {
        $bounds = array(1, 6, 12, 20, 29, 39, 50, 62, 75, 89, 103, 118);
        $kmh = (float) $cur['windspeedKmph'];
        $grade = 12;
        foreach ($bounds as $i => $min) {
            if ($kmh < $min) { $grade = $i; break; }
        }
        $level = $grade . '级';
    }

    if ($dir === '') return $level;
    return $level === '' ? $dir . '风' : $dir . '风 ' . $level;
}

/**
 * 访客真实 IP：EdgeOne 连接 IP → X-Forwarded-For 首段 → REMOTE_ADDR
 * 只接受公网地址，内网/保留地址返回空串
 */
function wx_client_ip()
{
    $cands = array();
    if (!empty($_SERVER['HTTP_EO_CONNECTING_IP'])) {
        $cands[] = $_SERVER['HTTP_EO_CONNECTING_IP'];
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        foreach (explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']) as $part) {
            $cands[] = $part;
        }
    }
    if (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        $cands[] = $_SERVER['HTTP_X_REAL_IP'];
    }
    if (!empty($_SERVER['REMOTE_ADDR'])) {
        $cands[] = $_SERVER['REMOTE_ADDR'];
    }

    foreach ($cands as $ip) {
        $ip = trim((string) $ip);
        if ($ip === '') continue;
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            return $ip;
        }
    }
    return '';
}

/**
 * IP → 经纬度与城市名（中文），成功结果缓存 7 天，失败缓存 1 小时
 */
function wx_geo($ip)
{
    if ($ip === '') return null;

    $key = 'geo_' . md5($ip);
    $cached = wx_cache_read($key);
    if (is_array($cached)) {
        return empty($cached['ok']) ? null : $cached;
    }

    $geo = null;

    $raw = wx_http('https://ipwho.is/' . rawurlencode($ip) . '?lang=zh-CN', 5);
    if ($raw !== '') {
        $j = json_decode($raw, true);
        if (is_array($j) && !empty($j['success']) && isset($j['latitude'], $j['longitude'])) {
            $city = isset($j['city']) ? trim((string) $j['city']) : '';
            if ($city === '' && isset($j['region'])) {
                $city = trim((string) $j['region']);
            }
            $geo = array(
                'ok'   => true,
                'lat'  => (string) $j['latitude'],
                'lon'  => (string) $j['longitude'],
                'city' => $city,
            );
        }
    }

    if ($geo === null) {
        $raw = wx_http('https://ipapi.co/' . rawurlencode($ip) . '/json/', 5);
        if ($raw !== '') {
            $j = json_decode($raw, true);
            if (is_array($j) && empty($j['error']) && isset($j['latitude'], $j['longitude'])) {
                $city = isset($j['city']) ? trim((string) $j['city']) : '';
                if ($city === '' && isset($j['region'])) {
                    $city = trim((string) $j['region']);
                }
                $geo = array(
                    'ok'   => true,
                    'lat'  => (string) $j['latitude'],
                    'lon'  => (string) $j['longitude'],
                    'city' => $city,
                );
            }
        }
    }

    wx_cache_write($key, $geo === null ? array('ok' => false) : $geo, $geo === null ? WX_GEO_FAIL_TTL : WX_GEO_TTL);

    return $geo;
}

/**
 * WMO 天气代码 → wttr.in(WWO) 代码 + 中文描述
 * 复用前端已有的图标映射，避免改 JS
 */
function wx_wmo_map($wmo)
{
    $map = array(
        0  => array(113, '晴'),
        1  => array(116, '晴间多云'),
        2  => array(119, '多云'),
        3  => array(122, '阴'),
        45 => array(248, '雾'),
        48 => array(260, '冻雾'),
        51 => array(263, '零星毛毛雨'),
        53 => array(266, '毛毛雨'),
        55 => array(266, '浓毛毛雨'),
        56 => array(281, '冻毛毛雨'),
        57 => array(284, '强冻毛毛雨'),
        61 => array(296, '小雨'),
        63 => array(302, '中雨'),
        65 => array(308, '大雨'),
        66 => array(311, '冻雨'),
        67 => array(314, '强冻雨'),
        71 => array(326, '小雪'),
        73 => array(329, '中雪'),
        75 => array(332, '大雪'),
        77 => array(338, '雪粒'),
        80 => array(293, '小阵雨'),
        81 => array(299, '中阵雨'),
        82 => array(305, '强阵雨'),
        85 => array(368, '小阵雪'),
        86 => array(371, '强阵雪'),
        95 => array(386, '雷阵雨'),
        96 => array(389, '雷阵雨伴冰雹'),
        99 => array(389, '强雷雨伴冰雹'),
    );
    return isset($map[(int) $wmo]) ? $map[(int) $wmo] : array(119, '多云');
}

/** Open-Meteo：免 key、国内可直连，作为首选数据源 */
function wx_fetch_openmeteo($lat, $lon, $label)
{
    if ($lat === '' || $lon === '') return array();

    $url = 'https://api.open-meteo.com/v1/forecast?latitude=' . rawurlencode($lat)
        . '&longitude=' . rawurlencode($lon)
        . '&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m'
        . '&wind_speed_unit=kmh&timezone=auto';
    $raw = wx_http($url, 6);
    if ($raw === '') return array();

    $j = json_decode($raw, true);
    if (!is_array($j) || empty($j['current']) || !isset($j['current']['temperature_2m'])) return array();
    $cur = $j['current'];

    $hit = wx_wmo_map(isset($cur['weather_code']) ? $cur['weather_code'] : 2);
    $wind = wx_wind(array(
        'winddirDegree' => isset($cur['wind_direction_10m']) ? $cur['wind_direction_10m'] : '',
        'windspeedKmph' => isset($cur['wind_speed_10m']) ? $cur['wind_speed_10m'] : '',
    ));

    return array(
        'temp'     => (string) round((float) $cur['temperature_2m']),
        'code'     => (string) $hit[0],
        'desc'     => $hit[1],
        'city'     => $label,
        'feels'    => isset($cur['apparent_temperature']) ? (string) round((float) $cur['apparent_temperature']) : '',
        'humidity' => isset($cur['relative_humidity_2m']) ? (string) round((float) $cur['relative_humidity_2m']) : '',
        'wind'     => $wind,
    );
}

function wx_fetch_weather($lat, $lon, $label)
{
    $meteo = wx_fetch_openmeteo($lat, $lon, $label);
    if (!empty($meteo)) return $meteo;

    $queries = array();
    if ($lat !== '' && $lon !== '') {
        $queries[] = $lat . ',' . $lon;
    }
    if ($label !== '') {
        $queries[] = $label;
    }

    foreach ($queries as $q) {
        $raw = wx_http('https://wttr.in/' . rawurlencode($q) . '?format=j1', 6);
        if ($raw === '') continue;
        $j = json_decode($raw, true);
        if (!is_array($j) || empty($j['current_condition'][0])) continue;
        $cur = $j['current_condition'][0];
        $temp = isset($cur['temp_C']) ? (string) $cur['temp_C'] : '';
        if ($temp === '') continue;
        return array(
            'temp'     => $temp,
            'code'     => isset($cur['weatherCode']) ? (string) $cur['weatherCode'] : '',
            'desc'     => isset($cur['weatherDesc'][0]['value']) ? (string) $cur['weatherDesc'][0]['value'] : '',
            'city'     => $label,
            'feels'    => isset($cur['FeelsLikeC']) ? (string) $cur['FeelsLikeC'] : '',
            'humidity' => isset($cur['humidity']) ? (string) $cur['humidity'] : '',
            'wind'     => wx_wind($cur),
        );
    }
    return array();
}

$geo = wx_geo(wx_client_ip());

$lat = $geo !== null ? $geo['lat'] : WX_LAT;
$lon = $geo !== null ? $geo['lon'] : WX_LON;
$label = ($geo !== null && $geo['city'] !== '') ? $geo['city'] : WX_LABEL;

$key = 'wx_' . md5(round((float) $lat, 2) . ',' . round((float) $lon, 2));

$weather = wx_cache_read($key);
if ($weather === null) {
    $weather = wx_fetch_weather($lat, $lon, $label);
    wx_cache_write($key, $weather, empty($weather) ? WX_FAIL_TTL : WX_WEATHER_TTL);
}

if (empty($weather)) wx_out(array('ok' => false));

/* 同一坐标可能对应多个城市名，缓存共享、城市名按当前访客覆盖 */
$weather['city'] = $label;

wx_out(array('ok' => true) + $weather);
