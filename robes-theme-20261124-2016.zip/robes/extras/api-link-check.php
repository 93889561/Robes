<?php
/**
 * 友情链接状态检测 API
 *
 * 并发检测（curl_multi），整体耗时控制在几秒内，
 * 避免串行探测导致 CDN（EdgeOne 等）回源超时返回 524。
 */
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'POST only']);
    exit;
}

$urls = isset($_POST['urls']) ? $_POST['urls'] : array();
if (!is_array($urls) || empty($urls)) {
    echo json_encode(['error' => 'no urls']);
    exit;
}

$urls = array_slice(array_values(array_unique(array_filter($urls, function ($u) {
    return filter_var($u, FILTER_VALIDATE_URL);
}))), 0, 50);

if (empty($urls)) {
    echo json_encode(new stdClass());
    exit;
}

$results = _checkBatch($urls, true);

$retry = array();
foreach ($results as $r) {
    if ($r['ok']) continue;
    if ($r['status'] === 403 || $r['status'] === 405 || $r['status'] === 0) $retry[] = $r['url'];
}
if (!empty($retry)) {
    $again = _checkBatch($retry, false);
    foreach ($again as $r) {
        if ($r['ok'] || $results[$r['url']]['status'] === 0) $results[$r['url']] = $r;
    }
}

$payload = array();
foreach ($results as $r) {
    $u = $r['url'];
    unset($r['url']);
    $payload[$u] = $r;
}
echo json_encode($payload, JSON_UNESCAPED_UNICODE);
exit;

/**
 * 并发检测一批 URL，返回以 url 为键的结果数组
 * @param array $urls
 * @param bool  $head true=HEAD 探测，false=GET 探测（仅取前 1KB）
 */
function _checkBatch($urls, $head = true)
{
    $out = array();

    if (!function_exists('curl_multi_init')) {
        foreach ($urls as $u) {
            $out[$u] = array('url' => $u, 'ok' => false, 'status' => 0, 'error' => 'no_curl', 'time' => 0);
        }
        return $out;
    }

    $timeout = $head ? 6000 : 5000;
    $mh = curl_multi_init();
    $map = array();   
    $chs = array();
    $starts = array();

    foreach ($urls as $url) {
        $ch = curl_init();
        $opts = array(
            CURLOPT_URL                => $url,
            CURLOPT_RETURNTRANSFER     => true,
            CURLOPT_FOLLOWLOCATION     => true,
            CURLOPT_MAXREDIRS          => 3,
            CURLOPT_CONNECTTIMEOUT_MS  => 3000,
            CURLOPT_TIMEOUT_MS         => $timeout,
            CURLOPT_SSL_VERIFYPEER     => true,
            CURLOPT_SSL_VERIFYHOST     => 2,
            CURLOPT_USERAGENT          => 'Mozilla/5.0 (compatible; LinkChecker/1.1)',
            CURLOPT_HTTPHEADER         => array('Accept: text/html,*/*'),
        );
        if ($head) {
            $opts[CURLOPT_NOBODY] = true;
        } else {
            $opts[CURLOPT_RANGE] = '0-1024';
        }
        curl_setopt_array($ch, $opts);
        curl_multi_add_handle($mh, $ch);
        $id = spl_object_id($ch);
        $map[$id] = $url;
        $chs[$id] = $ch;
        $starts[$id] = microtime(true);
    }

    $running = null;
    do {
        $status = curl_multi_exec($mh, $running);
        if ($running && $status === CURLM_OK) curl_multi_select($mh, 0.2);
    } while ($running && $status === CURLM_OK);

    foreach ($map as $id => $url) {
        $ch = $chs[$id];
        if (!$ch) continue;

        $errno = curl_errno($ch);
        $code  = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err   = curl_error($ch);
        $time  = (int) round((microtime(true) - $starts[$id]) * 1000);

        curl_multi_remove_handle($mh, $ch);
        curl_close($ch);

        $out[$url] = array(
            'url'    => $url,
            'ok'     => ($errno === 0 && $code > 0 && $code < 500),
            'status' => $code,
            'error'  => ($errno === 0 && $code > 0 && $code < 500) ? '' : ($err ?: 'curl_errno:' . $errno),
            'time'   => $time,
        );
    }

    curl_multi_close($mh);
    return $out;
}
