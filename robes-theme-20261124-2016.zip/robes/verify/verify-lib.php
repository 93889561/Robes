<?php
/**
 * Robes 主题 · 评论无感验证核心
 *
 */
if (!defined('ROBES_VERIFY_LIB')) define('ROBES_VERIFY_LIB', true);

if (!defined('ROBES_VERIFY_TTL'))         define('ROBES_VERIFY_TTL', 3600);            
if (!defined('ROBES_VERIFY_MIN_ELAPSED')) define('ROBES_VERIFY_MIN_ELAPSED', 1000);   
if (!defined('ROBES_VERIFY_MAX_ELAPSED')) define('ROBES_VERIFY_MAX_ELAPSED', 3600000);
if (!defined('ROBES_VERIFY_RATE'))        define('ROBES_VERIFY_RATE', 8);             
if (!defined('ROBES_VERIFY_STORE_TTL'))   define('ROBES_VERIFY_STORE_TTL', 3600);      

function robesVerifyOption($key, $default = '')
{
    try {
        $val = \Helper::options()->{$key};
        return ($val !== null && $val !== '') ? $val : $default;
    } catch (\Throwable $e) {
        return $default;
    }
}

function robesVerifyEnabled()
{
    return robesVerifyOption('enableCommentVerify', '1') === '1';
}

function robesVerifyDifficulty()
{
    return max(2, min(5, intval(robesVerifyOption('verifyDifficulty', '4'))));
}

function robesVerifySecret()
{
    static $secret = null;
    if ($secret !== null) return $secret;

    $seed = '';
    try {
        $cfg = \Typecho\Db::get()->getConfig(\Typecho\Db::READ);
        $arr = method_exists($cfg, 'toArray') ? $cfg->toArray() : array();
        $seed = (isset($arr['password']) ? $arr['password'] : '')
              . '|' . (isset($arr['database']) ? $arr['database'] : '')
              . '|' . (isset($arr['user']) ? $arr['user'] : '');
    } catch (\Throwable $e) {
    }
    if ($seed === '') {
        $seed = defined('__TYPECHO_ROOT_DIR__') ? __TYPECHO_ROOT_DIR__ : __DIR__;
    }

    $secret = hash('sha256', $seed . '|robes-verify-v1');
    return $secret;
}

function robesVerifyClientIp()
{
    try {
        return \Typecho\Request::getInstance()->getIp();
    } catch (\Throwable $e) {
    }
    return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
}

function robesVerifyIpTag($ip)
{
    return substr(hash_hmac('sha256', (string) $ip, robesVerifySecret()), 0, 16);
}

function robesVerifyB64($raw)
{
    return rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');
}

function robesVerifyUnb64($str)
{
    return base64_decode(strtr($str, '-_', '+/'), true);
}

function robesVerifySign($body)
{
    return substr(hash_hmac('sha256', $body, robesVerifySecret()), 0, 32);
}


function robesVerifyIssue()
{
    $data = array(
        'n' => bin2hex(random_bytes(12)),   
        'e' => time(),                      
        'd' => robesVerifyDifficulty(),     
        'i' => robesVerifyIpTag(robesVerifyClientIp()),
    );
    $body = robesVerifyB64(json_encode($data));

    return array(
        'token'      => $body . '.' . robesVerifySign($body),
        'nonce'      => $data['n'],
        'difficulty' => $data['d'],
        'expires'    => $data['e'] + ROBES_VERIFY_TTL,
    );
}

function robesVerifyParseToken($token)
{
    if (!is_string($token) || $token === '' || strpos($token, '.') === false) return null;

    list($body, $sig) = explode('.', $token, 2);
    if (!hash_equals(robesVerifySign($body), (string) $sig)) return null;

    $json = robesVerifyUnb64($body);
    if ($json === false) return null;
    $data = json_decode($json, true);
    if (!is_array($data) || !isset($data['n'], $data['e'], $data['d'], $data['i'])) return null;

    $issued = intval($data['e']);
    if ($issued > time() + 60) return null;                  
    if (time() - $issued > ROBES_VERIFY_TTL) return null;    
    /**
     * 不再校验签发时的 IP：
     * 站点经 CDN（EdgeOne/Cloudflare 等）回源时，REMOTE_ADDR 是边缘节点 IP，
     * 每次请求都可能不同，会导致签到正常但提交时报“验证已过期”。
     * 防重放由 nonce 单次使用 + 签名 + 有效期保证。
     */

    return $data;
}


function robesVerifyPowOk($nonce, $proof, $difficulty)
{
    if (!is_string($proof) || $proof === '' || strlen($proof) > 20) return false;
    if (!preg_match('/^[0-9]+$/', $proof)) return false;
    if (!is_string($nonce) || $nonce === '' || strlen($nonce) > 128) return false;

    $difficulty = max(1, intval($difficulty));
    $hash = hash('sha256', $nonce . $proof);
    return strpos($hash, str_repeat('0', $difficulty)) === 0;
}

function robesVerifyStoreDir()
{
    static $dir = null;
    if ($dir !== null) return $dir === '' ? null : $dir;

    $base = function_exists('sys_get_temp_dir') ? sys_get_temp_dir() : '/tmp';
    $path = rtrim($base, '/') . '/robes-verify-' . substr(robesVerifySecret(), 0, 12);
    if (!is_dir($path)) @mkdir($path, 0700, true);
    $dir = (is_dir($path) && is_writable($path)) ? $path : '';

    return $dir === '' ? null : $dir;
}


function robesVerifyMarkUsed($nonce)
{
    $dir = robesVerifyStoreDir();
    if (!$dir) return true;

    $file = $dir . '/' . hash('sha256', $nonce);
    if (is_file($file) && (time() - @filemtime($file)) < ROBES_VERIFY_STORE_TTL) return false;

    @file_put_contents($file, (string) time(), LOCK_EX);

    if (mt_rand(1, 50) === 1) {   
        foreach ((array) @glob($dir . '/*') as $f) {
            if (time() - @filemtime($f) > ROBES_VERIFY_STORE_TTL) @unlink($f);
        }
    }

    return true;
}

function robesVerifyRateLimited($ip)
{
    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select(array('COUNT(coid)' => 'total'))
                ->from('table.comments')
                ->where('ip = ?', $ip)
                ->where('created > ?', time() - 60)
        );
        return intval(isset($row['total']) ? $row['total'] : 0) >= ROBES_VERIFY_RATE;
    } catch (\Throwable $e) {
        return false;
    }
}

function robesVerifyIsCommentPost()
{
    if (!isset($_SERVER['REQUEST_METHOD']) || strtoupper($_SERVER['REQUEST_METHOD']) !== 'POST') return false;

    $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    $path = parse_url($uri, PHP_URL_PATH);
    if (!is_string($path) || $path === '') $path = $uri;

    if (substr($path, -8) === '/comment') return true;                 
    if (strpos($path, 'contents-comment') !== false) return true;      
    return false;
}

function robesVerifyIsLoggedIn()
{
    try {
        $opts = \Widget\Options::alloc();
        \Typecho\Cookie::setPrefix(rtrim($opts->siteUrl, '/'));
        if (!\Typecho\Cookie::get('__typecho_uid')) return false;
        return (bool) \Widget\User::alloc()->hasLogin();
    } catch (\Throwable $e) {
        return false;
    }
}

function robesVerifyReject($code, $payload)
{
    if (!headers_sent()) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}
