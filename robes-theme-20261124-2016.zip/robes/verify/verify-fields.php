<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
if (themeOption('enableCommentVerify', '1') !== '1') return;
?>
<input type="text" name="vf_hp" class="vf-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
<input type="hidden" name="vf_token" value="">
<input type="hidden" name="vf_proof" value="">
<input type="hidden" name="vf_elapsed" value="">
<input type="hidden" name="vf_beh" value="">
<span class="vf-pill" id="vf-pill" data-state="idle" title="提交时自动完成人机校验，无需点击">
    <i class="ri-shield-check-line vf-icon"></i>
    <span class="vf-text">正在验证…</span>
</span>
