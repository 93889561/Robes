<?php
/**
 * Robes 主题 · 评论无感验证接口
 *
 */
/* 引导 Typecho：签名密钥由数据库配置派生，必须与评论提交时的运行环境一致，
   否则签发的 token 在提交时验签失败（提示“验证已过期”） */
if (!defined('__TYPECHO_ROOT_DIR__')) {
    $__root = dirname(__DIR__, 4);
    if (is_file($__root . '/config.inc.php')) {
        require_once $__root . '/config.inc.php';
    }
}

require_once __DIR__ . '/verify-lib.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('X-Robots-Tag: noindex');

$__action = isset($_GET['action']) ? (string) $_GET['action'] : '';

if (!robesVerifyEnabled()) {
    http_response_code(404);
    echo '{"ok":false,"message":"verify disabled"}';
    exit;
}

if ($__action === 'challenge') {
    $__out = array('ok' => true) + robesVerifyIssue();
    echo json_encode($__out, JSON_UNESCAPED_UNICODE);
    exit;
}

http_response_code(400);
echo '{"ok":false,"message":"bad action"}';
