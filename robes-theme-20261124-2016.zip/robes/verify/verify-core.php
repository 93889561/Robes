<?php
/**
 * Robes 主题 · 评论验证服务端拦截（可选）
 *
 * 主题默认仅做前端无感验证。若需要服务端强制拦截，
 * 请在 config.inc.php 末尾引入本文件：
 * require_once __TYPECHO_ROOT_DIR__ . '/usr/themes/robes/verify-core.php';
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

require_once __DIR__ . '/verify-lib.php';

function robesVerifyGuard()
{
    if (!robesVerifyIsCommentPost()) return;

    try {
        if (!robesVerifyEnabled()) return;
        if (robesVerifyIsLoggedIn()) return;

        $elapsed = isset($_POST['vf_elapsed']) ? intval($_POST['vf_elapsed']) : 0;
        $beh     = isset($_POST['vf_beh']) ? intval($_POST['vf_beh']) : 0;

        $hp = isset($_POST['vf_hp']) ? trim((string) $_POST['vf_hp']) : '';
        if ($hp !== '' && $beh < 1) {
            robesVerifyReject(200, array('ok' => true, 'filtered' => true));
        }

        if ($elapsed < ROBES_VERIFY_MIN_ELAPSED || $elapsed > ROBES_VERIFY_MAX_ELAPSED) {
            robesVerifyReject(403, array('verify' => 'timing', 'message' => '提交速度异常，请重试'));
        }
        if ($beh < 1) {
            robesVerifyReject(403, array('verify' => 'behavior', 'message' => '验证未通过，请刷新页面后重试'));
        }

        $data = robesVerifyParseToken(isset($_POST['vf_token']) ? $_POST['vf_token'] : '');
        if (!$data) {
            robesVerifyReject(403, array('verify' => 'token', 'message' => '验证已过期，请重新提交'));
        }

        $proof = isset($_POST['vf_proof']) ? $_POST['vf_proof'] : '';
        if (!robesVerifyPowOk($data['n'], $proof, $data['d'])) {
            robesVerifyReject(403, array('verify' => 'proof', 'message' => '验证未通过，请重试'));
        }

        if (!robesVerifyMarkUsed($data['n'])) {
            robesVerifyReject(403, array('verify' => 'replay', 'message' => '验证已使用，请重新提交'));
        }

        if (robesVerifyRateLimited(robesVerifyClientIp())) {
            robesVerifyReject(429, array('verify' => 'rate', 'message' => '评论太频繁，请稍后再试'));
        }
    } catch (\Throwable $e) {
        return;   
    }
}

robesVerifyGuard();
