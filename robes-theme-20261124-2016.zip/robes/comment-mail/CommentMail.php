<?php
/**
 * Robes 评论邮箱通知
 * 新评论提交完成后发送 HTML 邮件提醒博主。
 * 支持：SMTP 发信（内置 PHPMailer 6，同 CommentNotifier 插件方案），未配置 SMTP 时回退到服务器本机 mail() 发信。
 * 配置入口：后台 外观 -> 设置外观（主题设置中的“评论邮件通知”一项）。
 */
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class RobesCommentMail
{
    /** 同一请求内只发一次 */
    private static $sent = false;

    /** 节流时间戳文件（放在站点目录之外，避免被公网下载） */
    private static function throttleFile()
    {
        return '/tmp/robes-comment-mail.sent';
    }

    /** options 表缓存 */
    private static $optCache = null;

    /** 从 options 表读取设置项（不依赖 Helper 类，CLI/Web 均可用），未保存时返回默认值 */
    private static function option($key, $default = '')
    {
        if (self::$optCache === null) {
            self::$optCache = array();
            try {
                $db = \Typecho\Db::get();
                $rows = $db->fetchAll($db->select('name', 'value')->from('table.options'));
                foreach ($rows as $row) {
                    /** 主题设置保存在 theme-robes 行（后台“设置外观”），解码后并入缓存 */
                    if ($row['name'] === 'theme:robes' || $row['name'] === 'theme-robes') {
                        $cfg = json_decode($row['value'], true);
                        if (!is_array($cfg)) {
                            $cfg = @unserialize($row['value']);
                        }
                        if (is_array($cfg)) {
                            foreach ($cfg as $k => $v) {
                                if (is_string($v)) {
                                    self::$optCache[$k] = $v;
                                }
                            }
                        }
                        continue;
                    }
                    self::$optCache[$row['name']] = $row['value'];
                }
            } catch (\Exception $e) {
            }
        }
        $val = isset(self::$optCache[$key]) ? self::$optCache[$key] : null;
        return ($val !== null && $val !== '') ? $val : $default;
    }

    /** 注册评论完成钩子（必须在评论提交请求到达前执行，由 bootstrap.php 调用） */
    public static function register()
    {
        \Typecho\Plugin::factory('Widget\Feedback')->finishComment = array(__CLASS__, 'onFinish');
    }

    /**
     * 评论完成回调
     * @param object $widget Widget\Feedback 实例（评论数据已 push 进 row）
     */
    public static function onFinish($widget)
    {
        /* 私密评论标记与邮件提醒共用同一个 finishComment 钩子，先处理私密标记 */
        if (class_exists('RobesPrivateComments')) {
            RobesPrivateComments::onFinish($widget);
        }

        /* 订阅勾选与「回复通知」独立于博主通知的节流 */
        try {
            self::handleReplyNotify($widget);
        } catch (\Throwable $e) {
            self::log('REPLY ERROR ' . $e->getMessage());
        }

        if (self::$sent) {
            return;
        }
        try {
            if (self::option('cmEnable', '1') !== '1') {
                return;
            }

            $data = self::buildData($widget);
            if (!$data) {
                return;
            }

            /** 节流：10 秒内最多发一封，防止评论灌水刷爆邮箱 */
            $flag = self::throttleFile();
            $last = is_file($flag) ? intval(file_get_contents($flag)) : 0;
            if (time() - $last < 10) {
                self::log('SKIP 节流中（10秒内已有提醒）');
                return;
            }

            $recipients = self::recipients();
            if (empty($recipients)) {
                self::log('SKIP 未找到收件人邮箱');
                return;
            }

            /** 博主自己评论自己时不提醒 */
            $recipients = array_values(array_filter($recipients, function ($m) use ($data) {
                return strcasecmp($m, $data['authorMail']) !== 0;
            }));
            if (empty($recipients)) {
                return;
            }

            self::$sent = true;
            file_put_contents($flag, strval(time()));

            $subject = self::option('title', 'robes.xin') . ' 有新评论：' . $data['excerpt'];
            $html = self::render($data);

            foreach ($recipients as $to) {
                list($ok, $msg) = self::send($to, $subject, $html);
                self::log(($ok ? 'OK  ' : 'FAIL') . ' -> ' . $to . ' | ' . $msg);
            }
        } catch (\Exception $e) {
            self::log('ERROR ' . $e->getMessage());
        } catch (\Throwable $e) {
            self::log('ERROR ' . $e->getMessage());
        }
    }

    /** 同一请求内回复通知只发一次 */
    private static $replySent = false;

    /**
     * 回复通知
     * 评论带 parent 时，直接给被回复的评论作者发信；博主自己与回复自己跳过。
     */
    private static function handleReplyNotify($widget)
    {
        if (self::option('cmEnable', '1') !== '1') {
            return;
        }

        if (self::$replySent) {
            return;
        }

        $myMail = strtolower(trim(strval($widget->mail)));

        $parent = intval($widget->parent);
        if ($parent <= 0 || $myMail === '') {
            return;
        }

        /* 待审核的回复先不发，否则对方点进来什么也看不到 */
        if (strval($widget->status) !== 'approved') {
            self::log('REPLY SKIP 回复待审核');
            return;
        }

        $db = \Typecho\Db::get();
        $p = $db->fetchRow(
            $db->select('author', 'mail', 'text')->from('table.comments')->where('coid = ?', $parent)
        );
        if (!$p) {
            return;
        }

        $to = strtolower(trim(strval($p['mail'])));
        if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
            return;
        }
        if ($to === $myMail) {
            return;
        }

        /* 博主自己有「新评论」通知，不再重复发回复通知 */
        foreach (self::recipients() as $owner) {
            if (strcasecmp($owner, $to) === 0) {
                return;
            }
        }

        /* 同一邮箱 60 秒内最多一封，防止刷屏 */
        $flag = '/tmp/robes-reply-' . md5($to);
        $last = is_file($flag) ? intval(file_get_contents($flag)) : 0;
        if (time() - $last < 60) {
            self::log('REPLY SKIP 节流 -> ' . $to);
            return;
        }

        self::$replySent = true;
        @file_put_contents($flag, strval(time()));

        $title = '';
        $link = strval($widget->permalink);
        try {
            $row = $db->fetchRow($db->select('title')->from('table.contents')->where('cid = ?', intval($widget->cid)));
            if ($row) {
                $title = strval($row['title']);
            }
        } catch (\Throwable $e) {
        }

        $plain = function ($s) {
            return mb_substr(trim(preg_replace('/\s+/u', ' ', strip_tags(strval($s)))), 0, 120);
        };

        $d = array(
            'title'        => $title,
            'link'         => $link,
            'author'       => strval($widget->author),
            'text'         => strval($widget->text),
            'created'      => date('Y-m-d H:i:s', intval($widget->created)),
            'parentAuthor' => strval($p['author']),
            'parentText'   => $plain($p['text']),
            'excerpt'      => $plain($widget->text),
        );

        $subject = self::option('title', 'robes.xin') . ' 回复了你的评论：' . $d['excerpt'];
        list($ok, $msg) = self::send($to, $subject, self::renderReply($d));
        self::log(($ok ? 'REPLY OK  ' : 'REPLY FAIL') . ' -> ' . $to . ' | ' . $msg);
    }

    /**
     * 主题强调色派生：$mix > 0 加深，$mix < 0 变浅（0~1）
     * 邮件里不用半透明，直接算出实色，保证各客户端一致且有足够对比度。
     */
    private static function accent($mix = 0)
    {
        $hex = strval(self::option('accentColor', '#839ac9'));
        $hex = preg_match('/^#?([0-9a-fA-F]{6})$/', $hex, $m) ? $m[1] : '839ac9';
        $out = '#';
        for ($i = 0; $i < 3; $i++) {
            $c = hexdec(substr($hex, $i * 2, 2));
            if ($mix > 0) {
                $c = $c * (1 - $mix);
            } elseif ($mix < 0) {
                $c = $c + (255 - $c) * (-$mix);
            }
            $out .= str_pad(dechex(max(0, min(255, (int) round($c)))), 2, '0', STR_PAD_LEFT);
        }
        return $out;
    }

    /** 邮件公共外壳：白卡片 + 圆角，表格布局兼容常见客户端 */
    private static function shell($inner, $stamp = '')
    {
        $site = htmlspecialchars(mb_strtoupper(strval(self::option('title', 'robes.xin')), 'UTF-8'));
        $sans = "-apple-system,BlinkMacSystemFont,'PingFang SC','Microsoft YaHei',Arial,sans-serif";
        if ($stamp === '') {
            $stamp = date('Y-m-d H:i');
        }

        return '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8">'
            . '<meta name="viewport" content="width=device-width,initial-scale=1">'
            . '<meta name="color-scheme" content="light"></head>'
            . '<body style="margin:0;padding:0;background:#f2f4f7;">'
            . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f2f4f7;">'
            . '<tr><td align="center" style="padding:30px 12px;">'
            . '<table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="width:100%;max-width:600px;background:#ffffff;border:1px solid #e5e9ef;border-radius:18px;overflow:hidden;font-family:' . $sans . ';">'
            . '<tr><td style="padding:32px 38px 26px;">'
            . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
            . '<td style="font-size:11px;letter-spacing:2.5px;color:#9aa4ae;">' . $site . '</td>'
            . '<td align="right" style="font-size:11px;color:#b0b8c2;">' . htmlspecialchars($stamp) . '</td>'
            . '</tr></table>'
            . '<div style="height:1px;background:#eef1f4;margin:18px 0 26px;"></div>'
            . $inner
            . '</td></tr>'
            . '<tr><td style="padding:14px 38px 18px;border-top:1px solid #f2f4f7;font-size:11px;color:#b0b8c2;">此邮件由 ' . $site . ' 自动发送，请勿直接回复</td></tr>'
            . '</table></td></tr></table></body></html>';
    }

    /** 评论者头像：描边圆形 + 首字 */
    private static function avatar($name)
    {
        $core = self::accent(0.36);
        $initial = mb_substr(trim(strip_tags(strval($name))), 0, 1, 'UTF-8');
        if ($initial === '') {
            $initial = '?';
        }
        return '<div style="width:34px;height:34px;border:1px solid #e5e9ef;border-radius:17px;text-align:center;line-height:34px;font-size:14px;color:' . $core . ';">'
            . htmlspecialchars($initial) . '</div>';
    }

    /** 评论者信息：头像 + 昵称 + 时间 */
    private static function who($author, $created)
    {
        $esc = 'htmlspecialchars';
        return '<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"><tr>'
            . '<td width="34" valign="top">' . self::avatar($author) . '</td>'
            . '<td style="padding-left:10px;" valign="middle">'
            . '<div style="font-size:13.5px;font-weight:600;color:#1f2430;line-height:1.4;">' . call_user_func($esc, $author) . '</div>'
            . '<div style="margin-top:2px;font-size:11.5px;color:#9aa4ae;">' . call_user_func($esc, $created) . '</div>'
            . '</td></tr></table>';
    }

    /** 引用块：左侧细线 + 灰色文字 */
    private static function quote($label, $text)
    {
        $line = self::accent(-0.55);
        return '<div style="margin-top:22px;padding-left:14px;border-left:2px solid ' . $line . ';font-size:13px;color:#7b8494;line-height:1.8;">'
            . '<span style="color:#a5aebb;">' . htmlspecialchars(strval($label)) . '</span><br>'
            . htmlspecialchars(strval($text)) . '…</div>';
    }

    /** 细线分隔 */
    private static function divider()
    {
        return '<div style="height:1px;background:#eef1f4;margin:26px 0 20px;"></div>';
    }

    /** 回复通知的 HTML 模板 */
    private static function renderReply($d)
    {
        $esc = 'htmlspecialchars';
        $deep = self::accent(0.36);
        $serif = "Georgia,'Songti SC','SimSun',serif";

        $inner = '<div style="font-size:11px;letter-spacing:3px;color:' . $deep . ';">回 复 提 醒</div>'
            . '<a href="' . call_user_func($esc, $d['link']) . '" style="display:block;margin-top:12px;font-family:' . $serif . ';font-size:22px;font-weight:600;color:#1f2430;line-height:1.55;text-decoration:none;">'
            . call_user_func($esc, $d['title']) . '</a>'
            . '<div style="margin-top:10px;font-size:13px;color:#8a94a6;line-height:1.8;">你在上文下的评论收到了新回复</div>'
            . '<div style="margin-top:22px;">' . self::who($d['author'], $d['created']) . '</div>'
            . '<div style="margin-top:16px;font-size:14px;color:#3a4353;line-height:1.95;">' . call_user_func($esc, $d['text']) . '</div>'
            . self::quote('原评论', $d['parentText'])
            . self::divider()
            . '<a href="' . call_user_func($esc, $d['link']) . '" style="font-size:13px;font-weight:600;color:' . $deep . ';text-decoration:none;letter-spacing:.3px;">查看并回复 →</a>';

        return self::shell($inner, $d['created']);
    }

    /** 收件人列表：主题设置优先，留空用管理员邮箱 */
    private static function recipients()
    {
        $list = preg_split('/[,，;；\s]+/', strval(self::option('cmMail', '')), -1, PREG_SPLIT_NO_EMPTY);
        $list = array_filter($list, function ($m) {
            return filter_var($m, FILTER_VALIDATE_EMAIL);
        });
        if (!empty($list)) {
            return array_values($list);
        }

        try {
            $db = \Typecho\Db::get();
            $row = $db->fetchRow(
                $db->select('mail')->from('table.users')
                    ->where('group = ?', 'administrator')
                    ->order('uid', \Typecho\Db::SORT_ASC)
                    ->limit(1)
            );
            if ($row && filter_var($row['mail'], FILTER_VALIDATE_EMAIL)) {
                return array($row['mail']);
            }
        } catch (\Exception $e) {
        }
        return array();
    }

    /** 从评论组件中整理邮件数据 */
    private static function buildData($widget)
    {
        $cid = intval($widget->cid);
        if ($cid <= 0 || !$widget->text) {
            return null;
        }

        $title = '';
        $link = '';
        try {
            $db = \Typecho\Db::get();
            $row = $db->fetchRow($db->select('title', 'slug')->from('table.contents')->where('cid = ?', $cid));
            if ($row) {
                $title = $row['title'];
                $link = \Typecho\Router::url('post', array('cid' => $cid, 'slug' => $row['slug']), self::option('index', self::option('siteUrl')));
            }
        } catch (\Exception $e) {
        }
        if ($link === '') {
            $link = strval($widget->permalink);
        }

        $plain = trim(preg_replace('/\s+/u', ' ', strip_tags(strval($widget->text))));

        $parent = array();
        if ($widget->parent) {
            try {
                $db = \Typecho\Db::get();
                $p = $db->fetchRow($db->select('author', 'text')->from('table.comments')->where('coid = ?', intval($widget->parent)));
                if ($p) {
                    $parent = array(
                        'author' => $p['author'],
                        'text' => mb_substr(trim(preg_replace('/\s+/u', ' ', strip_tags($p['text']))), 0, 100),
                    );
                }
            } catch (\Exception $e) {
            }
        }

        return array(
            'title'      => $title,
            'link'       => $link,
            'author'     => strval($widget->author),
            'authorMail' => strval($widget->mail),
            'authorUrl'  => strval($widget->url),
            'ip'         => strval($widget->ip),
            'text'       => strval($widget->text),
            'excerpt'    => mb_substr($plain, 0, 40),
            'created'    => date('Y-m-d H:i:s', intval($widget->created)),
            'status'     => strval($widget->status) === 'approved' ? '已通过' : '待审核',
            'parent'     => $parent,
            'adminUrl'   => rtrim(strval(self::option('siteUrl')), '/') . rtrim(__TYPECHO_ADMIN_DIR__, '/') . '/comments.php',
        );
    }

    /** 新评论通知的 HTML 模板 */
    private static function render($d)
    {
        $esc = 'htmlspecialchars';
        $accent = self::accent(0.36);

        $serif = "Georgia,'Songti SC','SimSun',serif";

        $inner = '<div style="font-size:11px;letter-spacing:3px;color:' . $accent . ';">新 评 论</div>'
            . '<a href="' . call_user_func($esc, $d['link']) . '" style="display:block;margin-top:12px;font-family:' . $serif . ';font-size:22px;font-weight:600;color:#1f2430;line-height:1.55;text-decoration:none;">'
            . call_user_func($esc, $d['title']) . '</a>'
            . '<div style="margin-top:24px;">' . self::who($d['author'], $d['created']) . '</div>'
            . '<div style="margin-top:18px;font-size:14px;color:#3a4353;line-height:1.95;">' . call_user_func($esc, $d['text']) . '</div>';

        if (!empty($d['parent'])) {
            $inner .= self::quote($d['parent']['author'] . ' 的评论', $d['parent']['text']);
        }

        $inner .= self::divider()
            . '<div style="font-size:11.5px;color:#a5aebb;letter-spacing:.4px;">'
            . call_user_func($esc, $d['authorMail']) . '　·　' . call_user_func($esc, $d['ip']) . '　·　' . call_user_func($esc, $d['status'])
            . '</div>'
            . '<div style="margin-top:22px;">'
            . '<a href="' . call_user_func($esc, $d['link']) . '" style="font-size:13px;font-weight:600;color:' . $accent . ';text-decoration:none;letter-spacing:.3px;">查看文章 →</a>'
            . '<a href="' . call_user_func($esc, $d['adminUrl']) . '" style="margin-left:22px;font-size:13px;color:#9aa4ae;text-decoration:none;">后台管理</a>'
            . '</div>';

        return self::shell($inner, $d['created']);
    }

    /** 发信：优先 SMTP（PHPMailer，与 CommentNotifier 插件同款实现），失败或未配置则回退本机 mail() */
    private static function send($to, $subject, $html)
    {
        $fromName = strval(self::option('title', 'robes.xin'));
        $smtpHost = strval(self::option('cmSmtpHost', ''));

        if ($smtpHost !== '') {
            try {
                $mail = self::phpMailer();
                $mail->setFrom(self::fromAddress(), $fromName);
                $mail->addAddress($to);
                $mail->Subject = $subject;
                $mail->isHTML();
                $mail->Body = $html;
                $mail->AltBody = trim(preg_replace('/\s+/u', ' ', strip_tags($html)));
                $mail->send();
                return array(true, 'SMTP 发送成功');
            } catch (\Throwable $e) {
                self::log('SMTP失败将回退mail(): ' . $e->getMessage());
            }
        }

        $from = self::fromAddress();
        $headers = 'MIME-Version: 1.0' . "\r\n"
            . 'From: ' . self::encodeHeader($fromName) . ' <' . $from . '>' . "\r\n"
            . 'Content-Type: text/html; charset=UTF-8' . "\r\n"
            . 'Content-Transfer-Encoding: base64' . "\r\n"
            . 'Message-ID: <' . uniqid() . '@' . self::mailHost() . '>';

        $body = chunk_split(base64_encode($html));
        $ok = @mail($to, self::encodeHeader($subject), $body, $headers, '-f' . $from);
        $err = '';
        if (!$ok) {
            $e = error_get_last();
            $err = $e ? ' | ' . $e['message'] : '';
        }
        return array($ok, ($ok ? 'mail() 发送成功' : 'mail() 发送失败' . $err));
    }

    /** 发件地址：SMTP 账号优先，否则管理员邮箱 */
    private static function fromAddress()
    {
        $user = strval(self::option('cmSmtpUser', ''));
        if (filter_var($user, FILTER_VALIDATE_EMAIL)) {
            return $user;
        }
        $r = self::recipients();
        if (!empty($r)) {
            return $r[0];
        }
        return 'no-reply@' . self::mailHost();
    }

    private static function mailHost()
    {
        $host = parse_url(strval(self::option('siteUrl')), PHP_URL_HOST);
        return $host ? $host : 'localhost';
    }

    private static function encodeHeader($str)
    {
        return '=?UTF-8?B?' . base64_encode($str) . '?=';
    }

    /** 按主题设置构造 PHPMailer（SMTP），配置与 CommentNotifier 插件一致 */
    private static function phpMailer()
    {
        if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
            require_once __DIR__ . '/PHPMailer/Exception.php';
            require_once __DIR__ . '/PHPMailer/PHPMailer.php';
            require_once __DIR__ . '/PHPMailer/SMTP.php';
        }

        $user = strval(self::option('cmSmtpUser', ''));
        if ($user === '') {
            throw new \Exception('已配置 SMTP 服务器但账号为空');
        }

        $secure = strval(self::option('cmSmtpSecure', 'ssl'));
        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
        $mail->CharSet = \PHPMailer\PHPMailer\PHPMailer::CHARSET_UTF8;
        $mail->Encoding = \PHPMailer\PHPMailer\PHPMailer::ENCODING_BASE64;
        $mail->isSMTP();
        $mail->Host = strval(self::option('cmSmtpHost', ''));
        $mail->Port = intval(self::option('cmSmtpPort', '465'));
        $mail->SMTPAuth = true;
        $mail->Username = $user;
        $mail->Password = strval(self::option('cmSmtpPass', ''));
        $mail->SMTPSecure = in_array($secure, array('ssl', 'tls'), true) ? $secure : '';
        $mail->Timeout = 10;
        $mail->SMTPKeepAlive = false;
        return $mail;
    }

    /** 写运行日志（站点目录之外，避免被公网下载；自动清理超过 64KB 的旧日志） */
    private static function log($msg)
    {
        $file = '/tmp/robes-comment-mail.log';
        if (is_file($file) && @filesize($file) > 65536) {
            @file_put_contents($file, '');
        }
        @file_put_contents($file, '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", FILE_APPEND);
    }
}
