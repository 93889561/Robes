<?php
/**
 * Robes 评论邮箱通知 - 引导文件
 * 由站点根目录 config.inc.php 加载（评论提交走 action 路由，主题 functions.php
 * 不会在该请求中加载，因此钩子必须在此注册）。
 *
 * 注意：Typecho 在 var/Widget/Init.php 中执行 Plugin::init() 时会用数据库
 * options.plugins 里的注册表整体覆盖钩子表，所以 finishComment 回调除了这里
 * 注册一次外，还持久化在 options 表的 plugins 记录中（与插件激活时的存储一致，
 * 见 register 脚本写入的 Widget_Feedback:finishComment 项）。
 *
 * 禁用方法：在 config.inc.php 中定义 __ROBES_COMMENT_MAIL_OFF__ 或删除该 include 行。
 */
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

require_once __DIR__ . '/CommentMail.php';
require_once __DIR__ . '/../comment-private.php';

RobesCommentMail::register();
